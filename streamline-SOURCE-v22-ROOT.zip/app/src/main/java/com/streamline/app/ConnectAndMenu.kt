package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Amber, unfocusedBorderColor = Line,
    focusedLabelColor = Amber, unfocusedLabelColor = Muted,
    focusedTextColor = TextCol, unfocusedTextColor = TextCol,
    cursorColor = Amber, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2
)

@Composable
fun ConnectScreen(autoConnect: Boolean = false, onAutoConnectConsumed: () -> Unit = {}, onDemo: () -> Unit, onConnected: (StalkerClient) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(Prefs.url(ctx)) }
    var mac by remember { mutableStateOf(Prefs.mac(ctx)) }
    // Advanced fields are OVERRIDE-only and start blank — we never display the device's
    // real generated IDs/signature on screen (showing them would only help cloning a device).
    // Blank = use this device's automatic identity; typing a value overrides it.
    var dev1 by remember { mutableStateOf("") }
    var dev2 by remember { mutableStateOf("") }
    var sig by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var advanced by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    // The connection routine, shared by the Connect button and auto-connect on launch.
    fun doConnect() {
        busy = true; status = "Connecting…"
        val useDev1 = dev1.ifBlank { Prefs.dev1(ctx) }
        val useDev2 = dev2.ifBlank { Prefs.dev2(ctx) }
        val useSig = sig.ifBlank { Prefs.sig(ctx) }
        scope.launch {
            try {
                val client = withContext(Dispatchers.IO) {
                    val c = StalkerClient(url, mac, useDev1, useDev2, useSig, Prefs.serial(ctx), user, pass, Prefs.model(ctx))
                    c.handshake(); c.getProfile(); c.doAuth(); c
                }
                // Persist only on success — a failed attempt (e.g. a typo'd URL/MAC) must not
                // overwrite the working credentials that were already saved.
                Prefs.saveConnection(ctx, url, mac)
                if (dev1.isNotBlank() || dev2.isNotBlank() || sig.isNotBlank())
                    Prefs.saveOverrides(ctx, dev1, dev2, sig)
                busy = false; onConnected(client)
            } catch (e: Exception) {
                busy = false
                val msg = e.message ?: ""
                status = when {
                    msg.contains("timeout", true) || msg.contains("timed out", true) ->
                        "Connection timed out — check the portal address and your internet."
                    msg.contains("Unable to resolve host", true) || msg.contains("UnknownHost", true) ->
                        "Couldn't reach that address — double-check the portal URL."
                    msg.contains("401") || msg.contains("403") || msg.contains("auth", true) ->
                        "The portal rejected this device — check the MAC address with your provider."
                    msg.isBlank() -> "Couldn't connect. Check the address and MAC."
                    else -> msg
                }
            }
        }
    }
    // Auto-connect once on launch when we already have saved credentials.
    LaunchedEffect(Unit) {
        if (autoConnect && url.isNotBlank() && mac.isNotBlank()) { onAutoConnectConsumed(); doConnect() }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("StreamLine", color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("v${BuildConfig.VERSION_NAME}", color = Amber, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 2.dp, bottom = 22.dp))

        Column(
            modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp)
                .background(Panel, RoundedCornerShape(14.dp))
                .border(1.dp, Line, RoundedCornerShape(14.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Connect to your provider's portal", color = TextCol, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            val urlFocus = remember { FocusRequester() }
            // First-time setup (no saved portal): land the remote on the URL field so a D-pad user
            // can start typing via the on-screen keyboard without hunting for the field. On returning
            // launches the URL is already filled, so we don't grab focus (or pop the keyboard).
            LaunchedEffect(Unit) {
                if (Prefs.url(ctx).isBlank()) { try { urlFocus.requestFocus() } catch (_: Exception) {} }
            }
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("Portal address") },
                placeholder = { Text("subdomain.domain.com") },
                singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth().focusRequester(urlFocus),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                colors = fieldColors()
            )
            OutlinedTextField(
                value = mac, onValueChange = { mac = it },
                label = { Text("MAC address") },
                singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )

            OutlinedTextField(
                value = user, onValueChange = { user = it },
                label = { Text("Username (if your portal uses one)") },
                singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )
            OutlinedTextField(
                value = pass, onValueChange = { pass = it },
                label = { Text("Password (if your portal uses one)") },
                singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                colors = fieldColors()
            )

            Text(if (advanced) "▾ Advanced — override device identity (optional)" else "▸ Advanced — override device identity (optional)",
                color = Amber, fontSize = 13.sp,
                modifier = Modifier.clickable { advanced = !advanced })

            if (advanced) {
                OutlinedTextField(
                    value = dev1, onValueChange = { dev1 = it },
                    label = { Text("Device ID 1 (override)") },
                    placeholder = { Text("leave blank — set automatically") },
                    singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
                OutlinedTextField(
                    value = dev2, onValueChange = { dev2 = it },
                    label = { Text("Device ID 2 (override)") },
                    placeholder = { Text("leave blank — set automatically") },
                    singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
                OutlinedTextField(
                    value = sig, onValueChange = { sig = it },
                    label = { Text("Signature (override)") },
                    placeholder = { Text("leave blank — set automatically") },
                    singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
            }

            status?.let {
                Text(it, color = if (it.startsWith("Connected") || it == "Connecting…") Amber else ErrCol,
                    fontSize = 13.sp)
            }
            Button(
                onClick = { doConnect() },
                enabled = !busy && url.isNotBlank() && mac.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))
            ) { Text(if (busy) "Connecting…" else "Connect", fontWeight = FontWeight.SemiBold) }
        }

        Spacer(Modifier.height(14.dp))
        TextButton(onClick = onDemo, enabled = !busy) { Text("Skip — try demo content", color = Muted) }
        Text("The app provides no channels. It plays the service of the provider you connect to.",
            color = Color(0xFF5E6680), fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp).widthIn(max = 420.dp))
        Spacer(Modifier.height(24.dp))
    }
}


private data class MenuTile(
    val label: String, val sub: String, val emoji: String,
    val glow: Color, val dest: Nav?
)

// time-of-day greeting for the warm welcome
private fun greeting(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when { h < 12 -> "Good morning"; h < 18 -> "Good afternoon"; else -> "Good evening" }
}

@Composable
fun MenuScreen(session: Session, demo: Boolean, onOpen: (Nav) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // One-time soft environment check (root/emulator) — shows a dismissible notice, never blocks.
    var envResult by remember { mutableStateOf<EnvCheck.Result?>(null) }
    var showEnvWarning by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val r = withContext(Dispatchers.IO) { EnvCheck.inspect(ctx) }
        envResult = r
        showEnvWarning = r.flagged && !EnvCheck.warningDismissed(ctx)
    }
    val tiles = buildList {
        add(MenuTile("Live TV", if (demo) "Demo channels" else "All channels", "📺", Color(0xFF4A7FFF), Nav.LiveCategories))
        add(MenuTile("Movies", "Films & cinema", "🎬", Color(0xFFA259FF), Nav.VodCategories))
        add(MenuTile("Series", "TV series & box sets", "📦", Color(0xFF33C5D6), Nav.SeriesCategories))
        // Radio is always shown (owner's choice). Note: this provider returns no radio, so it
        // will display "No radio stations" until the line offers radio.
        add(MenuTile("Radio", "Audio club", "📻", Color(0xFF36C98A), Nav.Radio))
        add(MenuTile("TV Guide", "Now & next", "🗓️", Color(0xFFF6BE55), Nav.Guide))
        if (!demo) add(MenuTile("Account", "Subscription", "🪪", Color(0xFF7B61FF), Nav.Account))
        if (!demo) add(MenuTile("Speed Test", "Connection", "📶", Color(0xFF33C5D6), Nav.SpeedTest))
        add(MenuTile("Settings", "Device & app", "⚙️", Color(0xFF9AA3C8), Nav.Settings))
    }
    Column(modifier = Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text(greeting(), color = Color(0xFFF8CD78), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("StreamLine", color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("v${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
            MenuClock()
            Spacer(Modifier.width(14.dp))
            Text("⌕", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onOpen(Nav.Search()) }
                    .background(Panel, RoundedCornerShape(10.dp)).padding(horizontal = 14.dp, vertical = 8.dp))
        }
        if (showEnvWarning && envResult != null) {
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth()
                    .background(Color(0x33F6BE55), RoundedCornerShape(12.dp))
                    .border(1.dp, Amber.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⚠", color = Amber, fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Heads up", color = TextCol, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("This looks like ${envResult!!.reason()}. The app will still work, but on such setups your account and streams are easier to misuse — keep your portal details private.",
                        color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text("Got it", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { EnvCheck.dismissWarning(ctx); showEnvWarning = false }
                        .background(Color(0x22F6BE55), RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 7.dp))
            }
        }
        Spacer(Modifier.height(26.dp))
        val weatherCity = Prefs.weatherCity(ctx)
        if (weatherCity.isNotBlank()) {
            WeatherCard(weatherCity)
            Spacer(Modifier.height(18.dp))
        }
        Text("WHAT WOULD YOU LIKE TO WATCH?", color = Muted, fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
        Spacer(Modifier.height(28.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 150.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(tiles) { _, t -> MenuTileCard(t, onOpen) }
        }
    }
}

@Composable
private fun MenuTileCard(t: MenuTile, onOpen: (Nav) -> Unit, autoFocus: Boolean = false) {
    val enabled = t.dest != null
    var focused by remember { mutableStateOf(false) }
    val requester = remember { androidx.compose.ui.focus.FocusRequester() }
    if (autoFocus) {
        LaunchedEffect(Unit) { try { requester.requestFocus() } catch (_: Exception) {} }
    }
    val lift by animateFloatAsState(if (focused) 1f else 0f, tween(180), label = "lift")
    val glowAlpha = if (enabled) (0.45f + 0.5f * lift) else 0.12f
    val bg = if (focused) Color(0xFF27304C) else Panel
    val borderColor = if (focused) Amber else Line

    Box(
        modifier = Modifier.height(140.dp)
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .scale(1f + 0.04f * lift)
            .clip(RoundedCornerShape(20.dp))
            .background(bg, RoundedCornerShape(20.dp))
            .border(if (focused) 2.dp else 1.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(enabled = enabled) { t.dest?.let(onOpen) }
    ) {
        // top-right colored glow (radial gradient — works on all API levels, no blur needed)
        Box(
            Modifier.size(150.dp).align(Alignment.TopEnd)
                .offset(x = 40.dp, y = (-40).dp)
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(t.glow.copy(alpha = glowAlpha), Color.Transparent),
                        radius = 200f
                    ),
                    androidx.compose.foundation.shape.CircleShape
                )
        )
        // fainter bottom-left glow for richness
        Box(
            Modifier.size(110.dp).align(Alignment.BottomStart)
                .offset(x = (-30).dp, y = 30.dp)
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(t.glow.copy(alpha = glowAlpha * 0.4f), Color.Transparent),
                        radius = 150f
                    ),
                    androidx.compose.foundation.shape.CircleShape
                )
        )
        // content
        Column(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(t.emoji, fontSize = 34.sp)
            Column {
                Text(t.label, color = if (enabled) TextCol else Muted, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(if (enabled) t.sub else "Coming soon", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

// Live clock + date for the menu header. Updates every second.
@Composable
fun MenuClock() {
    var now by remember { mutableStateOf(java.util.Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = java.util.Date()
            kotlinx.coroutines.delay(1000)
        }
    }
    val timeFmt = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    val dateFmt = remember { java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault()) }
    Column(horizontalAlignment = Alignment.End) {
        Text(timeFmt.format(now), color = TextCol, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        Text(dateFmt.format(now), color = Muted, fontSize = 12.sp)
    }
}
