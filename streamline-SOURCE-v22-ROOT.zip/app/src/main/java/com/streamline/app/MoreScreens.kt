package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.Context
import android.content.Intent

// ---------- Radio ----------
@Composable
fun RadioScreen(session: Session, onPlay: (UiChannel) -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    var state by remember { mutableStateOf<List<UiChannel>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        if (session.client == null) { state = demoRadio; return@LaunchedEffect }
        try {
            state = withContext(Dispatchers.IO) {
                session.client.getRadioChannels().map { UiChannel(it.number, it.name, "Radio", cmd = it.cmd) }
            }
        } catch (e: Exception) { error = e.message ?: "Could not load radio" }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Radio", onBack)
        when {
            error != null -> MessageBox(error!!)
            state == null -> LoadingBox()
            state!!.isEmpty() -> MessageBox("No radio stations returned by the portal.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state!!) { ch ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
                        .clickable { onPlay(ch) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("◉", color = Amber, fontSize = 20.sp, modifier = Modifier.padding(end = 14.dp))
                        Text(ch.name, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("▶", color = Amber, fontSize = 18.sp)
                    }
                }
            }
        }
    }
}

// ---------- TV Guide (timeline) ----------
@Composable
fun GuideScreen(session: Session, onPlay: (UiChannel, List<UiChannel>) -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    var channels by remember { mutableStateOf<List<UiChannel>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val deviceOffsetSec = remember { java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 1000 }
    var serverOffsetSec by remember { mutableStateOf<Int?>(null) }
    var selectedDay by remember { mutableStateOf(0) }
    // Guide looks forward: today + 10 days to come (catch-up covers the past). Filed to portal clock.
    val days = remember(serverOffsetSec) { buildDayList(daysBack = 0, serverOffsetSec = serverOffsetSec ?: deviceOffsetSec, daysForward = 10) }
    // Each channel's programmes for the selected day, read from the persistent 2-week store.
    // Keyed "channelNumber:dayIndex" so switching day re-reads without refetching.
    val epgByKey = remember { mutableStateMapOf<String, List<UiEpg>>() }
    // Programme-detail popup, opened by tapping the highlighted "now" cell. Full cast/description
    // comes from a fresh get_short_epg (the store keeps name+time only), so it's scoped to "now".
    val guideScope = rememberCoroutineScope()
    var guideShowDetail by remember { mutableStateOf(false) }
    var guideDetail by remember { mutableStateOf<EpgProgram?>(null) }
    var guideDetailChan by remember { mutableStateOf("") }
    var guideDetailChannel by remember { mutableStateOf<UiChannel?>(null) }
    var guideDetailLoading by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (session.client == null) { channels = demoChannels; return@LaunchedEffect }
        try {
            val list = withContext(Dispatchers.IO) {
                session.client.getAllChannels().map { UiChannel(it.number, it.name, "Live", logo = it.logo, cmd = it.cmd, id = it.id) }
            }
            channels = list
            // Bulk EPG sweep (get_epg_info) for the whole grid — all channels in one request.
            withContext(Dispatchers.IO) { runCatching { session.client.harvestEpgInfo(15) } }
            // Detect the portal clock once off the first real channel so the day boundaries line up
            // (this also seeds that channel's store, since the probe is the harvest sweep).
            val sample = list.firstOrNull { !it.id.isNullOrBlank() }?.id
            if (sample != null) {
                serverOffsetSec = withContext(Dispatchers.IO) {
                    runCatching { session.client.serverUtcOffsetSeconds(sample) }.getOrNull()
                }
            }
        } catch (e: Exception) { error = e.message ?: "Could not load guide" }
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("TV Guide", onBack)
        when {
            error != null -> MessageBox(error!!)
            channels == null -> LoadingBox()
            channels!!.isEmpty() -> MessageBox("No channels returned by the portal.")
            else -> {
                // Day picker (same days as catch-up)
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    days.forEachIndexed { i, d ->
                        val sel = i == selectedDay
                        Text(
                            d.label,
                            color = if (sel) Color(0xFF1A1300) else Muted,
                            fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .background(if (sel) Amber else Panel, RoundedCornerShape(10.dp))
                                .clickable { selectedDay = i }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(channels!!) { ch ->
                        // Lazily fill this channel's row for the selected day from the 2-week store.
                        val client = session.client
                        val day = days.getOrNull(selectedDay)
                        val key = "${ch.number}:$selectedDay"
                        if (client != null && !ch.id.isNullOrBlank() && day != null && !epgByKey.containsKey(key)) {
                            LaunchedEffect(key) {
                                val progs = withContext(Dispatchers.IO) {
                                    runCatching {
                                        client.harvestShortEpg(ch.id)   // one sweep per channel/session, fills the store
                                        val nowSec = System.currentTimeMillis() / 1000
                                        EpgStore.forDay(ch.id, day.startSec, day.endSec).map { p ->
                                            val isNow = p.startTs in 1..nowSec && nowSec < p.endTs
                                            UiEpg(p.name, epgClock(p), isNow, p.startTs, ch.name)
                                        }
                                    }.getOrDefault(emptyList())
                                }
                                epgByKey[key] = progs
                            }
                        }
                        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                            .clickable { onPlay(ch, channels!!) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(110.dp)) {
                                Text(ch.name, color = TextCol, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(ch.number.toString().padStart(3, '0'), color = Amber, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                                val progs = if (session.client == null) demoEpg[ch.number] ?: emptyList()
                                            else epgByKey[key] ?: emptyList()
                                if (progs.isEmpty())
                                    Text("No programme info", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                                else progs.forEach { p ->
                                    Box(Modifier.padding(end = 6.dp)
                                        .background(if (p.isNow) Amber.copy(alpha = 0.18f) else Panel2, RoundedCornerShape(8.dp))
                                        .border(if (p.isNow) 1.dp else 0.dp, if (p.isNow) Amber else Color.Transparent, RoundedCornerShape(8.dp))
                                        .then(
                                            if (p.isNow) Modifier.clickable {
                                                // tap the now-playing programme -> full detail (fresh short-EPG = cast/description)
                                                val cl = session.client
                                                val cid = ch.id
                                                guideDetailChan = ch.name
                                                guideDetailChannel = ch
                                                guideDetail = null
                                                guideShowDetail = true
                                                if (cl != null && !cid.isNullOrBlank()) {
                                                    guideDetailLoading = true
                                                    guideScope.launch {
                                                        val fresh = withContext(Dispatchers.IO) {
                                                            runCatching {
                                                                val now = System.currentTimeMillis() / 1000
                                                                val list = cl.getShortEpg(cid)
                                                                list.firstOrNull { it.startTs in 1..now && now < it.endTs } ?: list.firstOrNull()
                                                            }.getOrNull()
                                                        }
                                                        guideDetail = fresh
                                                        guideDetailLoading = false
                                                    }
                                                }
                                            } else Modifier
                                        )
                                        .padding(horizontal = 10.dp, vertical = 6.dp)) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(p.name, color = TextCol, fontSize = 12.sp, maxLines = 1)
                                            }
                                            Text(p.time, color = if (p.isNow) Amber else Muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (guideShowDetail) {
            EpgDetailSheet(
                program = guideDetail,
                channelName = guideDetailChan,
                loading = guideDetailLoading,
                actionLabel = "▶ Watch live",
                onAction = {
                    val c = guideDetailChannel
                    if (c != null) onPlay(c, channels ?: emptyList())
                },
                onDismiss = { guideShowDetail = false }
            )
        }
    }
}

// ---------- Search ----------
@Composable
fun SearchScreen(
    session: Session,
    initialQuery: String = "",
    onPlayChannel: (UiChannel) -> Unit,
    onOpenMovie: (UiMovie) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    var query by remember(initialQuery) { mutableStateOf(initialQuery) }
    var committedQuery by remember { mutableStateOf("") }
    var channels by remember { mutableStateOf<List<UiChannel>>(emptyList()) }
    var titles by remember { mutableStateOf<List<UiMovie>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("all") }   // all | live | movies | series

    // Preload channel names once for instant local channel matching.
    LaunchedEffect(Unit) {
        if (session.client == null) channels = demoChannels
        else channels = withContext(Dispatchers.IO) {
            runCatching {
                session.client.getAllChannels().map {
                    UiChannel(it.number, it.name, "Live", logo = it.logo, cmd = it.cmd, id = it.id, archive = it.archive)
                }
            }.getOrDefault(emptyList())
        }
    }

    // Debounce the box, then search VOD + series titles (network) once typing settles.
    LaunchedEffect(query) {
        kotlinx.coroutines.delay(350)
        committedQuery = query.trim()
    }
    LaunchedEffect(committedQuery) {
        val q = committedQuery
        if (q.isBlank()) { titles = emptyList(); loading = false; return@LaunchedEffect }
        if (session.client == null) {
            titles = (demoMovies + demoSeries).filter { it.name.contains(q, true) }
            return@LaunchedEffect
        }
        loading = true
        titles = withContext(Dispatchers.IO) {
            val movies = runCatching { session.client.searchVodAll(q) }.getOrDefault(emptyList()).map { pm ->
                UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                    listOfNotNull(pm.year.ifBlank { null }, pm.director.ifBlank { null }).joinToString(" · "),
                    cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                    seriesId = if (pm.isSeries) pm.id else null,
                    added = pm.added, actors = pm.actors, director = pm.director)
            }
            val series = runCatching { session.client.searchSeriesAll(q) }.getOrDefault(emptyList()).map { pm ->
                UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                    listOfNotNull(pm.year.ifBlank { null }, pm.director.ifBlank { null }).joinToString(" · "),
                    cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                    seriesId = pm.id,
                    added = pm.added, actors = pm.actors, director = pm.director)
            }
            movies + series
        }
        loading = false
    }

    val ch = if (filter == "movies" || filter == "series") emptyList()
             else channels.filter { query.isNotBlank() && it.name.contains(query, true) }.take(30)
    val titleList = when (filter) {
        "live" -> emptyList()
        "movies" -> titles.filter { it.seriesId == null }
        "series" -> titles.filter { it.seriesId != null }
        else -> titles
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Search", onBack)
        // Type filter
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all" to "All", "live" to "Live", "movies" to "Movies", "series" to "Series").forEach { (key, label) ->
                val sel = filter == key
                Text(label, color = if (sel) Color(0xFF1A1300) else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.background(if (sel) Amber else Panel, RoundedCornerShape(10.dp))
                        .clickable { filter = key }.padding(horizontal = 14.dp, vertical = 8.dp))
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search channels, movies & series") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(), colors = fieldColors()
        )
        Spacer(Modifier.height(14.dp))
        when {
            query.isBlank() -> {
                val recents = remember { Prefs.recentSearches(ctx) }
                if (recents.isEmpty()) MessageBox("Type to search channels, movies and series.")
                else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Text("Recent searches", color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    items(recents) { r ->
                        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                            .clickable { query = r }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("\uD83D\uDD58", fontSize = 13.sp, modifier = Modifier.padding(end = 10.dp))
                            Text(r, color = TextCol, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            ch.isEmpty() && titleList.isEmpty() && !loading -> MessageBox("No matches.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (ch.isNotEmpty()) item { Text("Channels", color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                items(ch) { c ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                        .clickable { Prefs.addRecentSearch(ctx, query); onPlayChannel(c) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.number.toString().padStart(3, '0'), color = Amber, fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.padding(end = 12.dp))
                        Text(c.name, color = TextCol, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Text("\u25B6", color = Amber, fontSize = 16.sp)
                    }
                }
                if (loading) item {
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = Amber)
                    }
                }
                if (titleList.isNotEmpty()) item { Text("Movies & Series", color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)) }
                items(titleList) { m ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                        .clickable { Prefs.addRecentSearch(ctx, query); onOpenMovie(m) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(width = 40.dp, height = 58.dp).clip(RoundedCornerShape(6.dp)).background(Panel2)) {
                            if (m.poster != null) AsyncImage(model = m.poster, contentDescription = m.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(m.name, color = TextCol, fontSize = 15.sp, maxLines = 2)
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (m.seriesId != null) "Series" else "Movie", color = Color(0xFF1A1300), fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.background(Amber, RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                                if (m.year.isNotBlank()) { Spacer(Modifier.width(8.dp)); Text(m.year, color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace) }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Series: seasons → episodes (drill-down, loaded on demand) ----------
@Composable
fun EpisodesScreen(session: Session, series: UiMovie, onPlay: (UiEpisode, List<UiEpisode>, Int) -> Unit, onBack: () -> Unit) {
    val sid = series.seriesId
    val isDemo = session.client == null || sid?.startsWith("demo") == true

    // keyed on sid: if this screen is reused for a different series, the state resets cleanly
    // instead of briefly showing the previous series' seasons.
    var seasons by remember(sid) { mutableStateOf<List<UiSeason>?>(null) }
    var seasonsError by remember(sid) { mutableStateOf<String?>(null) }
    var openSeason by remember(sid) { mutableStateOf<UiSeason?>(null) }

    // Load just the SEASONS up front — cheap, so the screen appears fast instead of pre-fetching
    // every season's episodes.
    LaunchedEffect(sid) {
        if (isDemo) { seasons = demoSeasons[sid] ?: emptyList(); return@LaunchedEffect }
        try {
            seasons = withContext(Dispatchers.IO) {
                session.client!!.getSeriesSeasons(sid ?: "").map { UiSeason(it.id, it.number, it.name) }
            }
        } catch (e: Exception) { seasonsError = e.message ?: "Could not load seasons" }
    }

    val loaded = seasons
    val single = loaded != null && loaded.size == 1
    // Episodes to show: an explicitly opened season, or the only season if there's just one
    // (skip a pointless one-row list).
    val sel: UiSeason? = openSeason ?: if (single) loaded!!.first() else null

    // Hardware back: from an opened season in a multi-season series, return to the season list;
    // otherwise leave the screen. (Single-season never sets openSeason, so it exits directly.)
    BackHandler { if (openSeason != null) openSeason = null else onBack() }

    if (sel != null) {
        SeasonEpisodes(
            session = session, series = series, season = sel, isDemo = isDemo,
            onPlay = onPlay,
            onBack = { if (single) onBack() else openSeason = null }
        )
    } else {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            TopBar(series.name, onBack)
            when {
                seasonsError != null -> MessageBox(seasonsError!!)
                loaded == null -> LoadingBox()
                loaded.isEmpty() -> MessageBox("No seasons returned by the portal.")
                else -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(loaded) { s ->
                            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                                .clickable { openSeason = s }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(s.name, color = TextCol, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                Text("›", color = Amber, fontSize = 20.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeasonEpisodes(
    session: Session, series: UiMovie, season: UiSeason, isDemo: Boolean,
    onPlay: (UiEpisode, List<UiEpisode>, Int) -> Unit, onBack: () -> Unit
) {
    var eps by remember(season.id) { mutableStateOf<List<UiEpisode>?>(null) }
    var error by remember(season.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(season.id) {
        val sid = series.seriesId
        if (isDemo) { eps = demoEpisodes[sid] ?: emptyList(); return@LaunchedEffect }
        try {
            eps = withContext(Dispatchers.IO) {
                session.client!!.getSeasonEpisodes(sid ?: "", season.id, season.number).map {
                    UiEpisode(it.name, it.season, it.episode, it.cmd)
                }
            }
        } catch (e: Exception) { error = e.message ?: "Could not load episodes" }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("${series.name} · ${season.name}", onBack)
        when {
            error != null -> MessageBox(error!!)
            eps == null -> LoadingBox()
            eps!!.isEmpty() -> MessageBox("No episodes in this season.")
            else -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(eps!!) { idx, ep ->
                        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                            .clickable { onPlay(ep, eps!!, idx) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("E${ep.episode}", color = Amber, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                                modifier = Modifier.width(44.dp))
                            Text(ep.name, color = TextCol, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text("▶", color = Amber, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

// ---------- Settings ----------
@Composable
fun SettingsScreen(session: Session, onDisconnect: () -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    val demo = session.client == null
    // All state is hoisted to the function level so collapsing a card (which removes its body from
    // composition) never resets what's inside it — only one card is open at a time.
    var openCard by remember { mutableStateOf("") }
    var startup by remember { mutableStateOf(Prefs.startupScreen(ctx)) }
    var portalUrl by remember { mutableStateOf(Prefs.url(ctx)) }
    var portalSaved by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(Prefs.model(ctx)) }
    var eng by remember { mutableStateOf(Prefs.engine(ctx)) }
    var pin by remember { mutableStateOf(Prefs.pin(ctx)) }
    var pinSaved by remember { mutableStateOf(false) }
    var accent by remember { mutableStateOf(Prefs.accent(ctx)) }
    var weatherCity by remember { mutableStateOf(Prefs.weatherCity(ctx)) }
    var devTaps by remember { mutableStateOf(0) }
    var devMode by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var logText by remember { mutableStateOf("") }
    var showCrash by remember { mutableStateOf(false) }
    var crashTextStr by remember { mutableStateOf("") }

    fun toggle(id: String) { openCard = if (openCard == id) "" else id }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TopBar("Settings", onBack)

        if (demo) {
            Button(
                onClick = onDisconnect,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))
            ) { Text("Connect to a portal", fontWeight = FontWeight.SemiBold) }
        }

        // ---------- Connection & account ----------
        SettingsCard("📡", "Connection & account", if (demo) "Demo mode" else "Portal, device model, MAC", Color(0xFF5AA0FF),
            openCard == "conn", { toggle("conn") }) {
            SettingRow("Mode", if (demo) "Demo content" else "Connected to portal")
            SettingRow("Status", "Registered to this device")
            Spacer(Modifier.height(10.dp))
            Text("The portal URL from your provider. You can change it here.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            OutlinedTextField(
                value = portalUrl, onValueChange = { portalUrl = it; portalSaved = false },
                label = { Text("Portal URL") }, placeholder = { Text("https://example.com/stalker_portal/c/") },
                singleLine = true, colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { Prefs.saveUrl(ctx, portalUrl); portalSaved = true },
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                Text(if (portalSaved) "Saved ✓" else "Save portal")
            }
            Spacer(Modifier.height(14.dp))
            Text("Device model — pick the MAG model your line is set up as. MAG254 is the most common.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("MAG250", "MAG254", "MAG322", "MAG420", "MAG520", "MAG540", "MAG544").chunked(4).forEach { rowModels ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowModels.forEach { m ->
                            val selected = model == m
                            Box(
                                Modifier.background(if (selected) Amber else Panel2, RoundedCornerShape(10.dp))
                                    .clickable { model = m; Prefs.saveModel(ctx, m) }
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Text(m, color = if (selected) Color(0xFF1A1304) else TextCol, fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Your MAC address — give this to your provider to register your line. Tap to copy.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            CopyableRow("MAC address", Prefs.mac(ctx), ctx)
        }

        // ---------- Startup & playback ----------
        SettingsCard("🚀", "Startup & playback", "Opening screen and video engine", Color(0xFF3FBF7F),
            openCard == "play", { toggle("play") }) {
            Text("Which screen opens after connecting.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("menu" to "Home", "live" to "Live TV", "movies" to "Movies", "series" to "Series").forEach { (key, label) ->
                    val sel = startup == key
                    Text(label, color = if (sel) Color(0xFF1A1304) else TextCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.background(if (sel) Amber else Panel2, RoundedCornerShape(8.dp))
                            .clickable { startup = key; Prefs.saveStartupScreen(ctx, key) }
                            .padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Playback engine", color = TextCol, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Auto", "exo" to "ExoPlayer", "vlc" to "VLC", "mpv" to "MPV").forEach { (v, label) ->
                    val sel = eng == v
                    Text(label, color = if (sel) Color(0xFF1A1304) else TextCol, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.background(if (sel) Amber else Panel2, RoundedCornerShape(8.dp))
                            .clickable { eng = v; Prefs.saveEngine(ctx, v) }.padding(horizontal = 14.dp, vertical = 8.dp))
                }
            }
            Text("Auto picks per stream — transport streams use MPV (hardware decode + subtitles). Choose MPV to force it for every channel.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        // ---------- Parental lock ----------
        SettingsCard("🔒", "Parental lock",
            if (Prefs.pin(ctx).isBlank()) "Off — set a PIN to lock adult content" else "On — adult content is locked", Color(0xFFF5B638),
            openCard == "lock", { toggle("lock") }) {
            Text("Set a PIN to lock adult categories. With a PIN, those sections ask for the code before opening — enter it once and they stay open until the app restarts. Leave blank to turn the lock off.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            OutlinedTextField(
                value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); pinSaved = false },
                label = { Text("4–6 digit PIN (blank = off)") }, singleLine = true,
                colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { Prefs.savePin(ctx, pin); Prefs.adultUnlocked = false; pinSaved = true },
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                Text(if (pinSaved) "Saved ✓" else "Save PIN", fontWeight = FontWeight.SemiBold)
            }
        }

        // ---------- Appearance & weather ----------
        SettingsCard("🎨", "Appearance & weather", "Accent colour and home weather", Color(0xFFE87DBE),
            openCard == "look", { toggle("look") }) {
            Text("Accent colour", color = TextCol, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("amber" to Color(0xFFF5B638), "blue" to Color(0xFF5B8DEF), "green" to Color(0xFF3FBF7F), "purple" to Color(0xFFB07CF0)).forEach { (name, col) ->
                    Box(Modifier.size(40.dp).background(col, RoundedCornerShape(20.dp))
                        .border(if (accent == name) 3.dp else 0.dp, TextCol, RoundedCornerShape(20.dp))
                        .clickable { accent = name; Prefs.saveAccent(ctx, name) })
                }
            }
            Text("Restart the app to fully apply a new accent.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(14.dp))
            Text("Show a weather card on the home menu. Enter your city (leave blank to hide).",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            OutlinedTextField(
                value = weatherCity, onValueChange = { weatherCity = it },
                label = { Text("City") }, placeholder = { Text("e.g. Nicosia") }, singleLine = true,
                colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { Prefs.saveWeatherCity(ctx, weatherCity.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                Text("Save city")
            }
        }

        // ---------- About ----------
        SettingsCard("ℹ️", "About", "Version & diagnostics", Color(0xFF9AA3C8),
            openCard == "about", { toggle("about") }) {
            Row(Modifier.fillMaxWidth().clickable { devTaps++; if (devTaps >= 7) devMode = true }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("App version", color = TextCol, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("StreamLine ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 14.sp)
            }
            SettingRow("Favorites saved", Prefs.favs(ctx).size.toString())
            if (devMode) {
                Spacer(Modifier.height(12.dp))
                Text("Connection log", color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { logText = ConnectLog.text(); showLog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                        Text(if (showLog) "Refresh" else "Show log")
                    }
                    if (showLog) {
                        Button(onClick = {
                            val cb = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cb.setPrimaryClip(android.content.ClipData.newPlainText("StreamLine log", logText))
                        }, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)) { Text("Copy") }
                        Button(onClick = {
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, logText)
                            }
                            ctx.startActivity(android.content.Intent.createChooser(send, "Share connection log"))
                        }, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)) { Text("Share") }
                        Button(onClick = { ConnectLog.clear(); logText = ConnectLog.text() },
                            colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)) { Text("Clear") }
                    }
                }
                if (showLog) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().background(Color(0xFF0E1320), RoundedCornerShape(12.dp))
                        .border(1.dp, Line, RoundedCornerShape(12.dp)).padding(14.dp)) {
                        Text(logText.ifBlank { "No connection attempt has been logged yet." },
                            color = TextCol, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Crash log", color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { crashTextStr = ConnectLog.crashText(ctx); showCrash = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                        Text(if (showCrash) "Refresh" else "Show crash log")
                    }
                    if (showCrash) {
                        Button(onClick = {
                            val cb = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cb.setPrimaryClip(android.content.ClipData.newPlainText("StreamLine crash log", crashTextStr))
                        }, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)) { Text("Copy") }
                        Button(onClick = { ConnectLog.clearCrash(ctx); crashTextStr = ConnectLog.crashText(ctx) },
                            colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)) { Text("Clear") }
                    }
                }
                if (showCrash) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().background(Color(0xFF0E1320), RoundedCornerShape(12.dp))
                        .border(1.dp, Line, RoundedCornerShape(12.dp)).padding(14.dp)) {
                        Text(crashTextStr.ifBlank { "No crash recorded yet." },
                            color = TextCol, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // ---------- Disconnect ----------
        Button(onClick = onDisconnect, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A1518), contentColor = ErrCol)) {
            Text(if (demo) "Back to connect screen" else "Disconnect", fontWeight = FontWeight.SemiBold)
        }
        Text("StreamLine · built for former Ministra / MAG users.", color = Color(0xFF5E6680), fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
    }

}

@Composable
private fun SettingRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(label, color = Muted, fontSize = 14.sp, modifier = Modifier.width(140.dp))
        Text(value, color = TextCol, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
    }
}

// A settings row whose value can be tapped to copy to the clipboard (for giving to a provider).
@Composable
private fun CopyableRow(label: String, value: String, ctx: android.content.Context) {
    var copied by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth()
            .clickable {
                val cb = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cb.setPrimaryClip(android.content.ClipData.newPlainText(label, value))
                copied = true
            }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Muted, fontSize = 14.sp, modifier = Modifier.width(140.dp))
        Text(value.ifBlank { "—" }, color = TextCol, fontSize = 13.sp,
            fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
        Text(if (copied) "Copied ✓" else "Copy", color = Amber, fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp))
    }
}

// A beautiful collapsible settings card: accent glyph + title + subtitle, with a chevron that
// rotates as it opens. Body animates in/out. Used to group the long settings list into calm,
// tap-to-open sections (only one open at a time).
@Composable
private fun SettingsCard(
    icon: String, title: String, subtitle: String, tint: Color,
    expanded: Boolean, onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val rot by animateFloatAsState(if (expanded) 90f else 0f, label = "chev")
    Box(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Panel, RoundedCornerShape(16.dp))
            .border(1.dp, Line, RoundedCornerShape(16.dp))
    ) {
        // top-right coloured glow — same radial style as the home menu tiles, so each card reads
        // as its own colour instead of a flat panel.
        Box(
            Modifier.size(150.dp).align(Alignment.TopEnd).offset(x = 30.dp, y = (-34).dp)
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(tint.copy(alpha = 0.45f), Color.Transparent),
                        radius = 190f
                    ),
                    androidx.compose.foundation.shape.CircleShape
                )
        )
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().clickable { onToggle() }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(38.dp).background(tint.copy(alpha = 0.32f), RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center
                ) { Text(icon, fontSize = 18.sp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = Muted, fontSize = 12.sp)
                }
                Text("›", color = tint, fontSize = 24.sp, modifier = Modifier.graphicsLayer { rotationZ = rot })
            }
            AnimatedVisibility(visible = expanded) {
                Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                    HorizontalDivider(color = Line, modifier = Modifier.padding(bottom = 14.dp))
                    content()
                }
            }
        }
    }
}
