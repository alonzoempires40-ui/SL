package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * First-run welcome. Shown once on a fresh install (no saved line yet), then never again — the
 * "setup done" flag is set as soon as a real connection succeeds. Purely a friendly front door:
 * the actual URL/MAC entry + test still happens on the existing Connect screen, so this can't
 * disturb auto-connect or the install-on-top identity.
 */
@Composable
fun WelcomeScreen(onStart: () -> Unit, onDemo: () -> Unit) {
    val accent = accentColor(Prefs.accent(LocalContext.current))
    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("StreamLine", color = accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Your TV line — live channels, movies, series and catch-up.",
                color = TextCol, fontSize = 15.sp)
            Spacer(Modifier.height(22.dp))

            listOf(
                "1" to "Have your portal URL and MAC ready (from your provider).",
                "2" to "Tap Set up my line and enter them — we'll test the connection.",
                "3" to "That's it. Your channels, guide and movies are ready."
            ).forEach { (n, t) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(26.dp).background(accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text(n, color = Color(0xFF1A1304), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(t, color = Muted, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(26.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF1A1304))) {
                Text("Set up my line", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = onDemo, modifier = Modifier.fillMaxWidth()) {
                Text("Just exploring — show me a demo", color = Muted, fontSize = 14.sp)
            }
        }
    }
}
