package com.streamline.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Nightly background EPG refresh — the app's "cron job".
 *
 * The portal only serves EPG going FORWARD and deletes past EPG server-side, so the only way to keep
 * a full 15-day catch-up guide is to harvest upcoming programmes before they air. That used to happen
 * only while the app was open; this worker does it automatically once overnight, whether or not the
 * app is launched, so the window stays full.
 *
 * It reuses the exact same headless login the connect screen uses (handshake -> getProfile -> doAuth),
 * rebuilt entirely from saved credentials, then runs the existing bulk sweep and persists the cache.
 *
 * HONEST LIMITS (Android, not us):
 *   - The OS batches background work, so it runs AROUND the target time, not exactly on it. Fine here.
 *   - Aggressive battery savers / "deep sleep" can delay or skip it; excluding the app from battery
 *     optimisation makes it reliable.
 *   - Needs a network connection at run time (the CONNECTED constraint waits for one).
 */
class EpgRefreshWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ctx = applicationContext
        // Not connected yet (fresh install / signed out) -> nothing to do, don't count as a failure.
        if (Prefs.activeUrl(ctx).isBlank()) return@withContext Result.success()
        try {
            EpgStore.loadNow(ctx)   // get the on-disk cache into memory before we harvest + flush

            // One fresh headless login + one EPG harvest (no catalog sweep — EPG only).
            fun freshClient() = StalkerClient(
                Prefs.activeUrl(ctx), Prefs.activeMac(ctx), Prefs.dev1(ctx), Prefs.dev2(ctx), Prefs.sig(ctx),
                Prefs.serial(ctx), Prefs.user(ctx), Prefs.pass(ctx), Prefs.model(ctx)
            ).also { it.handshake(); it.getProfile(); it.doAuth() }

            val client = freshClient()
            client.harvestEpgInfo(15)   // bulk forward sweep; merges into EpgStore internally
            EpgStore.flush()            // write the freshly-filled cache to disk

            Result.success()
        } catch (_: Throwable) {
            // Transient portal/network trouble — let WorkManager back off and try again later.
            Result.retry()
        }
    }

}

/** Schedules the nightly refresh. Call once on app start; it persists across reboots. */
object EpgScheduler {
    private const val WORK_NAME = "epg-nightly-refresh"
    private const val TARGET_HOUR = 2     // 2am — start of the quiet window; retries walk the night
    private const val TARGET_MINUTE = 0

    fun schedule(ctx: Context) {
        try {
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, TARGET_HOUR)
                set(Calendar.MINUTE, TARGET_MINUTE)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)  // next 2:00am
            }
            val initialDelayMs = next.timeInMillis - now.timeInMillis

            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<EpgRefreshWorker>(24, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setInitialDelay(initialDelayMs, TimeUnit.MILLISECONDS)
                .build()

            // KEEP: schedule once and let it run nightly; don't reset the timer on every app launch.
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        } catch (_: Throwable) { /* never let scheduling crash startup */ }
    }
}
