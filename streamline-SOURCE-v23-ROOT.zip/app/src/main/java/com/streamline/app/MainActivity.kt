package com.streamline.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

// A connected session (null = demo mode)
class Session(val client: StalkerClient?)

enum class ContentKind { VOD, SERIES }

// channel list carried into the player so up/down can zap (set when entering from a live list)
private var liveList: List<UiChannel> = emptyList()

sealed class Nav {
    object Welcome : Nav()
    object Connect : Nav()
    object Menu : Nav()
    object LiveCategories : Nav()
    data class Channels(val genreId: String? = null, val genreName: String? = null) : Nav()
    object VodCategories : Nav()
    data class VodList(val cat: Category, val back: Nav = VodCategories) : Nav()
    object SeriesCategories : Nav()
    data class SeriesList(val cat: Category) : Nav()
    object Radio : Nav()
    object Guide : Nav()
    data class Search(val initialQuery: String = "") : Nav()
    object Settings : Nav()
    object Account : Nav()
    object SpeedTest : Nav()
    data class Catchup(val channel: UiChannel, val from: Nav) : Nav()
    data class PlayArchive(val channel: UiChannel, val program: EpgProgram, val from: Nav) : Nav()
    data class Episodes(val series: UiMovie, val from: Nav) : Nav()
    data class MovieDetail(val movie: UiMovie, val from: Nav) : Nav()
    data class Play(val title: String, val number: Int, val movie: UiMovie?, val channel: UiChannel?, val from: Nav) : Nav()
    data class PlayEpisode(val ep: UiEpisode, val seriesName: String, val from: Nav, val episodes: List<UiEpisode> = emptyList(), val epIndex: Int = 0) : Nav()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // create this device's permanent identity on first launch (once, then never changes)
        Prefs.ensureDeviceIdentity(this)
        ConnectLog.init(this)
        ConnectLog.installCrashHandler(this)
        EpgStore.init(this)                 // load the persistent 2-week EPG cache
        EpgScheduler.schedule(this)         // schedule the nightly background EPG refresh (~2:00am)
        ChannelCache.init(this)             // on-disk channel-list cache (skip re-downloading 4.4 MB)
        setContent { App() }
    }

    override fun onPause() {
        super.onPause()
        EpgStore.flush()                    // persist the latest harvested EPG
    }

}

// Lets any screen's TopBar jump straight to the main menu without threading a lambda through
// every screen signature. Set once in App().
val LocalGoHome = androidx.compose.runtime.staticCompositionLocalOf<() -> Unit> { {} }

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var nav by remember { mutableStateOf<Nav>(if (Prefs.activeUrl(ctx).isBlank() && !Prefs.setupDone(ctx)) Nav.Welcome else Nav.Connect) }
    var session by remember { mutableStateOf(Session(null)) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accentColor(Prefs.accent(ctx)), background = Ink, surface = Panel,
            onBackground = TextCol, onSurface = TextCol
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            Box(Modifier.fillMaxSize()) {
                NavHost(nav = nav, session = session, setNav = { nav = it }, setSession = { session = it })
            }
        }
    }
}


private fun startupNav(ctx: android.content.Context): Nav = when (Prefs.startupScreen(ctx)) {
    "live" -> Nav.LiveCategories
    "movies" -> Nav.VodCategories
    "series" -> Nav.SeriesCategories
    else -> Nav.Menu
}

@Composable
fun NavHost(nav: Nav, session: Session, setNav: (Nav) -> Unit, setSession: (Session) -> Unit) {
  val ctx = androidx.compose.ui.platform.LocalContext.current
  // Auto-connect fires once per launch; disarmed after the first attempt (and not re-armed on a
  // manual disconnect → return to Connect), so disconnecting doesn't immediately reconnect.
  var autoConnectArmed by remember { mutableStateOf(true) }
  androidx.compose.runtime.CompositionLocalProvider(LocalGoHome provides { setNav(Nav.Menu) }) {
    when (val n = nav) {
        is Nav.Welcome -> WelcomeScreen(
            onStart = { setNav(Nav.Connect) },
            onDemo = { setSession(Session(null)); setNav(startupNav(ctx)) }
        )
        is Nav.Connect -> ConnectScreen(
            autoConnect = autoConnectArmed,
            onAutoConnectConsumed = { autoConnectArmed = false },
            onDemo = { setSession(Session(null)); setNav(startupNav(ctx)) },
            onConnected = { client ->
                setSession(Session(client)); Prefs.markSetupDone(ctx)
                setNav(startupNav(ctx))
            }
        )
        is Nav.Menu -> MenuScreen(
            session = session,
            demo = session.client == null,
            onOpen = { dest -> setNav(dest) }
        )
        is Nav.LiveCategories -> LiveCategoriesScreen(
            session = session,
            onOpen = { genreId, genreName -> setNav(Nav.Channels(genreId, genreName)) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.Channels -> ChannelsScreen(
            session = session,
            genreId = n.genreId,
            genreName = n.genreName,
            onPlay = { ch, all -> liveList = all; setNav(Nav.Play(ch.name, ch.number, null, ch, n)) },
            onCatchup = { ch -> setNav(Nav.Catchup(ch, n)) },
            onBack = { setNav(if (n.genreId != null) Nav.LiveCategories else Nav.Menu) }
        )
        is Nav.Catchup -> CatchupScreen(
            session = session,
            channel = n.channel,
            onPlayArchive = { program -> setNav(Nav.PlayArchive(n.channel, program, n)) },
            onBack = { setNav(n.from) }
        )
        is Nav.PlayArchive -> PlayerScreen(
            title = "${n.channel.name} — ${n.program.name}", number = n.channel.number,
            movie = null, channel = n.channel, session = session,
            archiveStartTs = n.program.startTs, archiveEndTs = n.program.endTs,
            archiveProgramId = n.program.id,
            onBack = { setNav(n.from) }
        )
        is Nav.VodCategories -> VideoClubScreen(
            session = session,
            onOpen = { m -> setNav(Nav.MovieDetail(m, n)) },
            onPlay = { m -> setNav(Nav.Play(m.name, 0, m, null, n)) },
            onOpenCategory = { cat -> setNav(Nav.VodList(cat)) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.VodList -> VodListScreen(
            session = session, category = n.cat, kind = ContentKind.VOD,
            onOpen = { m -> setNav(Nav.MovieDetail(m, n)) },
            onBack = { setNav(n.back) }
        )
        is Nav.SeriesCategories -> VideoClubScreen(
            session = session,
            onlySeries = true,
            onOpen = { m -> setNav(Nav.MovieDetail(m, n)) },
            onPlay = { m -> setNav(Nav.Play(m.name, 0, m, null, n)) },
            onOpenCategory = { cat -> setNav(Nav.VodList(cat, Nav.SeriesCategories)) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.SeriesList -> VodListScreen(
            session = session, category = n.cat, kind = ContentKind.SERIES,
            onOpen = { m -> setNav(Nav.MovieDetail(m, n)) },
            onBack = { setNav(Nav.SeriesCategories) }
        )
        is Nav.Radio -> RadioScreen(
            session = session,
            onPlay = { ch -> setNav(Nav.Play(ch.name, ch.number, null, ch, n)) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.Guide -> GuideScreen(
            session = session,
            onPlay = { ch, all -> liveList = all; setNav(Nav.Play(ch.name, ch.number, null, ch, n)) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.Search -> SearchScreen(
            session = session,
            initialQuery = n.initialQuery,
            onPlayChannel = { ch -> setNav(Nav.Play(ch.name, ch.number, null, ch, n)) },
            onOpenMovie = { m -> setNav(Nav.MovieDetail(m, n)) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.Settings -> SettingsScreen(
            session = session,
            onDisconnect = { setSession(Session(null)); setNav(Nav.Connect) },
            onReconnect = { autoConnectArmed = true; setSession(Session(null)); setNav(Nav.Connect) },
            onBack = { setNav(Nav.Menu) }
        )
        is Nav.Account -> AccountScreen(session = session, onBack = { setNav(Nav.Menu) })
        is Nav.SpeedTest -> SpeedTestScreen(session = session, onBack = { setNav(Nav.Menu) })
        is Nav.Episodes -> {
            EpisodesScreen(
                session = session, series = n.series,
                onPlay = { ep, list, idx -> setNav(Nav.PlayEpisode(ep, n.series.name, n, list, idx)) },
                onBack = { setNav(n.from) }
            )
        }
        is Nav.MovieDetail -> VideoDetailScreen(
            movie = n.movie,
            session = session,
            onPlay = {
                if (n.movie.seriesId != null) setNav(Nav.Episodes(n.movie, n))
                else setNav(Nav.Play(n.movie.name, 0, n.movie, null, n))
            },
            onOpenSeries = if (n.movie.seriesId != null) ({ setNav(Nav.Episodes(n.movie, n)) }) else null,
            onOpenMovie = { m -> setNav(Nav.MovieDetail(m, n)) },
            onBack = { setNav(n.from) }
        )
        is Nav.PlayEpisode -> {
            val epCtx = androidx.compose.ui.platform.LocalContext.current
            val epMovie = UiMovie(
                name = "${n.seriesName} — S${n.ep.season}E${n.ep.episode}",
                year = "", description = "",
                playUrl = n.ep.playUrl, cmd = n.ep.cmd
            )
            LaunchedEffect(epMovie.name) { Prefs.saveContinueWatched(epCtx, epMovie) }
            PlayerScreen(
                title = epMovie.name, number = 0, movie = epMovie, channel = null,
                session = session, episodeNumber = n.ep.episode,
                episodes = n.episodes, epIndex = n.epIndex,
                onPlayEpisode = { ep, idx -> setNav(Nav.PlayEpisode(ep, n.seriesName, n.from, n.episodes, idx)) },
                onBack = { setNav(n.from) }
            )
        }
        is Nav.Play -> {
            val playCtx = androidx.compose.ui.platform.LocalContext.current
            n.movie?.let { mv -> LaunchedEffect(mv.name) { Prefs.saveContinueWatched(playCtx, mv) } }
            PlayerScreen(
            title = n.title, number = n.number,
            movie = n.movie, channel = n.channel, session = session,
            liveList = if (n.channel != null) liveList else emptyList(),
            onZap = { ch -> setNav(Nav.Play(ch.name, ch.number, null, ch, n.from)) },
            onRestartProgramme = { prog -> n.channel?.let { setNav(Nav.PlayArchive(it, prog, n)) } },
            onBack = { setNav(n.from) }
        )
        }
    }
  }
}
