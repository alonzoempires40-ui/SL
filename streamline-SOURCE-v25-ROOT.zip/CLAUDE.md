# CLAUDE.md — StreamLine project brief

This file is the single source of truth for the project. It serves humans and AI assistants alike
(it is both `CLAUDE.md` and the project doc). Read it fully before changing anything.
Every fact below was verified against the tree at build 17 (full audit) and kept current through build 22.

## 1. What this is

**StreamLine** (`com.streamline.app`) — a Ministra/Stalker-portal IPTV client for Android TV,
stripped down from **OpenStream v340** (43 → 22 Kotlin files) and renamed. Target device:
Sony KD-70XF8305 (Android 9, arm64, 2 GB RAM), driven by remote (D-pad). The owner has no local
Android toolchain: **builds happen on GitHub Actions** (repo `OS-Small`) from a source ZIP.
Debug APK ≈ 109 MB single-ABI. The app is connected to a real portal and fully working
(live TV, VOD, series, guide, catch-up, radio, weather, PiP, sleep timer).

## 2. Ground rules (the working constitution)

1. **One purpose per build.** Numbered source zips `streamline-SOURCE-v{N}-ROOT.zip`, ROOT layout
   (`settings.gradle.kts` at the zip's top level — the CI unzip step requires it).
2. **Owner compiles (CI); the assistant has no compiler.** Hand-verify everything before shipping:
   balance, symbol resolution, imports, in-zip checks. State plainly what is UNVERIFIED.
3. **Every zip gets a fresh `versionCode`** and an updated `VERSION.txt` — even doc-only builds.
   (A stale VERSION.txt inside build 242 caused real confusion once.)
4. **Delete features completely**: code + nav + settings + manifest + deps. Then run the
   deleted-symbol export scan (rule 8) — a missed export (`SmoothSession`) once broke CI.
5. **Reference-first for any layout/UI change.** The pristine v340 tree (and the 242 zip) is the
   known-good reference. Diff against it, apply ONE stated delta. No experiment chains — four
   builds were once burned nudging spacers when the correct code sat in the reference.
6. **Move aside, never delete** when juggling backups; verify the destination before removing any
   copy (a sandbox reset once destroyed the only local tree).
7. **Brutal honesty** in VERSION.txt and replies: record mistakes, caveats, and what was NOT done.
8. **Verification battery per build** (see §9): kbalance 0/0 on all files, deleted-export scan,
   NEW-vs-pristine dead-import scan, in-zip verification of the exact shipped bytes.

## 3. Toolchain facts & DO-NOT-TOUCH list

| Item | Value | Why it must not change casually |
|---|---|---|
| Gradle | **8.11.1** (pinned in CI) | Runner default (9.x) is incompatible with AGP 8.9.2. Wrapper jar is absent by design; CI supplies Gradle. |
| AGP / Kotlin / JDK | 8.9.2 / 2.1.20 / 17 | Matched set; CI sets JDK 17 explicitly. |
| SDK | compileSdk 36, targetSdk 34, minSdk 28 | |
| ABI | **arm64-v8a only** | Build 8. Halved the APK (168→109 MB). 32-bit boxes out of scope. |
| `keyAlias = "openstream"` | **NEVER rename** | The alias is baked inside the binary `app/debug.keystore`; renaming breaks signing. NOTE: there are ~8 load-bearing "openstream" strings total (keystore alias; `Vault` key alias `openstream_vault_v1`; the prefs FILE name; three on-disk log/cache filenames; the EnvCheck prefs literal) — all keyed to existing installs' data, so none can change without a migration. Plus one cosmetic: Weather's User-Agent (fixed to "StreamLine" in build 19). |
| mpv | `dev.jdtech.mpv:libmpv:0.5.1` | 1.0.0 renames the whole MPVLib API (CI-verified breakage). Do not bump without a migration build. |
| Packaging | `pickFirsts += "**/libc++_shared.so"` | VLC and mpv both bundle it; without this the merge fails. |
| R8 | `isMinifyEnabled = false` (release block) | We build **assembleDebug**, so this flag does nothing today. Enabling R8 on debug = its own risky build (mpv JNI keep-rule exists in proguard-rules.pro but is unverified under minify). |

## 4. The three engines — DO NOT REMOVE ANY

| Engine | Handles | Why irreplaceable |
|---|---|---|
| ExoPlayer (media3 1.8.0) | HLS (`.m3u8`) | Standard adaptive streaming. |
| libVLC 3.7.0 | Greek-subtitle VOD; universal error fallback | Ships iconv; transcodes legacy Windows-1253 / ISO-8859-7 subs. **Exo cannot render this portal's embedded subs at all.** |
| libmpv 0.5.1 | MPEG-TS live | HW-decodes transport streams AND draws embedded subs where VLC's HW path can't. |

History: build 242 had only Exo+VLC and was ~100 MB smaller — libmpv **is** that 100 MB, added
deliberately for TS playback. The size is the price of the capability; the owner chose to keep it.
Router lives in `Player.kt` (`pickEngine`). Per-engine subtitle scaling (`subScaleFor`) stays in
Model — players read it — even though its settings UI was removed by owner request.

## 5. Build & CI (GitHub Actions)

Repo layout: the repo contains the **unextracted source ZIP** at its root (plus README and the
workflow). The workflow finds `settings.gradle.kts` anywhere, else unzips the newest `*.zip` into
`_src/` and builds there. Owner flow: replace the zip → Actions runs → download artifact
**StreamLine-debug-apk** (`StreamLine-v{N}.apk`) → sideload.

The proven `.github/workflows/build.yml` (recreate verbatim if ever lost — each element earned its
place through a CI failure: the setup-android action hangs on licenses and pulls a broken emulator,
hence the `yes | sdkmanager` line and no setup-android; Gradle is pinned; the locate step handles
the zip-in-repo layout):

```yaml
name: Build APK
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: "17" }
      - name: Accept Android SDK licenses (preinstalled SDK)
        run: yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
      - name: Set up Gradle 8.11.1 (matches AGP 8.9.2)
        uses: gradle/actions/setup-gradle@v4
        with: { gradle-version: "8.11.1" }
      - name: Locate or unzip the source
        id: locate
        run: |
          SETTINGS=$(find . -name settings.gradle.kts -not -path '*/build/*' -not -path './.git/*' | head -1)
          if [ -z "$SETTINGS" ]; then
            ZIP=$(ls -t *.zip 2>/dev/null | head -1)
            if [ -z "$ZIP" ]; then echo "::error::No settings.gradle.kts and no .zip in the repo."; exit 1; fi
            mkdir -p _src && unzip -q "$ZIP" -d _src
            SETTINGS=$(find _src -name settings.gradle.kts -not -path '*/build/*' | head -1)
          fi
          if [ -z "$SETTINGS" ]; then echo "::error::Zip extracted but no settings.gradle.kts inside."; exit 1; fi
          echo "dir=$(dirname "$SETTINGS")" >> "$GITHUB_OUTPUT"
      - name: Build debug APK
        working-directory: ${{ steps.locate.outputs.dir }}
        run: gradle assembleDebug --no-daemon --stacktrace
      - name: Show APK size
        run: |
          find . -name "*.apk" -path "*outputs*" -exec ls -lh {} \;
          find . -name "*.apk" -path "*outputs*" -exec stat -c '%s bytes  %n' {} \;
      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: StreamLine-debug-apk
          path: "**/outputs/apk/**/*.apk"
          if-no-files-found: error
```

## 6. Install & test notes

- The v7 rename made this a **new app** to Android. Coming from OpenStream:
  `adb uninstall com.openstream.app` once, then fresh-install. (Both apps can also coexist —
  useful for side-by-side comparison.)
- First launch: portal URL + the **same MAC** the provider whitelisted. Device model matters
  (MAG model picker in Connection settings).
- Playback test matrix after any engine/ABI/dep change: (1) a TS live channel → MPV badge;
  (2) a Greek-sub movie → VLC; (3) an HLS stream → Exo. Player top bar: 💤 sleep, PiP, CC.
- Weather: Settings → Appearance & weather → city → Save → card appears on the home menu
  (blank city hides it). Free Open-Meteo API, no key, no extra dependency.

## 7. Architecture map (22 files, verified line counts)

| File | LOC | Role |
|---|---|---|
| MainActivity.kt | 252 | Session state (null = demo), navigation host |
| Model.kt | 435 | `Prefs` (all persisted settings incl. sealed login via Vault), design tokens, UI models |
| Vault.kt | 105 | Seals portal credentials (MAC/serial/user/pass) in prefs |
| StalkerClient.kt | 1771 | The portal API client (handshake, channels, EPG, VOD, catch-up) |
| ConnectAndMenu.kt | 375 | Connect/login screen + the home menu (greeting, weather, 8 tiles) |
| BrowseScreens.kt | 631 | Live categories, channel list, VOD/series categories + poster grid |
| VideoClub.kt | 408 | VOD home: hero banner (featured), Continue-watching / My-list / category rails |
| Player.kt | 909 | Playback screen: engine router (`pickEngine`), Exo path, keys, PiP, sleep, tracks |
| VlcPlayer.kt | 168 | VLC engine controller |
| MpvPlayer.kt | 231 | mpv engine controller |
| Catchup.kt | 233 | Server-side catch-up archive browser (operator DVR — a KEEP feature) |
| EpgCache.kt | 194 | EPG store |
| EpgRefreshWorker.kt | 95 | Background EPG refresh (WorkManager) |
| EpgDetail.kt | 154 | Programme detail |
| MoreScreens.kt | 801 | Radio, TV Guide, Settings (5 cards), About/diagnostics |
| AccountScreens.kt | 159 | Account/subscription info |
| Weather.kt | 247 | Open-Meteo weather (`Weather` object + `WeatherCard`) — removed build 4, restored build 12 |
| ChannelCache.kt | 103 | Channel list cache |
| ConnectLog.kt | 185 | Connection diagnostics log |
| EnvCheck.kt | 74 | Environment sanity checks |
| Onboarding.kt | 66 | First-run onboarding |
| Polish.kt | 97 | `Modifier.tvFocus(shape, autoFocus)` (focus ring/scale/autofocus) + shared polish |

## 8. Decisions log (settled — do not relitigate silently)

- **All 3 engines stay** (owner, after the 242 comparison). PiP + sleep timer **kept**.
- **Weather** back in (build 12) — zero size cost, owner wants it.
- **Home menu layout = the 242/v340 original, verbatim** (build 16; diff-verified). The menu
  deliberately has **no auto-focus ring at open** (owner request; the original never had one).
  Other screens DO seed focus: channel list, both category lists, poster grid (4 seeds in
  BrowseScreens), hero Play button (VideoClub), portal-URL field on first-time setup only.
- **Group B dead accessors left in Model** (`addProfile, removeProfile, activeIsKids, saveMac,
  savePass, saveUser`) — dead in v340 too, near auth code, zero benefit to removing.
- **`UiMovie.portalTrailer` kept** — still populated by StalkerClient's parser; inert.
- Trailer-key accessors (`tmdbKey`) removed (build 6). Live-subs stack fully removed (build 5+7).

## 9. Verification toolkit — and its KNOWN FALSE POSITIVES

Run before shipping any build:
1. `python3 tools/kbalance.py app/src/main/java/com/streamline/app/*.kt` → must be 0/0 everywhere.
2. **Deleted-export scan**: for every top-level symbol of every deleted file (pristine v340 is the
   symbol source), grep the surviving tree. Must be zero. (The SmoothSession lesson.)
3. **NEW-vs-pristine dead-import scan** per edited file.
4. **In-zip verification**: after packaging, read the zip and assert the exact changes are inside.

False positives to expect (documented from the build-17 audit — do not "fix" these):
- `getValue`/`setValue` imports: used implicitly by `by remember` delegation.
- `Weather.kt`: `LazyRow`/`items` imports were unused in v340 too — left as-is on restore.
- Prefs resolution by regex: `var`-declared flags (`var adultUnlocked`) and digit-suffixed names
  (`dev1`, `dev2`) evade `fun X(` / `[a-zA-Z]+` patterns.
- `tvFocus` is a **Modifier extension** (`fun Modifier.tvFocus(`) — `fun tvFocus(` finds nothing.

## 10. Build history (condensed)

1 Cleo/voice-AI strip (Vault kept — seals login) · 2 Cast · 3 Reminders · 4 Weather+YouTube/
Trailers+Social/VPN · 5 Live subtitles (manifest → INTERNET-only) · 6 dead trailer-key accessors ·
7 **rename** OpenStream→StreamLine incl. package (fresh install; SmoothSession leak fixed after
first real CI compile) · 8 **single-ABI arm64** (168→109 MB) · 9 D-pad D1: list-screen focus
seeds · 10 menu-tile + login-field seeds · 11 hero Play focus (home) · 12 **weather restored** +
spacing · 13-15 tile-layout iterations (13 contentPadding, 14 revert, 15 centered) · 16 **menu
layout restored verbatim from the 242/v340 reference** (diff-proven; ring stays off) · 17 full
audit (zero defects) + this CLAUDE.md + tools/kbalance.py shipped in-repo ·
18 semantic fixes from the external review: ConnectLog redaction hardened (URL-encoded MAC +
device_id/signature/sn/prehash), real Active/Expired/Unknown account status + status-coloured row,
ChannelsScreen progress bar un-broken (startTs passed) · 19 remaining safe fixes: EPG harvest marks
done only on success; connect saves credentials only AFTER a successful auth; Nav.Catchup /
Nav.Episodes carry from-targets so Back returns where you came from; stale comments, Weather UA,
dead YouTube proguard keep, and this doc's "one openstream" claim corrected · 20 MAG-remote Player
D-pad: ☰ Menu toggles bar focus (amber ring, entry on the play/pause button), ℹ Info = programme
popup, CHAN± zap, 0-9 typed channel tuning, arrows/media keys unchanged · 21 D-pad complete: the
seven top-bar chips (Back / Next / sleep / home / CC / PiP / EPG) join the ring, auto-hide pauses
during bar focus, any hide path drops bar mode; engine badge deliberately touch-only · 22 this doc
sync (no code changes).

## 11. Known quirks & open items

- Home menu opens with **nothing focused** (by request). First D-pad press establishes focus; on
  some devices that press is consumed silently. Restore = pass `autoFocus = index == 0` at the
  `MenuTileCard` call in ConnectAndMenu.
- Hero Play may re-grab focus if the banner leaves and re-enters composition (LaunchedEffect
  re-runs on re-entry). Acceptable on TV; noted, not fixed.
- Cosmetic couch-spacing / EPG-grid polish: only on specific on-device feedback, one delta at a
  time from the reference (rule 5).
- Optional: R8-on-debug (own build; verify mpv keep-rules), CI native-lib size-breakdown step.

## 12. Build-17 audit record

Checks run on the full tree: balance 22/22 OK · deleted-export scan clean · all focus seeds match
design (4+1+1, menu 0) · weather wired end-to-end (4 prefs, all called) · manifest = INTERNET-only,
PiP flag present, no stray receivers/services · theme/label/app_name lockstep · gradle: single-ABI,
3 engines, pickFirst, keyAlias intact · every cross-file composable defined exactly once · zero new
dead imports vs pristine. **Result: zero code defects; three audit-regex artifacts documented in §9.**
