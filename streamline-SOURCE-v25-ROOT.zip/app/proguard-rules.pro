# StreamLine R8/ProGuard keep rules.
# These protect the parts of the app that obfuscation would otherwise break.
# Obfuscation is currently OFF (debug builds). When release minification is turned on,
# these rules let R8 shrink/obfuscate the rest while keeping the app working.

# ---- Kotlin / coroutines ----
-dontwarn kotlinx.**
-keep class kotlin.Metadata { *; }
-keepclassmembers class **$WhenMappings { <fields>; }

# ---- Jetpack Compose (reflection + runtime internals) ----
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

# ---- Our data models (parsed from/into JSON by field name — names must survive) ----
-keep class com.streamline.app.** { *; }

# ---- OkHttp / Okio (networking) ----
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }

# ---- org.json (portal JSON) ----
-keep class org.json.** { *; }

# ---- libVLC ----
-keep class org.videolan.** { *; }
-dontwarn org.videolan.**

# ---- Media3 / ExoPlayer ----
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# ---- Coil (image loading) ----
-keep class coil.** { *; }
-dontwarn coil.**

# ---- AndroidYouTubePlayer ----

# Keep line numbers for readable crash reports while obfuscating names
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# mpv (libmpv) is driven through JNI by class/method name — keep it intact for release builds.
-keep class dev.jdtech.mpv.** { *; }
