package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.system.measureTimeMillis

/* ---------------- Account ---------------- */

@Composable
fun AccountScreen(session: Session, onBack: () -> Unit) {
    BackHandler { onBack() }
    var info by remember { mutableStateOf<AccountInfo?>(null) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        info = withContext(Dispatchers.IO) {
            runCatching { session.client?.getAccountInfo() }.getOrNull()
        }
        loading = false
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Account", onBack)
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Amber) }
            else -> {
                val a = info
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel)
                ) {
                    val st = a?.status?.ifBlank { "Unknown" } ?: "Unknown"
                    val stColor = when (st) {
                        "Active" -> Color(0xFF36C98A)
                        "Expired" -> Color(0xFFE0554E)
                        else -> Color(0xFF9AA3B8)
                    }
                    InfoRow("Status", st, valueColor = stColor)
                    Divider()
                    InfoRow("Expires", a?.expires?.ifBlank { "—" } ?: "—")
                    if (!a?.tariff.isNullOrBlank()) { Divider(); InfoRow("Plan", a!!.tariff) }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Your server address and account ID are kept hidden for your privacy and aren't shown here.",
                    color = Muted, fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color = TextCol) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Muted, fontSize = 14.sp)
        Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Divider() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF232A44)))

/* ---------------- Speed Test ---------------- */

@Composable
fun SpeedTestScreen(session: Session, onBack: () -> Unit) {
    BackHandler { onBack() }
    var running by remember { mutableStateOf(false) }
    var downMbps by remember { mutableStateOf<Double?>(null) }
    var pingMs by remember { mutableStateOf<Long?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var scope = androidx.compose.runtime.rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Speed Test", onBack)
        Column(
            Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(30.dp))
            Text(
                if (running) "Testing…" else "Check your connection speed",
                color = Muted, fontSize = 14.sp
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "Start test",
                color = if (running) Muted else Color(0xFF1A1300),
                fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .background(if (running) Panel else Amber, RoundedCornerShape(12.dp))
                    .clickable(enabled = !running) {
                        running = true; err = null; downMbps = null; pingMs = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { runSpeedTest(session) }
                            running = false
                            r.fold(
                                onSuccess = { (d, p) -> downMbps = d; pingMs = p },
                                onFailure = { err = "Couldn't run the test — check your connection." }
                            )
                        }
                    }
                    .padding(horizontal = 44.dp, vertical = 14.dp)
            )
            Spacer(Modifier.height(34.dp))
            if (err != null) {
                Text(err!!, color = ErrCol, fontSize = 13.sp)
            } else if (downMbps != null || pingMs != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(50.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(downMbps?.let { String.format("%.1f", it) } ?: "—",
                            color = Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Mbps down", color = Muted, fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(pingMs?.toString() ?: "—",
                            color = Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text("ms ping", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Measures your connection generally — not a promise about any single stream.",
                color = Muted, fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }
    }
}

/**
 * Lightweight speed test: pings the portal host for latency, then times a download of a known
 * resource to estimate throughput. Uses the portal's own server so it reflects the path that
 * actually matters for streaming. Returns (downMbps, pingMs).
 */
private suspend fun runSpeedTest(session: Session): Result<Pair<Double, Long>> = runCatching {
    val client = session.client ?: throw RuntimeException("not connected")
    // Use the SAME authenticated client/headers that successfully load channels. The old
    // version opened a raw HttpURLConnection to a portal directory with no UA/cookie/auth,
    // which the portal rejected — so the test always failed.
    val ping = client.pingPortal()
    val (bytes, ms) = client.speedSample()
    if (bytes <= 0L) throw RuntimeException("no data from portal")
    val seconds = (ms.coerceAtLeast(1)) / 1000.0
    val mbps = (bytes * 8.0 / 1_000_000.0) / seconds
    Pair(mbps, ping)
}
