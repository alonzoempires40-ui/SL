package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed as itemsIndexedGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------- shared bits ----------
@Composable
fun TopBar(title: String, onBack: () -> Unit, onHome: (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null) {
    val goHome = onHome ?: LocalGoHome.current
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        // Clear, tappable Back chip — every screen has an obvious way out.
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onBack() }
                .background(Panel, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 7.dp)
        ) {
            Text("‹", color = Amber, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(4.dp))
            Text("Back", color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.width(12.dp))
        Text(title, color = TextCol, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.weight(1f))
        if (trailing != null) { trailing(); Spacer(Modifier.width(10.dp)) }
        // Home button — jump straight back to the main menu from anywhere.
        Text("🏠", fontSize = 16.sp,
            modifier = Modifier.clickable { goHome() }
                .background(Panel, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 7.dp))
    }
}

@Composable
fun LoadingBox() = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Amber) }

/** Sort options for content lists. `sortby` maps to the portal's get_ordered_list sort key. */
enum class SortKey(val label: String, val sortby: String) {
    ADDED("Newest", "added"),
    NAME_AZ("A → Z", "name"),
    NAME_ZA("Z → A", "name"),
    YEAR("Year", "year"),
    NUMBER("Channel #", "number")
}

/** A search box + a row of sort chips, shared by the Live TV, Movies and Series lists. */
@Composable
fun FilterSortBar(
    query: String,
    onQuery: (String) -> Unit,
    sort: SortKey,
    onSort: (SortKey) -> Unit,
    sortOptions: List<SortKey> = SortKey.values().toList(),
    placeholder: String = "Search by name"
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            placeholder = { Text(placeholder, color = Muted, fontSize = 14.sp) },
            leadingIcon = { Text("🔍", fontSize = 14.sp) },
            trailingIcon = {
                if (query.isNotBlank())
                    Text("✕", color = Muted, fontSize = 15.sp,
                        modifier = Modifier.clickable { onQuery("") }.padding(10.dp))
            },
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Sort:", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp, end = 2.dp))
            sortOptions.forEach { opt ->
                val sel = opt == sort
                Text(
                    opt.label,
                    color = if (sel) Color(0xFF1A1300) else Muted,
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .background(if (sel) Amber else Panel, RoundedCornerShape(9.dp))
                        .clickable { onSort(opt) }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }
        }
    }
}

/** Apply a SortKey to an in-memory list of movies (final, display-time ordering). */
fun List<UiMovie>.sortedByKey(key: SortKey): List<UiMovie> = when (key) {
    SortKey.NAME_AZ -> sortedBy { it.name.lowercase() }
    SortKey.NAME_ZA -> sortedByDescending { it.name.lowercase() }
    SortKey.YEAR -> sortedByDescending { it.year.toIntOrNull() ?: 0 }
    SortKey.ADDED -> sortedByDescending { it.added }
    SortKey.NUMBER -> this
}

@Composable
fun MessageBox(msg: String) = Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
    Text(msg, color = if (msg.startsWith("No ")) Muted else ErrCol, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
}

// ---------- channels with EPG preview + favorites ----------
@Composable
fun ChannelsScreen(
    session: Session,
    genreId: String? = null,
    genreName: String? = null,
    onPlay: (UiChannel, List<UiChannel>) -> Unit,
    onCatchup: (UiChannel) -> Unit = {},
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    var state by remember { mutableStateOf<List<UiChannel>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf<Int?>(null) }
    var epg by remember { mutableStateOf<List<UiEpg>>(emptyList()) }
    var showFavs by remember { mutableStateOf(false) }
    var favTick by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(SortKey.NUMBER) }

    LaunchedEffect(genreId) {
        if (session.client == null) {
            // demo: filter is cosmetic, show all demo channels
            state = demoChannels; return@LaunchedEffect
        }
        try {
            state = withContext(Dispatchers.IO) {
                val c = session.client
                val genres = runCatching { c.getGenres().toMap() }.getOrDefault(emptyMap())
                c.getAllChannels()
                    .filter { genreId == null || genreId == "*" || it.genreId == genreId }   // "*" = All (show everything)
                    .map { pc ->
                        UiChannel(pc.number, pc.name,
                            genres[pc.genreId]?.let { "Live · $it" } ?: "Live",
                            logo = pc.logo, cmd = pc.cmd, id = pc.id, archive = pc.archive)
                    }
            }
        } catch (e: Exception) { error = e.message ?: "Could not load channels" }
    }

    // load EPG when a channel is expanded
    LaunchedEffect(expanded) {
        val all = state ?: return@LaunchedEffect
        val sel = all.firstOrNull { it.number == expanded } ?: return@LaunchedEffect
        // debounce: this effect cancels/restarts whenever the expanded channel changes, so a short
        // wait here means only the channel left open ~¼s actually calls the portal — tapping quickly
        // down the list no longer fires a request per channel.
        kotlinx.coroutines.delay(250)
        epg = if (session.client == null) demoEpg[sel.number] ?: emptyList()
        else withContext(Dispatchers.IO) {
            runCatching {
                val id = sel.id.orEmpty()
                if (id.isBlank()) emptyList()
                else session.client.getShortEpg(id).map { p ->
                    // show HH:MM, formatted from the absolute timestamp (was mangling t_time to "PM")
                    val clock = epgClock(p)
                    val now = p.startTs <= (System.currentTimeMillis() / 1000) &&
                        (System.currentTimeMillis() / 1000) < p.endTs
                    UiEpg(p.name, clock, now, p.startTs)
                }
            }.getOrDefault(emptyList())
        }
    }

    val favs = remember(favTick) { Prefs.favs(ctx) }
    val shown = remember(state, showFavs, favTick, query, sort) {
        var base = state ?: emptyList()
        if (showFavs) base = base.filter { favs.contains(it.number) }
        val q = query.trim()
        if (q.isNotBlank()) base = base.filter { it.name.contains(q, true) }
        base = when (sort) {
            SortKey.NAME_AZ -> base.sortedBy { it.name.lowercase() }
            SortKey.NAME_ZA -> base.sortedByDescending { it.name.lowercase() }
            else -> base.sortedBy { it.number }   // NUMBER / natural channel order
        }
        base
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar(genreName ?: (if (session.client == null) "Demo channels" else "Live TV"), onBack) {
            Text(if (showFavs) "★ Favorites" else "☆ All", color = Amber, fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { showFavs = !showFavs }
                    .background(Panel, RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 6.dp))
        }
        if (!state.isNullOrEmpty()) FilterSortBar(
            query = query, onQuery = { query = it },
            sort = sort, onSort = { sort = it },
            sortOptions = listOf(SortKey.NUMBER, SortKey.NAME_AZ, SortKey.NAME_ZA),
            placeholder = "Search channels"
        )
        when {
            error != null -> EmptyState("⚠", "Couldn't load channels", error, isError = true)
            state == null -> Column { repeat(6) { SkeletonBox(Modifier.fillMaxWidth().height(72.dp).padding(vertical = 5.dp)) } }
            shown.isEmpty() -> EmptyState(if (showFavs) "★" else "📺", if (showFavs) "No favorites yet" else "No channels", if (showFavs) "Tap the star on a channel to add it here." else "Your provider hasn't shared any channels.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(shown) { index, ch ->
                    ChannelCard(
                        ch = ch,
                        isFav = favs.contains(ch.number),
                        isExpanded = expanded == ch.number,
                        epg = if (expanded == ch.number) epg else emptyList(),
                        onSelect = { expanded = if (expanded == ch.number) null else ch.number },
                        onPlay = { onPlay(ch, shown) },
                        onFav = { Prefs.toggleFav(ctx, ch.number); favTick++ },
                        onCatchup = { onCatchup(ch) },
                        autoFocus = index == 0
                    )
                }
            }
        }
    }
}

// ---------- Live TV categories (genres) — shown first, like Movies/Series ----------
@Composable
fun LiveCategoriesScreen(
    session: Session,
    onOpen: (String?, String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var state by remember { mutableStateOf<List<Category>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var pinTarget by remember { mutableStateOf<Pair<String?, String>?>(null) }

    LaunchedEffect(Unit) {
        if (session.client == null) {
            state = listOf(Category("demo", "Demo channels")); return@LaunchedEffect
        }
        try {
            val c = session.client
            state = withContext(Dispatchers.IO) {
                c!!.getGenreCats()
            }
        } catch (e: Exception) { error = e.message ?: "Couldn't load categories" }
    }

    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar(if (session.client == null) "Demo channels" else "Live TV", onBack)
        Spacer(Modifier.height(8.dp))
        when {
            error != null -> MessageBox(error!!)
            state == null -> LoadingBox()
            state!!.isEmpty() -> MessageBox("No channel categories from the portal.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // The portal already includes an "All" category, so we don't add our own
                // "All channels" shortcut — that was a duplicate.
                itemsIndexed(state!!) { index, cat ->
                    val locked = Prefs.adultLocked(ctx) && Prefs.isAdultCat(cat.title, cat.censored)
                    Row(Modifier.fillMaxWidth()
                        .tvFocus(RoundedCornerShape(14.dp), index == 0)
                        .background(Panel, RoundedCornerShape(14.dp))
                        .clickable { if (locked) pinTarget = cat.id to cat.title else onOpen(cat.id, cat.title) }.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(cat.title, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(if (locked) "🔒" else "›", color = Amber, fontSize = if (locked) 18.sp else 22.sp)
                    }
                }
            }
        }
        pinTarget?.let { (id, title) -> AdultLockDialog(onDismiss = { pinTarget = null }, onUnlocked = { pinTarget = null; onOpen(id, title) }) }
    }
}

@Composable
fun ChannelCard(
    ch: UiChannel, isFav: Boolean, isExpanded: Boolean, epg: List<UiEpg>,
    onSelect: () -> Unit, onPlay: () -> Unit, onFav: () -> Unit, onCatchup: () -> Unit = {}, autoFocus: Boolean = false
) {
    Column(
        Modifier.fillMaxWidth()
            .tvFocus(RoundedCornerShape(14.dp), autoFocus)
            .background(Panel, RoundedCornerShape(14.dp))
            .border(if (isExpanded) 1.dp else 0.dp, if (isExpanded) Amber else Color.Transparent, RoundedCornerShape(14.dp))
            .clickable { onSelect() }.padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Channel number is always shown (small, left) even when the channel has a logo.
            Text(ch.number.toString(), color = Amber, fontFamily = FontFamily.Monospace,
                fontSize = 12.sp, modifier = Modifier.widthIn(min = 30.dp))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                if (!ch.logo.isNullOrBlank())
                    AsyncImage(model = ch.logo, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                else Text(ch.number.toString(), color = Amber, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(ch.name, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(ch.info, color = Muted, fontSize = 13.sp)
            }
            Text(if (isFav) "★" else "☆", color = Amber, fontSize = 20.sp,
                modifier = Modifier.clickable { onFav() }.padding(horizontal = 8.dp))
            Text("▶", color = Amber, fontSize = 18.sp,
                modifier = Modifier.clickable { onPlay() }.padding(start = 4.dp))
        }
        if (isExpanded) {
            Spacer(Modifier.height(10.dp))
            if (epg.isEmpty())
                Text("No programme info available.", color = Muted, fontSize = 12.sp)
            else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                epg.forEach { p ->
                    Row {
                        Text(if (p.isNow) "● " else "   ", color = Amber, fontSize = 12.sp)
                        Text(p.time, color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(110.dp))
                        Text(p.name, color = if (p.isNow) TextCol else Muted, fontSize = 12.sp)
                    }
                }
            }
            // Amber progress bar for the current programme (how far along it is), like the TV Guide.
            // End time = the next programme's start; only shown when both timestamps are known.
            val nowIdx = epg.indexOfFirst { it.isNow }
            if (nowIdx >= 0 && epg[nowIdx].startTs > 0L) {
                val startTs = epg[nowIdx].startTs
                val endTs = epg.getOrNull(nowIdx + 1)?.startTs ?: 0L
                if (endTs > startTs) {
                    val frac = ((System.currentTimeMillis() / 1000 - startTs).toFloat() / (endTs - startTs).toFloat()).coerceIn(0f, 1f)
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Panel2)) {
                        Box(Modifier.fillMaxWidth(frac).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Amber))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                    Text("▶ Watch now", fontWeight = FontWeight.SemiBold)
                }
                // Catch-up only appears on channels the provider records.
                if (ch.archive) {
                    Button(onClick = onCatchup, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)) {
                        Text("🗓 Catch-up", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

// ---------- categories (shared by VOD & Series) ----------
@Composable
private fun CategoriesScreen(
    title: String, load: suspend () -> List<Category>, demoCats: List<Category>,
    isDemo: Boolean, onOpen: (Category) -> Unit, onBack: () -> Unit
) {
    BackHandler { onBack() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var state by remember { mutableStateOf<List<Category>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var pinTarget by remember { mutableStateOf<Category?>(null) }
    LaunchedEffect(Unit) {
        if (isDemo) { state = demoCats; return@LaunchedEffect }
        try { state = withContext(Dispatchers.IO) { load() } }
        catch (e: Exception) { error = e.message ?: "Could not load categories" }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar(title, onBack)
        when {
            error != null -> MessageBox(error!!)
            state == null -> LoadingBox()
            state!!.isEmpty() -> MessageBox("No categories returned by the portal.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(state!!) { index, cat ->
                    val locked = Prefs.adultLocked(ctx) && Prefs.isAdultCat(cat.title, cat.censored)
                    Row(Modifier.fillMaxWidth()
                        .tvFocus(RoundedCornerShape(14.dp), index == 0)
                        .background(Panel, RoundedCornerShape(14.dp))
                        .clickable { if (locked) pinTarget = cat else onOpen(cat) }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(cat.title, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(if (locked) "🔒" else "›", color = Amber, fontSize = if (locked) 18.sp else 22.sp)
                    }
                }
            }
        }
        pinTarget?.let { cat -> AdultLockDialog(onDismiss = { pinTarget = null }, onUnlocked = { pinTarget = null; onOpen(cat) }) }
    }
}

@Composable
fun VodCategoriesScreen(session: Session, onOpen: (Category) -> Unit, onBack: () -> Unit) =
    CategoriesScreen("Movies & Series", { session.client!!.getVodCategories().filter { it.id != "*" }.map { Category(it.id, it.title, it.censored) } },
        listOf(Category("demo", "Demo movies")), session.client == null, onOpen, onBack)

@Composable
fun SeriesCategoriesScreen(session: Session, onOpen: (Category) -> Unit, onBack: () -> Unit) =
    CategoriesScreen("Series", { session.client!!.getSeriesCats() },
        listOf(Category("demo", "Demo series")), session.client == null, onOpen, onBack)

// ---------- VOD/Series list (poster grid) ----------
@Composable
fun VodListScreen(session: Session, category: Category, kind: ContentKind, onOpen: (UiMovie) -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // State is keyed on category.id so it resets cleanly when you open a different category.
    var items by remember(category.id) { mutableStateOf<List<UiMovie>?>(null) }
    var total by remember(category.id) { mutableStateOf(0) }
    var loadedPage by remember(category.id) { mutableStateOf(0) }
    var wantPage by remember(category.id) { mutableStateOf(1) }   // bumped by "Load more"
    var loadingMore by remember(category.id) { mutableStateOf(false) }
    var error by remember(category.id) { mutableStateOf<String?>(null) }
    var sort by remember(category.id) { mutableStateOf(SortKey.ADDED) }
    var query by remember(category.id) { mutableStateOf("") }
    var committedQuery by remember(category.id) { mutableStateOf("") }
    var loadedKey by remember(category.id) { mutableStateOf("") }   // category|sort|search of loaded data
    val gridState = rememberLazyGridState()

    fun mapItems(raw: List<PortalMovie>) = raw.map { pm ->
        UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
            listOfNotNull(pm.year.ifBlank { null }, pm.director.ifBlank { null }).joinToString(" · "),
            cmd = pm.cmd,
            portalTrailer = pm.trailer.ifBlank { null },
            // A VOD item flagged is_series (or anything from the Series menu) routes to episodes.
            seriesId = if (kind == ContentKind.SERIES || pm.isSeries) pm.id else null,
            added = pm.added, actors = pm.actors, director = pm.director, categoryId = category.id)
    }

    // Debounce the search box: commit the query a beat after typing stops, so we don't refetch
    // on every keystroke.
    LaunchedEffect(query) {
        kotlinx.coroutines.delay(350)
        committedQuery = query.trim()
    }

    // Infinite scroll: when the last visible cell gets within a few rows of the end, pull the
    // next page automatically (no button press). Guarded so it requests one page at a time.
    LaunchedEffect(gridState, category.id) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
            .collect { lastVisible ->
                val loaded = items?.size ?: 0
                if (kind != ContentKind.SERIES && loaded in 1 until total &&
                    !loadingMore && wantPage <= loadedPage && lastVisible >= loaded - 6) {
                    wantPage += 1
                }
            }
    }

    LaunchedEffect(category.id, sort, committedQuery, wantPage) {
        val client = session.client
        if (client == null) {
            if (items == null) items = if (kind == ContentKind.SERIES) demoSeries else demoMovies
            loadedKey = "${category.id}|${sort.sortby}|$committedQuery"; return@LaunchedEffect
        }
        // A change of sort or search is a "fresh" context → reload from page 1; otherwise it's a
        // paging request for the same context.
        val key = "${category.id}|${sort.sortby}|$committedQuery"
        val fresh = key != loadedKey
        if (!fresh && wantPage <= loadedPage) return@LaunchedEffect
        if (fresh) error = null else loadingMore = true
        try {
            if (kind == ContentKind.SERIES) {
                // Series come as one list; search/sort are applied client-side at display time.
                val raw = withContext(Dispatchers.IO) { client.getSeriesList(category.id) }
                items = mapItems(raw); total = raw.size; loadedPage = 1; loadedKey = key
            } else {
                val pageToFetch = if (fresh) 1 else wantPage
                val allowAdult = !Prefs.adultLocked(ctx)
                val pg = withContext(Dispatchers.IO) { client.getVodPage(category.id, pageToFetch, sort.sortby, committedQuery, allowAdult) }
                items = (if (fresh) emptyList() else (items ?: emptyList())) + mapItems(pg.items)
                total = pg.total; loadedPage = pageToFetch; loadedKey = key
                if (fresh && wantPage != 1) wantPage = 1
            }
        } catch (e: Exception) { if (fresh) error = e.message ?: "Could not load titles" }
        loadingMore = false
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar(category.title, onBack)
        FilterSortBar(
            query = query, onQuery = { query = it },
            sort = sort, onSort = { sort = it },
            sortOptions = listOf(SortKey.ADDED, SortKey.NAME_AZ, SortKey.NAME_ZA, SortKey.YEAR),
            placeholder = if (kind == ContentKind.SERIES) "Search series" else "Search movies"
        )
        val list = items
        val shown = remember(list, sort, committedQuery) {
            var l = list ?: emptyList()
            if (committedQuery.isNotBlank()) l = l.filter { it.name.contains(committedQuery, true) }
            l.sortedByKey(sort)
        }
        when {
            error != null -> MessageBox(error!!)
            list == null -> LoadingBox()
            shown.isEmpty() -> MessageBox(
                if (committedQuery.isNotBlank()) "No titles match \"$committedQuery\"." else "No titles in this category."
            )
            else -> LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(minSize = 140.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexedGrid(shown) { index, m -> PosterCard(m, onOpen, autoFocus = index == 0) }
                if ((list?.size ?: 0) < total && kind != ContentKind.SERIES) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Box(Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                            if (loadingMore) Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(color = Amber, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Loading…  (${list?.size ?: 0} / $total)", color = Muted, fontSize = 12.sp)
                            }
                            // Fallback tap target in case auto-scroll doesn't fire on a given device.
                            else Button(
                                onClick = { if (!loadingMore && (list?.size ?: 0) < total) wantPage += 1 },
                                colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = TextCol)
                            ) { Text("Load more  (${list?.size ?: 0} / $total)") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PosterCard(m: UiMovie, onOpen: (UiMovie) -> Unit, autoFocus: Boolean = false) {
    Column(Modifier.tvFocus(RoundedCornerShape(12.dp), autoFocus).clickable { onOpen(m) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(12.dp))
            .background(Panel2).border(1.dp, Line, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            if (!m.poster.isNullOrBlank())
                AsyncImage(model = m.poster, contentDescription = m.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text(m.name, color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(8.dp))
        }
        Text(m.name, color = TextCol, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
        if (m.year.isNotBlank()) Text(m.year, color = Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

// ---------- movie/series detail ----------
@Composable
fun MovieDetailScreen(movie: UiMovie, onPlay: () -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Details", onBack)
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(150.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(12.dp))
                .background(Panel2).border(1.dp, Line, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                if (!movie.poster.isNullOrBlank())
                    AsyncImage(model = movie.poster, contentDescription = movie.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(movie.name, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(8.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(movie.name, color = TextCol, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (movie.meta.isNotBlank())
                    Text(movie.meta, color = Muted, fontSize = 13.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(12.dp))
                Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                    Text("▶ Play", fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        if (movie.description.isNotBlank())
            Text(movie.description, color = Color(0xFFC6CCDB), fontSize = 14.sp, lineHeight = 21.sp)
        else Text("No description available.", color = Muted, fontSize = 13.sp)
    }
}

// Parental lock prompt — shown when a locked adult category is tapped while a PIN is set.
// Correct PIN unlocks adult sections for the rest of the app session (until restart).
@Composable
private fun AdultLockDialog(onDismiss: () -> Unit, onUnlocked: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val accent = accentColor(Prefs.accent(ctx))
    var pinEntry by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                if (pinEntry == Prefs.pin(ctx)) { Prefs.adultUnlocked = true; onUnlocked() } else pinError = true
            }) { Text("Unlock", color = accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } },
        title = { Text("Locked", color = TextCol) },
        text = {
            Column {
                Text("This section is protected. Enter your parental PIN.", color = Muted, fontSize = 13.sp)
                OutlinedTextField(
                    value = pinEntry,
                    onValueChange = { pinEntry = it.filter { c -> c.isDigit() }.take(6); pinError = false },
                    label = { Text("PIN") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = fieldColors()
                )
                if (pinError) Text("Incorrect PIN", color = ErrCol, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        },
        containerColor = Panel
    )
}
