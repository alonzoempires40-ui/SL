package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * Catch-up: pick a day this channel has stored, see that day's programmes, replay any that
 * have archive available. Days back are limited by the channel's archive duration.
 */
@Composable
fun CatchupScreen(
    session: Session,
    channel: UiChannel,
    onPlayArchive: (program: EpgProgram) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    // The portal keeps its own clock (Stalker timezone), which can differ from the phone's. Detect
    // its UTC offset once so the day tabs and the per-day query line up with the server's day
    // boundaries — exactly what a real MAG box shows. Until detected, fall back to the device offset
    // so the first paint matches the phone, then it snaps to the portal's clock.
    val deviceOffsetSec = remember { java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 1000 }
    var offsetSec by remember(channel) { mutableStateOf<Int?>(null) }
    val days = remember(channel, offsetSec) { buildDayList(daysBack = 14, serverOffsetSec = offsetSec ?: deviceOffsetSec) }
    var selected by remember { mutableStateOf(0) }
    var dayUi by remember { mutableStateOf<DayUi>(DayUi.Loading) }

    LaunchedEffect(channel) {
        val chId = channel.id ?: return@LaunchedEffect
        if (chId.isBlank()) return@LaunchedEffect
        offsetSec = withContext(Dispatchers.IO) {
            runCatching { session.client?.serverUtcOffsetSeconds(chId) }.getOrNull()
        }
    }

    LaunchedEffect(selected, offsetSec) {
        dayUi = DayUi.Loading
        val chId = channel.id
        if (chId.isNullOrBlank()) { dayUi = DayUi.Error("No guide for this channel"); return@LaunchedEffect }
        val day = days.getOrNull(selected) ?: return@LaunchedEffect   // guard any index race
        val result = withContext(Dispatchers.IO) {
            runCatching { session.client?.getEpgForDay(chId, day.apiDate, day.startSec, day.endSec) ?: emptyList() }
        }
        dayUi = result.fold(
            onSuccess = { DayUi.Ready(it) },
            onFailure = { DayUi.Error("Couldn't load this day's guide") }
        )
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("${channel.name} — Catch-up", onBack)
        // Day picker
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            days.forEachIndexed { i, d ->
                val sel = i == selected
                Text(
                    d.label,
                    color = if (sel) Color(0xFF1A1300) else Muted,
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .background(if (sel) Amber else Panel, RoundedCornerShape(10.dp))
                        .clickable { selected = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        // One atomic UI state (Loading / Error / Ready) instead of two nullable vars. The original
        // crash was a LazyColumn whose items() read a nullable `programs` state that flipped to null
        // mid-render (during Compose's apply pass) -> NPE. With a single sealed state captured into a
        // `val`, and the list living inside Ready (never null), that class of crash can't happen.
        when (val ui = dayUi) {
            is DayUi.Error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(ui.msg, color = Muted, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            }
            DayUi.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Amber)
            }
            is DayUi.Ready -> {
                val progs = ui.progs
                if (progs.isEmpty()) {
                    // This portal serves no per-day programme guide (get_simple_data_table = false for
                    // past dates). The recordings still exist on the Flussonic DVR, so offer a time
                    // scrubber: tap an hour and play straight from the archive by timestamp.
                    val day = days.getOrNull(selected)
                    val dayStart = day?.startSec ?: 0L
                    val nowSec = System.currentTimeMillis() / 1000
                    val hours = if (dayStart > 0) (0..23).map { dayStart + it * 3600L }.filter { it < nowSec } else emptyList()
                    if (hours.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No catch-up available for this day.", color = Muted, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            item {
                                Text(
                                    "No programme guide for this day — pick a time to play from the recording:",
                                    color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(bottom = 14.dp)
                                )
                            }
                            items(hours.chunked(4)) { row ->
                                Row(
                                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    for (ts in row) {
                                        val h = ((ts - dayStart) / 3600L).toInt()
                                        Text(
                                            "%02d:00".format(h),
                                            color = Color(0xFFF8CD78),
                                            fontSize = 15.sp, fontFamily = FontFamily.Monospace,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier
                                                .weight(1f)
                                                .background(Panel, RoundedCornerShape(10.dp))
                                                .clickable {
                                                    onPlayArchive(
                                                        EpgProgram(
                                                            name = "${channel.name} · %02d:00".format(h),
                                                            start = "%02d:00".format(h), end = "",
                                                            startTs = ts, endTs = ts + 3600L,
                                                            desc = "", id = "", hasArchive = true
                                                        )
                                                    )
                                                }
                                                .padding(vertical = 14.dp)
                                        )
                                    }
                                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        items(progs) { p ->
                            val playable = p.hasArchive && p.startTs > 0
                            Row(
                                Modifier.fillMaxWidth()
                                    .then(if (playable) Modifier.clickable { onPlayArchive(p) } else Modifier)
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    epgClock(p),
                                    color = if (playable) Color(0xFFF8CD78) else Muted,
                                    fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                                    maxLines = 1, softWrap = false,
                                    modifier = Modifier.width(60.dp)
                                )
                                Text(
                                    p.name,
                                    color = if (playable) TextCol else Muted,
                                    fontSize = 14.sp, modifier = Modifier.weight(1f)
                                )
                                if (playable) Text("▶", color = Amber, fontSize = 18.sp)
                                else Text("·", color = Muted, fontSize = 14.sp)
                            }
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1C2238)))
                        }
                    }
                }
            }
        }
    }
}

// One atomic catch-up screen state. Collapsing the old (programs: List?, error: String?) pair into a
// single sealed value means there is never a nullable list for a LazyColumn to read mid-render, which
// is what produced the Catchup.kt items() NPE. The list lives only inside Ready and is non-null.
private sealed interface DayUi {
    object Loading : DayUi
    data class Error(val msg: String) : DayUi
    data class Ready(val progs: List<EpgProgram>) : DayUi
}

// Shared by CatchupScreen and GuideScreen.
data class DayItem(val label: String, val apiDate: String, val startSec: Long, val endSec: Long)

fun buildDayList(daysBack: Int, serverOffsetSec: Int, daysForward: Int = 0): List<DayItem> {
    val out = mutableListOf<DayItem>()
    // Work on the portal's wall clock: take a UTC calendar and shift it by the server offset, so its
    // fields read the server's local date/time. Snap to midnight to get each server-local day, format
    // the date string for the query, and convert that server-local midnight back to a real UTC instant
    // for the [start,end) timestamp window used to bucket programmes.
    val utc = java.util.TimeZone.getTimeZone("UTC")
    val api = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = utc }
    val nice = SimpleDateFormat("EEE d", Locale.getDefault()).apply { timeZone = utc }
    val cal = Calendar.getInstance(utc).apply {
        timeInMillis = System.currentTimeMillis() + serverOffsetSec * 1000L  // server wall-clock now
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)               // server-local midnight
    }
    val count = if (daysForward > 0) daysForward else daysBack
    val step = if (daysForward > 0) 1 else -1
    for (i in 0..count) {
        val label = when (i) {
            0 -> "Today"
            1 -> if (daysForward > 0) "Tomorrow" else "Yesterday"
            else -> nice.format(cal.time)
        }
        // cal.timeInMillis is the instant that reads as server-local midnight in UTC; the real UTC
        // instant of that midnight is that value minus the offset.
        val startSec = (cal.timeInMillis - serverOffsetSec * 1000L) / 1000
        out.add(DayItem(label, api.format(cal.time), startSec, startSec + 86_400))
        cal.add(Calendar.DAY_OF_YEAR, step)
    }
    return out
}
