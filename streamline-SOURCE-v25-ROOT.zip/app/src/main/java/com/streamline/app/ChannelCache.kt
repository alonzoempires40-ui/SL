package com.streamline.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * On-disk cache of the full channel list, so the app doesn't re-download the ~4.4 MB
 * get_all_channels payload on every connect.
 *
 * WHERE: the app's PRIVATE internal storage (filesDir). On a non-rooted device no other app can
 * read it. WHAT: only channel names / ids / cmd placeholders and the genre + archive flags — the
 * same data that already lives in memory while the app runs. It does NOT contain the MAC address or
 * the session token; those stay in SharedPreferences and are never written here.
 *
 * The cache is keyed to the current portal+MAC, so switching to a different line never shows the
 * wrong channels, and it carries a timestamp so a stale copy can be refreshed. It is always a
 * SUPPLEMENT: every read returns null on the slightest problem (missing, corrupt, wrong key, wrong
 * version), so the caller simply falls back to a normal portal fetch and channels still load.
 */
object ChannelCache {
    private var appCtx: Context? = null
    private const val FILE = "channels_cache.json"
    private const val VERSION = 1

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    private fun file(): File? = appCtx?.let { File(it.filesDir, FILE) }

    /** A successful load: the channels plus how old the cache is, in milliseconds. */
    data class Cached(val channels: List<PortalChannel>, val ageMs: Long)

    /** Save the parsed channel list under this portal+MAC key. Best-effort; never throws. */
    fun save(key: String, channels: List<PortalChannel>) {
        val f = file() ?: return
        try {
            val arr = JSONArray()
            for (c in channels) {
                arr.put(JSONObject().apply {
                    put("id", c.id)
                    put("number", c.number)
                    put("name", c.name)
                    put("genreId", c.genreId)
                    put("cmd", c.cmd)
                    put("logo", c.logo ?: "")
                    put("archive", c.archive)
                    put("archiveDays", c.archiveDays)
                })
            }
            val root = JSONObject().apply {
                put("v", VERSION)
                put("key", key)
                put("ts", System.currentTimeMillis())
                put("channels", arr)
            }
            f.writeText(root.toString())
            ConnectLog.add("  \u2605 [CH-CACHE] saved ${channels.size} channels to private storage")
        } catch (e: Exception) {
            ConnectLog.add("  [CH-CACHE] save failed (ignored): ${e.message}")
        }
    }

    /**
     * Load the cached list IF it matches this portal+MAC key and the current format version.
     * Returns null on any problem so the caller fetches from the portal instead. Never throws.
     */
    fun load(key: String): Cached? {
        val f = file() ?: return null
        if (!f.exists()) return null
        return try {
            val root = JSONObject(f.readText())
            if (root.optInt("v", -1) != VERSION) return null
            if (root.optString("key") != key) return null
            val arr = root.optJSONArray("channels") ?: return null
            val out = ArrayList<PortalChannel>(arr.length())
            for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                out.add(
                    PortalChannel(
                        id = c.optString("id"),
                        number = c.optInt("number"),
                        name = c.optString("name"),
                        genreId = c.optString("genreId"),
                        cmd = c.optString("cmd"),
                        logo = c.optString("logo").ifBlank { null },
                        archive = c.optBoolean("archive"),
                        archiveDays = c.optInt("archiveDays")
                    )
                )
            }
            if (out.isEmpty()) null else Cached(out, System.currentTimeMillis() - root.optLong("ts", 0L))
        } catch (e: Exception) {
            ConnectLog.add("  [CH-CACHE] load failed (ignored, will fetch): ${e.message}")
            null
        }
    }

    /** Delete the cache (e.g. a future manual refresh). Best-effort. */
    fun clear() {
        try { file()?.delete() } catch (_: Exception) { }
    }
}
