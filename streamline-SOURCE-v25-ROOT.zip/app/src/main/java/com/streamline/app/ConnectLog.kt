package com.streamline.app

import android.content.Context

/**
 * ConnectLog — records portal activity for the WHOLE session and writes it to a file
 * so it can be viewed (Settings → Connection log), copied, or shared for diagnosis.
 * The file is saved to the app's external files dir:
 *   Android/data/com.streamline.app/files/openstream-connect-log.txt
 * It rolls (oldest lines drop past MAX) and survives reconnects. Request URLs and
 * stream/archive links are logged for diagnosis, but access credentials (the stream
 * token, the Bearer session token, and the MAC) are masked so a copied/shared log
 * can't leak stream access or device identity. Gated by `enabled`; set it false for
 * a fully clean release.
 */
object ConnectLog {
    private val lines = StringBuilder()
    private const val MAX = 600000
    private const val FILE_MAX = 1200000
    private var appCtx: Context? = null
    private val fileLock = Any()
    const val FILE_NAME = "openstream-connect-log.txt"

    // Single on/off switch for ALL logging. Keep ON while diagnosing the portal with the
    // provider; flip to false for a clean release, and back to true for future upgrades.
    @Volatile var enabled = true

    // Scoped suppression for BULK background work (the catalog sweep). The sweep makes hundreds of
    // portal requests, each of which would otherwise write ~5 verbose log lines (URL, headers,
    // HTTP status, a JSON snippet). That flood was heavy enough to stutter the app on its busiest
    // moments. While this is >0, add() drops lines — normal user browsing (not wrapped) still logs
    // fully. Nested-safe via a counter; ALWAYS paired with try/finally so it can't get stuck on.
    @Volatile private var quietDepth = 0
    fun beginQuiet() { quietDepth++ }
    fun endQuiet() { if (quietDepth > 0) quietDepth-- }
    /** Run [block] with logging suppressed (for bulk background work like the catalog sweep). */
    fun <T> quiet(block: () -> T): T {
        beginQuiet()
        try { return block() } finally { endQuiet() }
    }

    /** Call once (e.g. at app start) so the log can write its file. */
    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    fun clear() {
        synchronized(lines) { lines.setLength(0) }
        headerWritten = false
        try {
            val ctx = appCtx
            if (ctx != null) {
                val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                java.io.File(dir, FILE_NAME).delete()
            }
        } catch (_: Exception) { /* never crash on cleanup */ }
    }

    // Mask access credentials so a copied/shared log can't leak stream access or device identity:
    //   ?token=<hex> stream credential, "Bearer <token>" session header, the MAC address (both
    //   the colon form 00:1A:79... and the URL-encoded form 00%3A1A%3A79... that appears inside
    //   the get_profile metrics= param), and the STB identity fields (device_id / signature /
    //   prehash / sn) that also travel in request lines.
    private val MAC_RE = Regex("([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}")
    private val MAC_ENC_RE = Regex("(?i)([0-9A-Fa-f]{2}(%3A)){5}[0-9A-Fa-f]{2}")
    private val TOKEN_RE = Regex("(?i)(token=)[^&\\s\"]+")
    private val BEARER_RE = Regex("(?i)(Bearer\\s+)\\S+")
    // device_id, device_id2, signature, sn, prehash as query params or JSON fields (encoded or not).
    private val IDENTITY_RE = Regex("(?i)(device_id2?|signature|prehash|\"?sn\"?)([=:]\\s*\"?)[0-9A-Fa-f%]+")
    private fun redact(line: String): String =
        line.replace(MAC_RE, "**:**:**:**:**:**")
            .replace(MAC_ENC_RE, "**%3A**%3A**%3A**%3A**%3A**")
            .replace(TOKEN_RE, "$1***")
            .replace(BEARER_RE, "$1***")
            .replace(IDENTITY_RE, "$1$2***")

    fun add(line: String) {
        if (!enabled || quietDepth > 0) return
        val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val safe = redact(line)
        val entry = "[$ts] $safe\n"
        synchronized(lines) {
            lines.append(entry)
            if (lines.length > MAX) lines.delete(0, lines.length - MAX)
        }
        appendFile(entry)
    }

    /** Log an HTTP step compactly. */
    fun step(label: String, detail: String = "") {
        add(if (detail.isBlank()) label else "$label — $detail")
    }

    fun text(): String = synchronized(lines) { lines.toString() }.ifBlank { "No connection attempt logged yet." }

    @Volatile private var headerWritten = false

    /**
     * Append ONLY the new entry to the log file.
     *
     * The previous version rewrote the WHOLE buffer to disk on every single line. With the
     * buffer now up to 2 MB, a single catch-up day-sweep (dozens of paginated requests, each
     * with its full JSON response logged) meant dozens of 2 MB string-builds + 2 MB disk
     * writes in a rapid burst — enough memory/IO churn to stall or drop the app on its
     * heaviest screen. Appending one line is O(line), so the burst is now trivial.
     */
    private fun appendFile(entry: String) {
        val ctx = appCtx ?: return
        synchronized(fileLock) {
        try {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            val f = java.io.File(dir, FILE_NAME)
            if (!headerWritten || !f.exists()) {
                f.writeText(
                    "StreamLine connection log\n" +
                    "Started: " + java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + "\n" +
                    "File: " + f.absolutePath + "\n" +
                    "----------------------------------------\n"
                )
                headerWritten = true
            }
            f.appendText(entry)
            // Bound the on-disk file too. The in-memory buffer rolls at MAX, but the file was
            // only ever appended to, so a long session grew it without limit. When it crosses
            // FILE_MAX, rewrite it once from the (already-capped, already-redacted) buffer. This
            // fires only on crossing the cap — not per line — so the heavy-screen burst the
            // append-only design was built to avoid stays cheap.
            if (f.length() > FILE_MAX) {
                val snapshot = synchronized(lines) { lines.toString() }
                f.writeText(
                    "StreamLine connection log (rolled — older lines dropped)\n" +
                    "----------------------------------------\n" + snapshot
                )
            }
        } catch (_: Exception) { /* logging must never crash the app */ }
        }
    }

    /** Where the log file lives, so Settings can tell the user. */
    fun filePath(ctx: Context): String {
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return java.io.File(dir, FILE_NAME).absolutePath
    }

    // ---- Crash capture -------------------------------------------------------------------
    // A crash that kills the process takes the in-memory connection log with it, and the
    // file gets wiped on the next reconnect — so an "app just drops" bug leaves no trace to
    // read. This records the stack trace of ANY uncaught crash to a SEPARATE, persistent file
    // (with a snapshot of the connection log as it stood at the moment of the crash), BEFORE
    // the app dies, then hands off to the system so it still terminates normally. The file is
    // never auto-deleted, so it can be opened from Settings after relaunch.
    const val CRASH_FILE_NAME = "openstream-crash-log.txt"
    @Volatile private var crashHandlerInstalled = false

    fun installCrashHandler(ctx: Context) {
        appCtx = ctx.applicationContext
        if (crashHandlerInstalled) return
        crashHandlerInstalled = true
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                val recent = synchronized(lines) { lines.toString() }
                val tail = if (recent.length > 20000) recent.takeLast(20000) else recent
                val body = "\n========== CRASH $stamp ==========\n" +
                    "thread: ${t.name}\n" +
                    sw.toString() +
                    "\n----- connection log at crash -----\n" + tail +
                    "\n========== END CRASH ==========\n"
                val c = appCtx
                if (c != null) {
                    val dir = c.getExternalFilesDir(null) ?: c.filesDir
                    java.io.File(dir, CRASH_FILE_NAME).appendText(body)
                }
            } catch (_: Throwable) { /* never fail inside the crash handler */ }
            prev?.uncaughtException(t, e)   // let the system finish crashing normally
        }
    }

    fun crashText(ctx: Context): String =
        try {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            val f = java.io.File(dir, CRASH_FILE_NAME)
            if (f.exists()) f.readText().ifBlank { "Crash log is empty." } else "No crash recorded yet."
        } catch (e: Exception) { "Couldn't read crash log: ${e.message}" }

    fun clearCrash(ctx: Context) {
        try {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            java.io.File(dir, CRASH_FILE_NAME).delete()
        } catch (_: Exception) { /* ignore */ }
    }
}
