package com.streamline.app

import android.content.Context
import android.os.Build
import java.io.File

/**
 * Soft environment check — looks for common signs of root or an emulator (BlueStacks etc.).
 *
 * IMPORTANT, and by design: this only RAISES A FLAG, it never hard-blocks the app. True
 * anti-root is impossible (a rooted device controls the app, not the other way round), and
 * hard-blocking would lock out legitimate users who root their own phones for normal reasons,
 * plus anyone genuinely testing on an emulator. So this is friction and a heads-up, not a wall.
 * The real protection is server-side: no content loads without a valid portal line.
 */
object EnvCheck {

    data class Result(val rooted: Boolean, val emulator: Boolean) {
        val flagged: Boolean get() = rooted || emulator
        fun reason(): String = when {
            rooted && emulator -> "a rooted device and an emulator"
            rooted -> "a rooted device"
            emulator -> "an emulator (e.g. BlueStacks)"
            else -> ""
        }
    }

    fun inspect(@Suppress("UNUSED_PARAMETER") ctx: Context): Result =
        Result(rooted = looksRooted(), emulator = looksEmulator())

    // --- root signals (common, defeatable by Magisk Hide — this catches casual cases only) ---
    private fun looksRooted(): Boolean {
        val suPaths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/system/app/Superuser.apk", "/data/local/xbin/su", "/data/local/bin/su"
        )
        if (suPaths.any { runCatching { File(it).exists() }.getOrDefault(false) }) return true
        // Magisk / known root manager packages leave traces in common locations
        val magisk = listOf("/sbin/.magisk", "/data/adb/magisk", "/data/adb/modules")
        if (magisk.any { runCatching { File(it).exists() }.getOrDefault(false) }) return true
        // test-keys build (typical of custom/rooted ROMs)
        if (Build.TAGS?.contains("test-keys") == true) return true
        return false
    }

    // --- emulator signals (BlueStacks, generic AVDs, etc.) ---
    private fun looksEmulator(): Boolean {
        val fp = Build.FINGERPRINT.lowercase()
        val model = Build.MODEL.lowercase()
        val product = Build.PRODUCT.lowercase()
        val manufacturer = Build.MANUFACTURER.lowercase()
        val hardware = Build.HARDWARE.lowercase()
        val brand = Build.BRAND.lowercase()
        if (fp.startsWith("generic") || fp.contains("vbox") || fp.contains("emulator") || fp.contains("test-keys") && fp.contains("generic")) return true
        if (model.contains("emulator") || model.contains("sdk") || model.contains("google_sdk") || model.contains("droid4x")) return true
        if (product.contains("sdk") || product.contains("emulator") || product.contains("vbox") || product.contains("bluestacks")) return true
        if (manufacturer.contains("genymotion") || manufacturer.contains("bluestacks")) return true
        if (hardware.contains("goldfish") || hardware.contains("ranchu") || hardware.contains("vbox") || hardware.contains("nox")) return true
        if (brand.startsWith("generic") && Build.DEVICE.lowercase().startsWith("generic")) return true
        // BlueStacks-specific files
        val bsFiles = listOf("/system/lib/libbluestacks.so", "/system/bin/bstfolder", "/data/data/com.bluestacks.appplayer")
        if (bsFiles.any { runCatching { File(it).exists() }.getOrDefault(false) }) return true
        return false
    }

    // Remember if the user already dismissed the warning this install, so we nag only once.
    fun warningDismissed(ctx: Context): Boolean =
        ctx.getSharedPreferences("openstream", Context.MODE_PRIVATE).getBoolean("env_warn_dismissed", false)

    fun dismissWarning(ctx: Context) {
        ctx.getSharedPreferences("openstream", Context.MODE_PRIVATE).edit()
            .putBoolean("env_warn_dismissed", true).apply()
    }
}
