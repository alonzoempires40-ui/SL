package com.streamline.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent local EPG store, kept ~2 weeks (the DVR archive window).
 *
 * Why: get_short_epg is the only EPG action this portal answers, and it's forward-only; the dated
 * endpoints are refused and old EPG is deleted server-side. So the only way to have names on a past
 * catch-up day is to save them as they air. get_short_epg also returns UPCOMING programmes, so one
 * large sweep captures days at once. We merge every sweep + now/next view here, keyed by
 * (ch_id, start_timestamp), and keep ~15 days. We store only name + start/stop time (lean = low
 * memory). The catch-up screen serves any captured day from this store.
 *
 * CRASH SAFETY — this class is built so it can NEVER drop the app:
 *   - Every public method has a catch-all; it can return a safe value but never throw to a caller
 *     (an uncaught exception on any thread would kill the process, so we swallow everything here).
 *   - init/flush run on background threads; the main thread never touches disk.
 *   - The heavy JSON parse in load() runs OUTSIDE the lock (parse into a local map, then take the
 *     lock only briefly to merge it in), so a slow parse can't stall merge()/forDay() or the UI.
 *   - save() snapshots under a brief lock, then serialises + writes outside the lock, to a temp file
 *     that is atomically renamed into place — a kill mid-write can't corrupt the cache.
 *   - A runaway file is ignored and rebuilt instead of parsed (OOM guard).
 */
object EpgStore {
    private const val FILE_NAME = "openstream-epg-cache.json"
    private const val KEEP_DAYS = 15L                       // ~2 weeks + a day of headroom
    private const val MAX_ROWS_PER_CH = 1000               // generous; storage isn't the concern
    private const val MAX_LOAD_BYTES = 16L * 1024 * 1024   // ignore a runaway file (OOM guard)
    private const val SAVE_DEBOUNCE_MS = 8_000L

    private var appCtx: Context? = null
    @Volatile private var loaded = false
    @Volatile private var lastSaveMs = 0L

    private val store = HashMap<String, HashMap<Long, Prog>>()   // ch_id -> (start_ts -> programme)
    private val saveLock = Any()                                 // serialises concurrent saves

    data class Prog(val s: Long, val e: Long, val n: String)

    fun init(ctx: Context) {
        try {
            appCtx = ctx.applicationContext
            Thread({ load() }, "epg-load").start()
        } catch (_: Throwable) { }
    }

    /**
     * Synchronous load for background workers (which are already off the main thread). Ensures the
     * on-disk cache is in memory BEFORE the worker harvests + flushes, so a flush can't overwrite
     * disk rows that hadn't been loaded yet. Safe to call repeatedly (load() is guarded).
     */
    fun loadNow(ctx: Context) {
        try { appCtx = ctx.applicationContext; load() } catch (_: Throwable) { }
    }

    /** Persist now, on a background thread. Safe to call from onPause / the main thread. */
    fun flush() {
        try { Thread({ save() }, "epg-save").start() } catch (_: Throwable) { }
    }

    /** Merge a batch for one channel (upsert by start_timestamp). Never throws. */
    fun merge(channelId: String, progs: List<EpgProgram>) {
        try {
            if (channelId.isBlank() || progs.isEmpty()) return
            var changed = false
            synchronized(this) {
                val m = store.getOrPut(channelId) { HashMap() }
                for (p in progs) {
                    if (p.startTs <= 0 || p.name.isBlank()) continue
                    val prev = m[p.startTs]
                    if (prev == null || prev.n != p.name || prev.e != p.endTs) {
                        m[p.startTs] = Prog(p.startTs, p.endTs, p.name)
                        changed = true
                    }
                }
                if (m.size > MAX_ROWS_PER_CH) capChannel(m)
            }
            if (changed && System.currentTimeMillis() - lastSaveMs >= SAVE_DEBOUNCE_MS) {
                save()   // merge() is always called from a background (network) thread
            }
        } catch (_: Throwable) { }
    }

    /** All stored programmes for one channel within [fromTs, toTs). Never throws; [] on any error. */
    fun forDay(channelId: String, fromTs: Long, toTs: Long): List<EpgProgram> {
        return try {
            val now = nowSec()
            val rows: List<Prog> = synchronized(this) {
                val m = store[channelId] ?: return emptyList()
                m.values.filter { it.s in fromTs until toTs }
            }
            rows.sortedBy { it.s }.map {
                EpgProgram(
                    name = it.n, start = "", end = "",       // epgClock formats from startTs
                    startTs = it.s, endTs = it.e,
                    desc = "", id = "",                      // no portal id -> timestamp-seek playback
                    hasArchive = it.e in 1 until now         // finished & in the past = replayable
                )
            }
        } catch (_: Throwable) { emptyList() }
    }

    fun count(channelId: String): Int =
        try { synchronized(this) { store[channelId]?.size ?: 0 } } catch (_: Throwable) { 0 }

    // --- internals ---

    /** Keep only the newest MAX_ROWS_PER_CH rows for a channel. Caller holds the lock. */
    private fun capChannel(m: HashMap<Long, Prog>) {
        val keepFrom = m.keys.sortedDescending().take(MAX_ROWS_PER_CH).lastOrNull() ?: return
        val it = m.keys.iterator()
        while (it.hasNext()) if (it.next() < keepFrom) it.remove()
    }

    private fun load() {
        if (loaded) return
        loaded = true
        try {
            val f = file() ?: return
            if (!f.exists() || f.length() > MAX_LOAD_BYTES) return   // missing or runaway -> start fresh
            val root = JSONObject(f.readText())                      // heavy parse, OUTSIDE the lock
            val cutoff = nowSec() - KEEP_DAYS * 86_400
            val parsed = HashMap<String, HashMap<Long, Prog>>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val ch = keys.next()
                val arr = root.optJSONArray(ch) ?: continue
                val m = HashMap<Long, Prog>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val s = o.optLong("s")
                    val e = o.optLong("e")
                    if (s <= 0 || e < cutoff) continue                // drop stale rows on load
                    m[s] = Prog(s, e, o.optString("n"))
                }
                if (m.isNotEmpty()) parsed[ch] = m
            }
            // brief lock just to merge parsed rows in, without clobbering anything harvested meanwhile
            synchronized(this) {
                for ((ch, m) in parsed) {
                    val dst = store.getOrPut(ch) { HashMap() }
                    for ((ts, p) in m) if (!dst.containsKey(ts)) dst[ts] = p
                }
            }
        } catch (_: Throwable) { /* corrupt/oversized cache -> start fresh */ }
    }

    private fun save() {
        try {
            synchronized(saveLock) {
                val f = file() ?: return
                val cutoff = nowSec() - KEEP_DAYS * 86_400
                // snapshot + prune under a brief lock (Prog is immutable, so sharing refs is safe)
                val snapshot = ArrayList<Pair<String, List<Prog>>>()
                synchronized(this) {
                    val empties = ArrayList<String>()
                    for ((ch, m) in store) {
                        val it = m.entries.iterator()
                        val live = ArrayList<Prog>(m.size)
                        while (it.hasNext()) {
                            val p = it.next().value
                            if (p.e < cutoff) { it.remove(); continue }   // prune as we go
                            live.add(p)
                        }
                        if (live.isNotEmpty()) snapshot.add(ch to live) else empties.add(ch)
                    }
                    for (ch in empties) store.remove(ch)
                }
                // serialise + write OUTSIDE the data lock, to a temp file, then atomically rename
                val root = JSONObject()
                for ((ch, live) in snapshot) {
                    val arr = JSONArray()
                    for (p in live) arr.put(JSONObject().put("s", p.s).put("e", p.e).put("n", p.n))
                    root.put(ch, arr)
                }
                val tmp = java.io.File(f.parentFile, "$FILE_NAME.tmp")
                tmp.writeText(root.toString())
                if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
                lastSaveMs = System.currentTimeMillis()
            }
        } catch (_: Throwable) { /* best effort */ }
    }

    private fun file(): java.io.File? {
        val ctx = appCtx ?: return null
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return java.io.File(dir, FILE_NAME)
    }

    private fun nowSec() = System.currentTimeMillis() / 1000
}
