package com.streamline.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/**
 * Programme-detail popup: name / time / category / description / cast.
 *
 * The rich fields (descr, category, director, actor) exist only on a FRESH get_short_epg row — the
 * 2-week EpgStore keeps name+start/stop only to stay tiny — so this is fed by the live now/next
 * programme, which is exactly "the programme playing". For a programme with no captured detail (a
 * stored past row, or one outside the short-EPG window) it still shows name + time and a short note.
 *
 * Crash-safe by construction: `program` may be null, every field is optional, and blank fields are
 * simply omitted. It draws no data it wasn't handed.
 */
@Composable
fun EpgDetailSheet(
    program: EpgProgram?,
    channelName: String,
    loading: Boolean = false,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(16.dp))
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (channelName.isNotBlank()) {
                Text(
                    channelName.uppercase(),
                    color = Amber, fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace
                )
                Spacer(Modifier.height(6.dp))
            }

            if (program == null) {
                Text(
                    if (loading) "Loading programme info\u2026" else "No programme information available.",
                    color = Muted, fontSize = 14.sp
                )
            } else {
                Text(
                    program.name.ifBlank { "Untitled programme" },
                    color = TextCol, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))

                val range = epgTimeRange(program)
                if (range.isNotBlank()) {
                    Text(range, color = Muted, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(Modifier.height(12.dp))

                if (program.category.isNotBlank()) {
                    Text(
                        program.category,
                        color = Amber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .background(Amber.copy(alpha = 0.14f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                }

                if (program.desc.isNotBlank()) {
                    Text(program.desc, color = TextCol, fontSize = 14.sp, lineHeight = 20.sp)
                    Spacer(Modifier.height(12.dp))
                }

                if (program.director.isNotBlank()) DetailLine("Director", program.director)
                if (program.actor.isNotBlank()) DetailLine("Cast", program.actor)

                val nothingExtra = program.category.isBlank() && program.desc.isBlank() &&
                    program.director.isBlank() && program.actor.isBlank()
                if (nothingExtra) {
                    Text(
                        if (loading) "Loading details\u2026" else "No further details for this programme.",
                        color = Muted, fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (actionLabel != null && onAction != null) {
                    Text(
                        actionLabel,
                        color = Color(0xFF1A1300), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(Amber, RoundedCornerShape(10.dp))
                            .clickable { onAction(); onDismiss() }
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                    Spacer(Modifier.weight(1f))
                }
                Text(
                    "Close",
                    color = Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .background(Panel2, RoundedCornerShape(10.dp))
                        .clickable { onDismiss() }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(Modifier.padding(bottom = 6.dp)) {
        Text(
            label,
            color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(64.dp)
        )
        Text(value, color = TextCol, fontSize = 13.sp, modifier = Modifier.weight(1f))
    }
}

/** "HH:mm \u2013 HH:mm" for a programme, from its absolute timestamps (falls back to the t_time strings). */
fun epgTimeRange(p: EpgProgram): String {
    val start = epgClock(p)   // reuse StalkerClient's robust clock formatter
    val end = if (p.endTs > 0)
        java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date(p.endTs * 1000))
    else p.end.trim().let { if (it.contains(' ')) it.substringAfter(' ').take(5) else it.take(5) }
    return when {
        start.isNotBlank() && end.isNotBlank() -> "$start \u2013 $end"
        start.isNotBlank() -> start
        else -> ""
    }
}
