package com.streamline.app

import android.content.Context
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

// ----- design tokens (match the mockup) -----
val Ink = Color(0xFF0B0E16)
val Panel = Color(0xFF141927)
val Panel2 = Color(0xFF1C2336)
val Line = Color(0xFF262E45)
val TextCol = Color(0xFFEAEDF5)
val Muted = Color(0xFF8A93AB)
val Amber = Color(0xFFF5B638)

// accent options the user can pick in Settings; Amber is the default brand color.
fun accentColor(name: String): Color = when (name) {
    "blue" -> Color(0xFF5B8DEF)
    "green" -> Color(0xFF3FBF7F)
    "purple" -> Color(0xFFB07CF0)
    else -> Amber
}
val ErrCol = Color(0xFFFF8A80)

// ----- UI models -----
data class UiChannel(
    val number: Int,
    val name: String,
    val info: String,
    val logo: String? = null,
    val playUrl: String? = null,
    val cmd: String? = null,
    val id: String? = null,
    val archive: Boolean = false
)

data class UiMovie(
    val name: String,
    val year: String,
    val description: String,
    val poster: String? = null,
    val meta: String = "",
    val playUrl: String? = null,
    val cmd: String? = null,
    val progress: Int = 0,        // 0–100 for Continue-watching bar; 0 = none
    val hue: String = "#2C3A66",  // backdrop tint when no artwork
    val portalTrailer: String? = null,  // trailer URL/id the provider stored, if any
    val seriesId: String? = null,       // set for series → enables the Episodes view
    val added: String = "",             // portal "added" datetime (YYYY-MM-DD …) for date sorting
    val actors: String = "",            // cast (from portal) — shown on the detail page
    val director: String = "",          // director (from portal) — shown on the detail page
    val categoryId: String = ""         // source category — drives the "More like this" row
)

data class Category(val id: String, val title: String, val censored: Boolean = false)

// ----- saved settings -----
// A viewing profile: a name, and whether it's a restricted Kids profile.
data class Profile(val name: String, val kids: Boolean = false)

object Prefs {
    private const val FILE = "openstream"

    // ---- Vault-sealed secrets (MAC, device ids, signature, serial, user/pass) ----
    // Stored encrypted via Vault (hardware Keystore). getSecret() transparently migrates a legacy
    // plaintext value to sealed form on first read, so existing installs upgrade themselves and
    // no call site anywhere in the app changes. putSecret() never loses data (Vault.seal falls
    // back to plaintext on a broken Keystore rather than failing).
    private fun getSecret(ctx: Context, key: String, def: String = ""): String {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val raw = p.getString(key, def) ?: def
        val out = Vault.open(raw)
        if (out.isNotEmpty() && !Vault.isSealed(raw)) {
            val sealed = Vault.seal(out)                        // one-time migration
            if (Vault.isSealed(sealed)) p.edit().putString(key, sealed).apply()
        }
        return out
    }

    /**
     * Permanent per-device identity, like a real set-top box.
     * Generated ONCE on first launch, stored forever, never changes for this install.
     * Each device gets DIFFERENT values (seeded from secure randomness + install time),
     * so two installs never collide. The user can still override any of them by typing
     * their own value on the Connect screen if their provider requires specific IDs.
     */
    fun ensureDeviceIdentity(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        if (p.getBoolean("identity_made", false)) return  // already generated — leave untouched

        val rnd = java.security.SecureRandom()
        fun randomHex(bytes: Int): String {
            val b = ByteArray(bytes); rnd.nextBytes(b)
            return b.joinToString("") { "%02x".format(it) }.uppercase()
        }
        // a unique seed for this device = secure randomness + the exact install instant
        val seed = randomHex(16) + System.currentTimeMillis().toString()

        // Device ID 1 and 2: 64-hex-char ids, like a MAG box. Distinct from each other.
        val devId1 = sha256(seed + "-id1")
        val devId2 = sha256(seed + "-id2")
        // Signature: another 64-char value derived from the same seed but distinct
        val signature = sha256(seed + "-sig")
        // Serial number: 13-char STB-style serial (uppercase alphanumeric)
        val serial = stbSerial(rnd)
        // A matching device MAC in Infomir's 00:1A:79 range if the user hasn't set one
        val mac = Vault.open(p.getString("mac", "") ?: "")
        val newMac = if (mac.isBlank() || mac == "00:1A:79:00:00:00") generateMac(rnd) else mac

        p.edit()
            .putString("dev1", Vault.seal(devId1))
            .putString("dev2", Vault.seal(devId2))
            .putString("sig", Vault.seal(signature))
            .putString("serial", Vault.seal(serial))
            .putString("mac", Vault.seal(newMac))
            .putBoolean("identity_made", true)
            .apply()
    }

    private fun sha256(s: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.uppercase()
    }

    private fun stbSerial(rnd: java.security.SecureRandom): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return (1..13).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
    }

    private fun generateMac(rnd: java.security.SecureRandom): String {
        // Infomir/MAG OUI prefix 00:1A:79, then 3 random octets
        val tail = (1..3).joinToString(":") { "%02X".format(rnd.nextInt(256)) }
        return "00:1A:79:$tail"
    }

    fun serial(ctx: Context) = getSecret(ctx, "serial")

    // save only URL + MAC, never touching the generated device identity
    fun saveConnection(ctx: Context, url: String, mac: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("url", url).putString("mac", Vault.seal(mac)).apply()
    }
    // persist manual overrides only when the user actually typed them
    fun saveOverrides(ctx: Context, dev1: String, dev2: String, sig: String) {
        val e = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
        if (dev1.isNotBlank()) e.putString("dev1", Vault.seal(dev1))
        if (dev2.isNotBlank()) e.putString("dev2", Vault.seal(dev2))
        if (sig.isNotBlank()) e.putString("sig", Vault.seal(sig))
        e.apply()
    }

    fun save(ctx: Context, url: String, mac: String, dev1: String = "", dev2: String = "", sig: String = "") {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("url", url).putString("mac", Vault.seal(mac))
            .putString("dev1", Vault.seal(dev1)).putString("dev2", Vault.seal(dev2))
            .putString("sig", Vault.seal(sig)).apply()
    }
    fun url(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("url", "") ?: ""
    fun saveUrl(ctx: Context, url: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("url", url.trim()).apply()
    fun saveMac(ctx: Context, mac: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("mac", Vault.seal(mac.trim())).apply()
    // Optional portal username/password (most MAC lines don't use these). Persisted so the
    // Enter button can connect with saved details.
    fun user(ctx: Context) = getSecret(ctx, "user")
    fun saveUser(ctx: Context, v: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("user", Vault.seal(v.trim())).apply()
    fun pass(ctx: Context) = getSecret(ctx, "pass")
    fun savePass(ctx: Context, v: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("pass", Vault.seal(v)).apply()
    fun model(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("model", "MAG254") ?: "MAG254"
    // Which screen opens after connecting: "menu" (default), "live", "movies", "series".
    fun startupScreen(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("startup", "menu") ?: "menu"
    fun saveStartupScreen(ctx: Context, v: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("startup", v).apply()

    // Subtitle size as a percentage, stored PER engine ("exo"/"vlc"/"mpv") because each renders
    // subs at a different base size — a shared value looked normal on VLC but tiny on mpv. 100 = that
    // engine's standard size; the per-player sliders scale from there. Read at player creation.
    fun subScaleFor(ctx: Context, engine: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("sub_scale_$engine", 100)
    fun saveSubScaleFor(ctx: Context, engine: String, pct: Int) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("sub_scale_$engine", pct).apply()

    // Recent search terms (most-recent first, capped at 10) for the Search screen's history chips.
    fun recentSearches(ctx: Context): List<String> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("searches", "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw); (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
    }
    fun addRecentSearch(ctx: Context, q: String) {
        val query = q.trim(); if (query.length < 2) return
        val cur = recentSearches(ctx).toMutableList()
        cur.removeAll { it.equals(query, true) }
        cur.add(0, query)
        val a = JSONArray(); cur.take(10).forEach { a.put(it) }
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("searches", a.toString()).apply()
    }
    fun saveModel(ctx: Context, m: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("model", m).apply()
    fun mac(ctx: Context) = getSecret(ctx, "mac", "00:1A:79:00:00:00")
    fun dev1(ctx: Context) = getSecret(ctx, "dev1")
    fun dev2(ctx: Context) = getSecret(ctx, "dev2")
    fun sig(ctx: Context) = getSecret(ctx, "sig")

    // ---- Second portal: its own URL + MAC. The device identity (serial/dev1/dev2/sig) is shared
    // on purpose — it is generated per-DEVICE, not per-portal. Portal 1 keeps the original keys,
    // so an existing login is completely untouched by this feature. ----
    fun activePortal(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("active_portal", 1)
    fun saveActivePortal(ctx: Context, n: Int) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("active_portal", n).apply()
    fun url2(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("url2", "") ?: ""
    fun saveUrl2(ctx: Context, url: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("url2", url.trim()).apply()
    fun mac2(ctx: Context): String { ensureIdentity2(ctx); return getSecret(ctx, "mac2") }
    fun saveMac2(ctx: Context, mac: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("mac2", Vault.seal(mac.trim())).apply()
    fun dev1p2(ctx: Context): String { ensureIdentity2(ctx); return getSecret(ctx, "dev1_2") }
    fun dev2p2(ctx: Context): String { ensureIdentity2(ctx); return getSecret(ctx, "dev2_2") }
    fun sigP2(ctx: Context): String { ensureIdentity2(ctx); return getSecret(ctx, "sig_2") }
    fun serialP2(ctx: Context): String { ensureIdentity2(ctx); return getSecret(ctx, "serial_2") }

    /**
     * Portal 2's OWN permanent identity — generated ONCE, the first time portal 2 is touched,
     * with the exact same mechanism as portal 1 (ensureDeviceIdentity): fresh secure seed, two
     * 64-hex device IDs, a signature, a 13-char STB serial, and a MAC in Infomir's 00:1A:79
     * range. A MAC the user already saved for portal 2 is kept, never overwritten.
     */
    private fun ensureIdentity2(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        if (p.getBoolean("identity2_made", false)) return
        val rnd = java.security.SecureRandom()
        fun randomHex(bytes: Int): String {
            val b = ByteArray(bytes); rnd.nextBytes(b)
            return b.joinToString("") { "%02x".format(it) }.uppercase()
        }
        val seed = randomHex(16) + System.currentTimeMillis().toString()
        val existingMac = Vault.open(p.getString("mac2", "") ?: "")
        p.edit()
            .putString("dev1_2", Vault.seal(sha256(seed + "-p2-id1")))
            .putString("dev2_2", Vault.seal(sha256(seed + "-p2-id2")))
            .putString("sig_2", Vault.seal(sha256(seed + "-p2-sig")))
            .putString("serial_2", Vault.seal(stbSerial(rnd)))
            .putString("mac2", Vault.seal(if (existingMac.isBlank()) generateMac(rnd) else existingMac))
            .putBoolean("identity2_made", true)
            .apply()
    }
    // What the connect flow and background worker actually use:
    fun activeUrl(ctx: Context) = if (activePortal(ctx) == 2) url2(ctx) else url(ctx)
    fun activeMac(ctx: Context) = if (activePortal(ctx) == 2) mac2(ctx) else mac(ctx)
    fun activeDev1(ctx: Context) = if (activePortal(ctx) == 2) dev1p2(ctx) else dev1(ctx)
    fun activeDev2(ctx: Context) = if (activePortal(ctx) == 2) dev2p2(ctx) else dev2(ctx)
    fun activeSig(ctx: Context) = if (activePortal(ctx) == 2) sigP2(ctx) else sig(ctx)
    fun activeSerial(ctx: Context) = if (activePortal(ctx) == 2) serialP2(ctx) else serial(ctx)
    fun saveActiveConnection(ctx: Context, url: String, mac: String) {
        if (activePortal(ctx) == 2) { saveUrl2(ctx, url); saveMac2(ctx, mac) } else saveConnection(ctx, url, mac)
    }


    // resume positions for VOD/episodes, keyed by a stable title string -> millis
    fun saveResume(ctx: Context, key: String, ms: Long, durationMs: Long) {
        if (durationMs <= 0) return
        val pct = ms.toFloat() / durationMs
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        // drop near-start and near-end so the Continue row stays meaningful
        if (pct < 0.03f || pct > 0.95f) { p.edit().remove("res_$key").remove("dur_$key").apply(); return }
        p.edit().putLong("res_$key", ms).putLong("dur_$key", durationMs).apply()
    }
    fun resumeMs(ctx: Context, key: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getLong("res_$key", 0)
    fun resumePct(ctx: Context, key: String): Int {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val r = p.getLong("res_$key", 0); val d = p.getLong("dur_$key", 0)
        return if (d > 0) ((r.toFloat() / d) * 100).toInt() else 0
    }

    // ---- Continue Watching + My List (small per-item records, stored as JSON in prefs) ----
    // We keep just enough to render a poster and replay it; progress for Continue is read LIVE from
    // resumePct() (which the player already maintains), so we never need to update the stored record.
    private fun encodeMovie(m: UiMovie) = JSONObject().apply {
        put("n", m.name); put("y", m.year); put("p", m.poster ?: "")
        put("c", m.cmd ?: ""); put("u", m.playUrl ?: ""); put("s", m.seriesId ?: "")
        put("ci", m.categoryId); put("a", m.actors); put("d", m.director)
    }
    private fun decodeMovie(o: JSONObject) = UiMovie(
        name = o.optString("n"), year = o.optString("y"), description = "",
        poster = o.optString("p").ifBlank { null }, cmd = o.optString("c").ifBlank { null },
        playUrl = o.optString("u").ifBlank { null }, seriesId = o.optString("s").ifBlank { null },
        categoryId = o.optString("ci"), actors = o.optString("a"), director = o.optString("d")
    )
    private fun readMovieList(ctx: Context, key: String): MutableList<UiMovie> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(key, "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { decodeMovie(it) } }.toMutableList()
        }.getOrDefault(mutableListOf())
    }
    private fun writeMovieList(ctx: Context, key: String, list: List<UiMovie>) {
        val a = JSONArray(); list.forEach { a.put(encodeMovie(it)) }
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(key, a.toString()).apply()
    }

    fun myList(ctx: Context): List<UiMovie> = readMovieList(ctx, "mylist")
    fun inMyList(ctx: Context, title: String) = myList(ctx).any { it.name == title }
    fun toggleMyList(ctx: Context, m: UiMovie) {
        val cur = readMovieList(ctx, "mylist")
        val i = cur.indexOfFirst { it.name == m.name }
        if (i >= 0) cur.removeAt(i) else cur.add(0, m)
        writeMovieList(ctx, "mylist", cur.take(100))
    }

    /** Record a movie as recently-played (call when it starts). Newest first, capped at 20. */
    fun saveContinueWatched(ctx: Context, m: UiMovie) {
        if (m.name.isBlank()) return
        val cur = readMovieList(ctx, "continue")
        // Collapse a series to ONE tile: if this is an episode ("Series — S#E#"), drop other episodes
        // of the same series so only the latest shows; otherwise just dedupe by exact name.
        val ep = Regex(" — S\\d+E\\d+$").find(m.name)
        if (ep != null) {
            val seriesPrefix = m.name.substring(0, ep.range.first)
            cur.removeAll { it.name.startsWith("$seriesPrefix — S") }
        } else {
            cur.removeAll { it.name == m.name }
        }
        cur.add(0, m)
        writeMovieList(ctx, "continue", cur.take(20))
    }
    /** The Continue Watching rail: recently-played items, progress read live, finished ones dropped. */
    fun continueList(ctx: Context): List<UiMovie> =
        readMovieList(ctx, "continue")
            .map { it.copy(progress = resumePct(ctx, it.name)) }
            .filter { it.progress < 95 }

    // parental PIN (blank = off)
    fun pin(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("pin", "") ?: ""
    fun savePin(ctx: Context, v: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("pin", v.trim()).apply()

    // Parental lock (replaces the old Kids profiles). adultUnlocked is in-memory only — it resets
    // when the app process restarts, so the lock re-arms on a fresh launch. Enter the PIN once and
    // adult sections stay open until then.
    var adultUnlocked = false
    fun adultLocked(ctx: Context): Boolean = pin(ctx).isNotBlank() && !adultUnlocked
    fun isAdultCat(title: String, censored: Boolean): Boolean {
        if (censored) return true
        val t = title.lowercase()
        return t.contains("adult") || t.contains("xxx") || t.contains("porn") ||
               t.contains("erotic") || t.contains("+18") || t.contains("18+") || t.contains("hardcore")
    }

    // preferred playback engine: "auto" (Exo→VLC), "exo", or "vlc"
    fun engine(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("engine", "auto") ?: "auto"
    fun saveEngine(ctx: Context, v: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("engine", v).apply()

    // accent color theme: "amber" (default), "blue", "green", "purple"
    fun accent(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("accent", "amber") ?: "amber"

    fun saveAccent(ctx: Context, v: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("accent", v).apply()

    // weather city for the menu widget (blank = weather hidden)
    fun weatherCity(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("weather_city", "") ?: ""
    fun saveWeatherCity(ctx: Context, v: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("weather_city", v).apply()
    // cached weather (JSON) + the city it was for, so the menu can show it instantly then refresh
    fun weatherCache(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("weather_cache", "") ?: ""
    fun saveWeatherCache(ctx: Context, json: String) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("weather_cache", json).apply()

    // favorite channel numbers, stored as a comma string
    fun favs(ctx: Context): MutableSet<Int> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("favs", "") ?: ""
        return raw.split(",").mapNotNull { it.trim().toIntOrNull() }.toMutableSet()
    }
    fun toggleFav(ctx: Context, number: Int) {
        val s = favs(ctx)
        if (!s.add(number)) s.remove(number)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("favs", s.joinToString(",")).apply()
    }
    fun isFav(ctx: Context, number: Int) = favs(ctx).contains(number)

    // ---- First-run wizard: shown once on a fresh install, then never again ----
    fun setupDone(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("setup_done", false)
    fun markSetupDone(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("setup_done", true).apply()

    // ---- Profiles (each: name + Kids flag). Default: one "Main" profile. Stored as name\tkids per line. ----
    fun profiles(ctx: Context): List<Profile> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("profiles", "") ?: ""
        val list = raw.split("\n").mapNotNull { line ->
            if (line.isBlank()) null else line.split("\t").let { Profile(it[0], it.getOrNull(1) == "1") }
        }
        return if (list.isEmpty()) listOf(Profile("Main", false)) else list
    }
    private fun saveProfiles(ctx: Context, list: List<Profile>) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("profiles", list.joinToString("\n") { "${it.name}\t${if (it.kids) "1" else "0"}" }).apply()
    fun addProfile(ctx: Context, name: String, kids: Boolean) {
        val n = name.trim().take(20)
        if (n.isBlank()) return
        val cur = profiles(ctx).toMutableList()
        if (cur.any { it.name.equals(n, true) }) return
        cur.add(Profile(n, kids)); saveProfiles(ctx, cur)
    }
    fun removeProfile(ctx: Context, name: String) {
        val cur = profiles(ctx).filterNot { it.name.equals(name, true) }
        saveProfiles(ctx, if (cur.isEmpty()) listOf(Profile("Main", false)) else cur)
        if (activeProfile(ctx).equals(name, true)) setActiveProfile(ctx, profiles(ctx).first().name)
    }
    fun activeProfile(ctx: Context): String {
        val saved = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("active_profile", "") ?: ""
        val all = profiles(ctx)
        return all.firstOrNull { it.name.equals(saved, true) }?.name ?: all.first().name
    }
    fun setActiveProfile(ctx: Context, name: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("active_profile", name.trim()).apply()
    fun activeIsKids(ctx: Context): Boolean {
        val a = activeProfile(ctx)
        return profiles(ctx).firstOrNull { it.name.equals(a, true) }?.kids == true
    }
    // Kids mode hides whatever the PORTAL marked adult (Category.censored) — no keyword guessing.
}

// ----- EPG UI model -----
data class UiEpg(val name: String, val time: String, val isNow: Boolean, val startTs: Long = 0, val channelName: String = "")

// ----- a horizontal rail of titles for the Netflix-style browse screen -----
data class Rail(val title: String, val items: List<UiMovie>)

// ----- an episode of a series -----
data class UiEpisode(val name: String, val season: String, val episode: String, val cmd: String?, val playUrl: String? = null)
data class UiSeason(val id: String, val number: String, val name: String)

// ----- demo content: legal public test streams + sample movies -----
val demoChannels = listOf(
    UiChannel(1, "Big Buck Bunny", "Demo · HLS", playUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
    UiChannel(2, "Apple BipBop", "Demo · HLS adaptive", playUrl = "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"),
    UiChannel(3, "Sintel", "Demo · HLS", playUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"),
    UiChannel(4, "Tears of Steel", "Demo · HLS", playUrl = "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8")
)

val demoMovies = listOf(
    UiMovie("Big Buck Bunny", "2008", "A large, kind-hearted rabbit deals with three bullying rodents in a sunny forest glade. Open-license animated short used here as demo content.", meta = "2008 · 10m · Animation", playUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
    UiMovie("Sintel", "2010", "A lone warrior searches across a harsh landscape for the dragon she befriended as a child. Open movie project, used as demo content.", meta = "2010 · 15m · Fantasy", playUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"),
    UiMovie("Tears of Steel", "2012", "In a future Amsterdam, a group reunites to undo a mistake that doomed the city to a robot uprising. Open movie project, used as demo content.", meta = "2012 · 12m · Sci-fi", playUrl = "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8")
)

val demoSeries = listOf(
    UiMovie("The Long Static", "2023", "A late-night radio host begins taking calls from a listener who calmly describes tomorrow's news. Demo placeholder series.", meta = "Season 1 · 8 episodes", playUrl = demoChannels[1].playUrl, hue = "#8A93AB", seriesId = "demo1"),
    UiMovie("Paper Harbor", "2024", "Two dockworkers restore an abandoned ferry and quietly reopen the line between feuding towns. Demo placeholder series.", meta = "Season 1 · 6 episodes", playUrl = demoChannels[2].playUrl, hue = "#3FBF7F", seriesId = "demo2")
)

val demoEpisodes = mapOf(
    "demo1" to (1..8).map { UiEpisode("Episode $it", "1", it.toString(), null, demoChannels[1].playUrl) },
    "demo2" to (1..6).map { UiEpisode("Episode $it", "1", it.toString(), null, demoChannels[2].playUrl) }
)

val demoSeasons = mapOf(
    "demo1" to listOf(UiSeason("demo1s1", "1", "Season 1")),
    "demo2" to listOf(UiSeason("demo2s1", "1", "Season 1"))
)

// Netflix-style rails for the demo Video Club
val demoVodRails: List<Rail> = run {
    val night = UiMovie("Night Train", "2024", "A night porter on the last sleeper to the coast discovers one passenger isn't on the manifest — and the train hasn't stopped where it should.", meta = "2024 · 1h 52m · Thriller", playUrl = demoChannels[0].playUrl, hue = "#4A2C6F")
    val cart = UiMovie("The Cartographer", "2023", "After inheriting his father's unfinished atlas, a young surveyor maps a valley the residents insist does not exist.", meta = "2023 · 2h 04m · Drama", playUrl = demoChannels[2].playUrl, hue = "#23355F")
    val tin = UiMovie("Tin Sky", "2022", "In a mining town under a sealed dome, a radio engineer starts picking up weather reports from outside.", meta = "2022 · 1h 47m · Sci-fi", playUrl = demoChannels[3].playUrl, hue = "#103530")
    val harbor = UiMovie("Paper Harbor", "2024", "Two dockworkers restore an abandoned ferry and quietly reopen the line between feuding towns.", meta = "2024 · 1h 38m · Drama", playUrl = demoChannels[1].playUrl, progress = 62, hue = "#1C3A2E")
    val solstice = UiMovie("Solstice", "2021", "A polar research crew counts down the last sunset of the year as the supplies — and the stories — stop adding up.", meta = "2021 · 1h 55m · Thriller", playUrl = demoChannels[0].playUrl, progress = 21, hue = "#3A1F3F")
    val low = UiMovie("Low Tide", "2024", "A harbor diver hired to recover a sunken car finds the trunk empty — and freshly opened.", meta = "2024 · 1h 58m · Crime", playUrl = demoChannels[2].playUrl, hue = "#23355F")
    val signal = UiMovie("Signal Hill", "2023", "A retired lineman has one night to restore a single tower before the storm cuts the valley off for good.", meta = "2023 · 1h 51m · Action", playUrl = demoChannels[3].playUrl, hue = "#4A241B")
    listOf(
        Rail("Continue watching", listOf(harbor, solstice, tin.copy(progress = 80))),
        Rail("Trending now", listOf(night, low, signal, tin)),
        Rail("New this week", listOf(cart, harbor, night, low)),
        Rail("Action & adventure", listOf(signal, night, low))
    )
}

val demoRadio = listOf(
    UiChannel(1, "Demo Radio One", "Audio · demo", playUrl = demoChannels[0].playUrl),
    UiChannel(2, "Demo Radio Two", "Audio · demo", playUrl = demoChannels[3].playUrl)
)

// demo EPG shown under a highlighted demo channel
val demoEpg = mapOf(
    1 to listOf(UiEpg("Morning Cartoons", "08:00 – 09:00", true), UiEpg("Nature Shorts", "09:00 – 10:00", false), UiEpg("Open Cinema", "10:00 – 11:30", false)),
    2 to listOf(UiEpg("Tech Loop", "08:30 – 09:30", true), UiEpg("Sample Stream Hour", "09:30 – 10:30", false)),
    3 to listOf(UiEpg("Fantasy Feature", "08:00 – 09:45", true), UiEpg("Behind the Scenes", "09:45 – 10:15", false)),
    4 to listOf(UiEpg("Sci-Fi Block", "08:00 – 09:00", true), UiEpg("Making Of", "09:00 – 09:30", false))
)
