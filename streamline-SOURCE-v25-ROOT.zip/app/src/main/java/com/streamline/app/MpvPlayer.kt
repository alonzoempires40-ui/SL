package com.streamline.app

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import dev.jdtech.mpv.MPVLib

/**
 * Third playback engine: mpv (libmpv).
 *
 * WHY THIS EXISTS — it fixes the one thing VLC can't do on this device. The portal's transport
 * streams need HARDWARE video decode to keep up, but libVLC's hardware path on Android won't
 * composite the stream's embedded subtitles onto the surface (so VLC forces a choice: hardware
 * decode with no subs, or software decode with subs but stuttering). mpv hardware-decodes via
 * MediaCodec AND renders subtitles itself (libass) in the same pipeline. The key is
 * `hwdec=mediacodec-copy`: frames are decoded in hardware then copied back so mpv can draw subs
 * and OSD over them.
 *
 * Exposes the same [PlaybackController] surface as [VlcController], so the player overlay drives it
 * without caring which engine is live. Communicates with libmpv through string properties only
 * (the most stable slice of the MPVLib API): get/setPropertyString and command.
 *
 * Track picking for mpv is wired via tracksOfType/selectSpu (the Player's picker uses it); mpv
 * also auto-selects the embedded subtitle/audio by default, which suits most streams here.
 */
class MpvController : PlaybackController {
    // Lifecycle guards so no native call runs before create() or twice across teardown.
    @Volatile var created = false
    @Volatile var attached = false
    @Volatile var ready = false

    private fun prop(name: String): Double =
        if (!ready) 0.0 else MPVLib.getPropertyString(name)?.toDoubleOrNull() ?: 0.0

    override fun isPlaying(): Boolean = ready && MPVLib.getPropertyString("pause") == "no"
    override fun playPause() {
        if (ready) MPVLib.setPropertyString("pause", if (isPlaying()) "yes" else "no")
    }
    override fun positionMs(): Long = (prop("time-pos") * 1000).toLong().coerceAtLeast(0)
    override fun durationMs(): Long = (prop("duration") * 1000).toLong().coerceAtLeast(0)
    override fun seekTo(ms: Long) {
        if (ready) MPVLib.command(arrayOf("seek", (ms / 1000.0).toString(), "absolute"))
    }
    override fun seekBy(deltaMs: Long) {
        if (ready) MPVLib.command(arrayOf("seek", (deltaMs / 1000.0).toString(), "relative"))
    }
    override fun setRate(rate: Float) { if (ready) MPVLib.setPropertyString("speed", rate.toString()) }

    // ---- Track listing / selection via mpv's track-list property ----
    // mpv exposes tracks as numbered properties: track-list/N/{type,id,title,lang}. Read them as
    // strings (the safe API slice) and map to the engine-agnostic TrackOption the picker already uses.
    private fun tracksOfType(kind: String): List<TrackOption> {
        if (!ready) return emptyList()
        val count = MPVLib.getPropertyString("track-list/count")?.toIntOrNull() ?: return emptyList()
        val out = ArrayList<TrackOption>()
        for (i in 0 until count) {
            if (MPVLib.getPropertyString("track-list/$i/type") != kind) continue
            val id = MPVLib.getPropertyString("track-list/$i/id")?.toIntOrNull() ?: continue
            val title = MPVLib.getPropertyString("track-list/$i/title")?.takeIf { it.isNotBlank() }
            val lang = MPVLib.getPropertyString("track-list/$i/lang")?.takeIf { it.isNotBlank() && it != "und" }
            val label = listOfNotNull(title, lang).joinToString(" · ")
                .ifBlank { (if (kind == "audio") "Audio " else "Subtitle ") + id }
            out.add(TrackOption(id, label))
        }
        return out
    }
    override fun audioTracks(): List<TrackOption> = tracksOfType("audio")
    override fun subtitleTracks(): List<TrackOption> = tracksOfType("sub")
    override fun currentAudio(): Int = if (!ready) -1 else MPVLib.getPropertyString("aid")?.toIntOrNull() ?: -1
    override fun currentSpu(): Int = if (!ready) -1 else MPVLib.getPropertyString("sid")?.toIntOrNull() ?: -1
    override fun selectAudio(id: Int) { if (ready) MPVLib.setPropertyString("aid", id.toString()) }
    override fun selectSpu(id: Int) { if (ready) MPVLib.setPropertyString("sid", if (id < 0) "no" else id.toString()) }
    override fun enableFirstSubtitle(): Int {
        // Prefer a Greek-tagged track, then English, else the first sub track — blind "#1" used to
        // lose when a movie's first track was an empty/forced-only one and the real subs were #2.
        if (!ready) return -1
        val count = MPVLib.getPropertyString("track-list/count")?.toIntOrNull() ?: return -1
        var first = -1; var greek = -1; var english = -1
        for (i in 0 until count) {
            if (MPVLib.getPropertyString("track-list/$i/type") != "sub") continue
            val id = MPVLib.getPropertyString("track-list/$i/id")?.toIntOrNull() ?: continue
            val lang = (MPVLib.getPropertyString("track-list/$i/lang") ?: "").lowercase()
            val title = (MPVLib.getPropertyString("track-list/$i/title") ?: "").lowercase()
            if (first < 0) first = id
            if (greek < 0 && (lang.startsWith("el") || lang.startsWith("gre") || title.contains("greek"))) greek = id
            if (english < 0 && (lang.startsWith("en") || title.contains("english"))) english = id
        }
        val pick = when { greek >= 0 -> greek; english >= 0 -> english; else -> first }
        if (pick >= 0) selectSpu(pick)
        return pick
    }
}

@Composable
fun MpvPlayer(
    url: String,
    controller: MpvController,
    modifier: Modifier = Modifier,
    userAgent: String? = null,
    referer: String? = null,
    onError: () -> Unit = {}
) {
    AndroidView(
        factory = { c ->
            SurfaceView(c).apply {
                holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) {
                        runCatching {
                          if (!controller.created) {
                            // First creation: build mpv, set options, load the stream.
                            MPVLib.create(c.applicationContext)
                            controller.created = true

                            // Subtitles need a font with Greek glyphs. mpv loads fonts from the
                            // "fonts" folder inside its config dir, so copy our bundled DejaVu Sans
                            // (broad Greek coverage) there once and point mpv's config dir at it.
                            // Without this, mpv's default font has only Latin glyphs, so Greek
                            // subtitle lines render blank (while Latin lines still show).
                            val mpvCfg = java.io.File(c.applicationContext.filesDir, "mpv")
                            runCatching {
                                val fontsDir = java.io.File(mpvCfg, "fonts")
                                fontsDir.mkdirs()
                                val fontFile = java.io.File(fontsDir, "DejaVuSans.ttf")
                                if (!fontFile.exists()) {
                                    c.applicationContext.assets.open("fonts/DejaVuSans.ttf").use { input ->
                                        fontFile.outputStream().use { output -> input.copyTo(output) }
                                    }
                                }
                            }

                            // ---- options set BEFORE init() ----
                            MPVLib.setOptionString("config", "yes")
                            MPVLib.setOptionString("config-dir", mpvCfg.path)
                            MPVLib.setOptionString("sub-font", "DejaVu Sans")
                            MPVLib.setOptionString("vo", "gpu")
                            MPVLib.setOptionString("gpu-context", "android")
                            // Hardware decode, but copy frames back so mpv composites the subtitles
                            // itself — the whole reason this engine is here.
                            MPVLib.setOptionString("hwdec", "mediacodec-copy")
                            // Auto-select and show the stream's embedded subtitle track.
                            MPVLib.setOptionString("sub-auto", "all")
                            MPVLib.setOptionString("sub-visibility", "yes")
                            // Try UTF-8 first, fall back to Windows-1253 for this portal's legacy
                            // Greek. The "utf8:" prefix means the codepage is used ONLY when the text
                            // isn't valid UTF-8 — so modern UTF-8 subs and legacy Greek both render.
                            MPVLib.setOptionString("sub-codepage", "utf8:windows-1253")
                            // Prefer Greek, then English, when mpv auto-picks a subtitle track at
                            // load — covers tracks that ARE language-tagged without waiting for the
                            // enable-poll. Untagged tracks are handled by enableFirstSubtitle below.
                            MPVLib.setOptionString("slang", "el,ell,gre,en,eng")
                            // Size subtitles relative to the VIDEO frame, not the window. Recent mpv
                            // scales sub text by window HEIGHT by default, so in a tall portrait window
                            // (video letterboxed into a thin band) the subs balloon to fill the screen.
                            // Setting both of these to "no" puts mpv in video-relative sizing, so subs
                            // stay proportional to the picture in BOTH orientations — landscape is
                            // unchanged, portrait shrinks to match.
                            MPVLib.setOptionString("sub-scale-by-window", "no")
                            MPVLib.setOptionString("sub-scale-with-window", "no")
                            // Overall size, from the per-player "MPV" slider. mpv renders subs
                            // smaller than VLC/Exo at the same nominal size, so its 100% baseline is
                            // pushed to 1.3 (vs mpv's own default 1.0) to visually match the others.
                            MPVLib.setOptionString("sub-scale", (1.3 * Prefs.subScaleFor(c, "mpv") / 100.0).toString())
                            // Network: match the box User-Agent (and Referer) the streamer gates on.
                            val ua = userAgent ?: "Mozilla/5.0 (QtEmbedded; U; Linux; C) " +
                                "AppleWebKit/533.3 (KHTML, like Gecko) MAG254 stbapp ver: 4 rev: 2721 Safari/533.3"
                            MPVLib.setOptionString("user-agent", ua)
                            if (referer != null) MPVLib.setOptionString("referrer", referer)
                            MPVLib.setOptionString("tls-verify", "no")
                            // Keep demuxer cache modest for mobile.
                            MPVLib.setOptionString("demuxer-max-bytes", "${32 * 1024 * 1024}")
                            MPVLib.setOptionString("demuxer-max-back-bytes", "${32 * 1024 * 1024}")

                            MPVLib.init()

                            MPVLib.attachSurface(holder.surface)
                            controller.attached = true
                            MPVLib.setOptionString("force-window", "yes")
                            MPVLib.setPropertyString("android-surface-size", "${width}x$height")

                            MPVLib.command(arrayOf("loadfile", url))
                            controller.ready = true
                          } else {
                            // Returning from background: the surface was destroyed then recreated.
                            // Re-attach it to the still-running mpv instead of reloading. Reloading a
                            // live stream jumps back to the live edge, which looks like a restart.
                            MPVLib.attachSurface(holder.surface)
                            controller.attached = true
                            MPVLib.setPropertyString("android-surface-size", "${width}x$height")
                          }
                        }.onFailure { onError() }
                    }

                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
                        if (controller.attached) runCatching {
                            MPVLib.setPropertyString("android-surface-size", "${w}x$h")
                        }
                    }

                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                        if (controller.attached) {
                            controller.attached = false
                            runCatching { MPVLib.detachSurface() }
                        }
                    }
                })
            }
        },
        modifier = modifier
    )

    DisposableEffect(url) {
        onDispose {
            controller.ready = false
            if (controller.attached) {
                controller.attached = false
                runCatching { MPVLib.detachSurface() }
            }
            if (controller.created) {
                controller.created = false
                runCatching {
                    MPVLib.command(arrayOf("stop"))
                    MPVLib.destroy()
                }
            }
        }
    }
}
