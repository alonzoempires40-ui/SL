package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * First-run welcome. Shown once on a fresh install (no saved line yet), then never again — the
 * "setup done" flag is set as soon as a real connection succeeds. Purely a friendly front door:
 * the actual URL/MAC entry + test still happens on the existing Connect screen, so this can't
 * disturb auto-connect or the install-on-top identity.
 */
@Composable
fun WelcomeScreen(onStart: () -> Unit, onDemo: () -> Unit) {
    val accent = accentColor(Prefs.accent(LocalContext.current))
    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("StreamLine", color = accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Your TV line — live channels, movies, series and catch-up.",
                color = TextCol, fontSize = 15.sp)
            Spacer(Modifier.height(22.dp))

            val ctx = LocalContext.current
            val mac = Prefs.mac(ctx)
            var copied by remember { mutableStateOf(false) }
            // Step 1 — the app already HAS the identity; show the MAC, tap to copy.
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(26.dp).background(accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                    Text("1", color = Color(0xFF1A1304), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Your box is ready. This is its MAC address:", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable {
                                val cb = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                cb.setPrimaryClip(android.content.ClipData.newPlainText("StreamLine MAC", mac))
                                copied = true
                            }
                            .background(Panel, RoundedCornerShape(10.dp))
                            .border(1.dp, accent, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(mac, color = accent, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.width(8.dp))
                        Text(if (copied) "copied ✓" else "tap to copy", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            listOf(
                "2" to "Give it to your provider — they register it and give you a portal address back.",
                "3" to "Enter that address. That's everything — channels, guide and movies are ready."
            ).forEach { (n, t) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(26.dp).background(accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text(n, color = Color(0xFF1A1304), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(t, color = Muted, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(26.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF1A1304))) {
                Text("Set up my line", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = onDemo, modifier = Modifier.fillMaxWidth().height(52.dp),
                border = BorderStroke(2.dp, Line),
                colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = TextCol)) {
                Text("Try the demo", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
