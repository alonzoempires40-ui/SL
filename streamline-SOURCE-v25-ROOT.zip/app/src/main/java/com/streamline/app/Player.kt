package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ContextWrapper
import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---- ExoPlayer track helpers (group+track index packed into one id for the picker) ----
private fun exoTrackList(exo: ExoPlayer?, type: Int): List<TrackOption> {
    val out = mutableListOf<TrackOption>()
    val groups = exo?.currentTracks?.groups ?: return out
    groups.forEachIndexed { gi, g ->
        if (g.type != type) return@forEachIndexed
        for (ti in 0 until g.length) {
            val f = g.getTrackFormat(ti)
            val lbl = f.label ?: f.language ?: "Track ${gi + 1}.${ti + 1}"
            out.add(TrackOption(gi * 1000 + ti, lbl, g.isTrackSelected(ti)))
        }
    }
    return out
}
private fun exoSelectTrack(exo: ExoPlayer?, encodedId: Int) {
    val groups = exo?.currentTracks?.groups ?: return
    val gi = encodedId / 1000; val ti = encodedId % 1000
    val g = groups.getOrNull(gi) ?: return
    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
        .setTrackTypeDisabled(g.type, false)   // re-enable this type in case it was disabled earlier
        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, listOf(ti)))
        .build()
}
private fun exoDisableType(exo: ExoPlayer?, type: Int) {
    if (exo == null) return
    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
        .setTrackTypeDisabled(type, true).build()
}

private fun fmt(ms: Long): String {
    if (ms <= 0) return "0:00"
    val total = ms / 1000
    val h = total / 3600; val m = (total % 3600) / 60; val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** Walk the ContextWrapper chain to the hosting Activity (needed to trigger Picture-in-Picture). */
private fun android.content.Context.findActivity(): Activity? {
    var c: android.content.Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

@Composable
fun PlayerScreen(
    title: String,
    number: Int,
    movie: UiMovie?,
    channel: UiChannel?,
    session: Session,
    liveList: List<UiChannel> = emptyList(),
    episodeNumber: String? = null,
    episodes: List<UiEpisode> = emptyList(),
    epIndex: Int = 0,
    onPlayEpisode: (UiEpisode, Int) -> Unit = { _, _ -> },
    archiveStartTs: Long? = null,
    archiveEndTs: Long? = null,
    archiveProgramId: String? = null,
    onZap: (UiChannel) -> Unit = {},
    onRestartProgramme: (EpgProgram) -> Unit = {},
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val goHome = LocalGoHome.current
    var url by remember { mutableStateOf(movie?.playUrl ?: channel?.playUrl) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableStateOf(0) }   // bumping this re-runs the stream fetch
    // Up Next: does this episode have a following one, and has playback hit the end?
    val hasNextEpisode = episodes.isNotEmpty() && epIndex + 1 < episodes.size
    var reachedEnd by remember(url) { mutableStateOf(false) }
    // Engine choice: if the user forced one in Settings, honor it. Otherwise auto-pick by
    // stream type — VLC (which embeds FFmpeg) for MPEG-TS / raw / ffmpeg-style streams,
    // ExoPlayer for clean HLS (.m3u8). This avoids ExoPlayer choking on mpegts first.
    fun pickEngine(u: String?): String {
        val forced = Prefs.engine(ctx)
        if (forced == "vlc") return "vlc"
        if (forced == "exo") return "exo"
        if (forced == "mpv") return "mpv"
        if (u == null) return "exo"
        // Content labelled with embedded Greek subs needs VLC: libVLC ships iconv and can transcode
        // the legacy Windows-1253 / ISO-8859-7 subtitle text into readable Greek. ExoPlayer cannot
        // render this portal's embedded subs at all. Route such titles to VLC automatically. Matches
        // "(Gr Subs)", "Gr.Subs", "Greek Subs", "GrSub", etc., case-insensitively.
        val t = title.lowercase()
        if (Regex("gr(eek)?[\\s._-]*subs?").containsMatchIn(t) || t.contains("greek")) return "vlc"
        val low = u.lowercase()
        val looksHls = low.contains(".m3u8")
        val looksTs = low.contains("mpegts") || low.contains(".ts") || low.contains("/ts") ||
            low.startsWith("rtp") || low.startsWith("udp") || low.startsWith("rtsp")
        return when {
            looksTs -> "mpv"      // mpv HW-decodes transport streams AND draws embedded subs (VLC HW path can't)
            looksHls -> "exo"     // ExoPlayer is solid on HLS
            else -> "exo"         // default; falls back to VLC on error
        }
    }
    var engine by remember { mutableStateOf(pickEngine(movie?.playUrl ?: channel?.playUrl)) }
    var triedMpvAfterVlc by remember { mutableStateOf(false) }
    // Auto-fallback watchdog state (reset per URL): did ExoPlayer ever decode a frame, and have
    // we already handed this URL to VLC once (so we don't ping-pong exo<->vlc).
    var exoStartedVideo by remember(url) { mutableStateOf(false) }
    var exoWatchdogDone by remember(url) { mutableStateOf(false) }
    // A live channel is one with no archive program — catch-up playback has a real, seekable
    // recording even though it also carries a channel reference.
    val isLive = channel != null && archiveStartTs == null

    // The programme currently airing on this live channel. Powers the "Restart programme" button,
    // which replays the show from its start via catch-up — and works even when the day-guide is
    // empty, because the now/next short-EPG (which this reads) is served when the table isn't.
    var liveProg by remember(channel?.id) { mutableStateOf<EpgProgram?>(null) }
    // Original live playlist url, kept so "go to live" can return after a timeshift/rewind swap.
    var liveOriginalUrl by remember(channel?.id) { mutableStateOf<String?>(null) }
    // Live timeshift (server-DVR, NOTHING recorded on the device): when set, we've swapped the live
    // edge for the provider's DVR stream beginning at this wall-clock unix moment, so the user can
    // pause / rewind / scrub recent live. null = watching the true live edge.
    var tsAnchor by remember(channel?.id) { mutableStateOf<Long?>(null) }
    // When live is paused we remember the moment; resuming plays the DVR from there (seamless pause-live).
    var pausedLiveAt by remember(channel?.id) { mutableStateOf<Long?>(null) }
    val tsScope = rememberCoroutineScope()

    // Programme-detail popup (the "EPG" chip in the top bar). The now-playing programme already
    // lives in liveProg with full detail; tapping refreshes it from a fresh get_short_epg so the
    // sheet tracks programme roll-over. Crash-safe: the fetch is runCatching, the sheet handles null.
    var showProgInfo by remember(channel?.id) { mutableStateOf(false) }
    var progInfo by remember(channel?.id) { mutableStateOf<EpgProgram?>(null) }
    var progInfoLoading by remember(channel?.id) { mutableStateOf(false) }
    var showTracks by remember { mutableStateOf(false) }   // audio/subtitle picker overlay
    LaunchedEffect(channel?.id, isLive) {
        val client = session.client
        if (isLive && client != null && channel?.id?.isNotBlank() == true) {
            liveProg = withContext(Dispatchers.IO) {
                runCatching {
                    val now = System.currentTimeMillis() / 1000
                    client.getShortEpg(channel.id!!).firstOrNull { it.startTs in 1..now && now < it.endTs }
                }.getOrNull()
            }
        }
    }
    LaunchedEffect(title, retry) {
        if (url != null) return@LaunchedEffect
        val client = session.client
        try {
            url = withContext(Dispatchers.IO) {
                when {
                    client != null && archiveStartTs != null && channel?.cmd != null -> {
                        // Catch-up: cap the window to "now" for a still-airing programme, then let
                        // the client resolve the live Flussonic url and rewrite it to this archive span.
                        val nowSec = System.currentTimeMillis() / 1000
                        val end = archiveEndTs ?: (archiveStartTs + 3600)
                        val dur = (minOf(end, nowSec) - archiveStartTs).coerceAtLeast(60)
                        val pid = archiveProgramId
                        if (pid.isNullOrBlank())
                            // timestamp seek (older day with no per-day guide) — no programme id
                            client.createCatchupLinkByTime(channel.id ?: "", archiveStartTs, dur)
                        else
                            client.createCatchupLink(pid, channel.cmd, archiveStartTs, dur)
                    }
                    client != null && channel?.cmd != null -> client.createLink(channel.cmd)
                    client != null && movie?.cmd != null && episodeNumber != null -> client.createSeriesLink(movie.cmd, episodeNumber)
                    client != null && movie?.cmd != null -> client.createVodLink(movie.cmd)
                    else -> null
                }
            }
            if (url == null) error = "No stream available"
            else {
                engine = pickEngine(url)        // route to the right engine once we know the URL
                if (isLive && liveOriginalUrl == null) liveOriginalUrl = url
            }
        } catch (e: Exception) { error = e.message ?: "Could not get stream link" }
    }

    // shared playback state, fed by whichever engine is active
    var playing by remember { mutableStateOf(true) }
    var speed by remember(url) { mutableStateOf(1f) }        // 1× normal, 2×/4×/8× fast-forward
    var rewinding by remember(url) { mutableStateOf(false) } // smooth continuous rewind toggle
    var ffHold by remember { mutableStateOf(false) }         // ▶▶ pressed-and-held (accelerating skip)
    var position by remember { mutableStateOf(0L) }
    var duration by remember { mutableStateOf(0L) }
    var controlsVisible by remember { mutableStateOf(true) }
    var barFocus by remember { mutableStateOf(false) }   // ☰ bar-focus mode; declared early so the auto-hide effect can read it
    var lastInteraction by remember { mutableStateOf(System.currentTimeMillis()) }

    // Keep the screen awake while video is actually playing; release it when paused or on exit, so
    // the tablet doesn't dim to standby mid-stream. Tied to `playing` so a paused player can sleep.
    val activity = ctx as? android.app.Activity
    DisposableEffect(playing) {
        val flag = android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        if (playing) activity?.window?.addFlags(flag) else activity?.window?.clearFlags(flag)
        onDispose { activity?.window?.clearFlags(flag) }
    }

    // engine handles
    val exo = remember(url, engine) {
        if (url != null && engine == "exo")
            run {
                // Stalker CDNs gate streams on the box User-Agent (and sometimes Referer);
                // reuse the SESSION's exact UA so the stream fetch matches the API calls.
                val ua = session.client?.streamUserAgent
                    ?: "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG254 stbapp ver: 4 rev: 2721 Safari/533.3"
                val referer = session.client?.streamReferer
                val httpFactory = DefaultHttpDataSource.Factory()
                    .setUserAgent(ua)
                    .setAllowCrossProtocolRedirects(true)
                    .setKeepPostFor302Redirects(true)
                if (referer != null) httpFactory.setDefaultRequestProperties(mapOf("Referer" to referer))
                ExoPlayer.Builder(ctx)
                    .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
                    .build().apply {
                        // Auto-show untagged subtitle tracks too ("und" / "track 1"): the portal's
                        // movie subs usually carry no language tag, and stock ExoPlayer skips those.
                        // (Windows-1253 Greek-encoded subs remain undecodable on Exo — those still
                        // need VLC/mpv; the title regex in pickEngine routes the labelled ones.)
                        trackSelectionParameters = trackSelectionParameters.buildUpon()
                            .setSelectUndeterminedTextLanguage(true).build()
                        setMediaItem(MediaItem.fromUri(url!!)); prepare(); playWhenReady = true
                        addListener(object : Player.Listener {
                            override fun onPlayerError(e: PlaybackException) {
                                if (Prefs.engine(ctx) != "exo") engine = "vlc"  // don't override a forced-Exo choice
                            }
                            override fun onIsPlayingChanged(p: Boolean) { playing = p }
                            override fun onPlaybackStateChanged(state: Int) {
                                if (state == Player.STATE_ENDED) reachedEnd = true
                            }
                            override fun onVideoSizeChanged(vs: VideoSize) {
                                if (vs.width > 0) exoStartedVideo = true   // ExoPlayer actually decoded video
                            }
                        })
                    }
            } else null
    }
    val vlc = remember(url) { VlcController() }
    val mpv = remember(url) { MpvController() }
    // Control surface the overlay drives — whichever non-Exo engine is currently active.
    val active: PlaybackController = if (engine == "mpv") mpv else vlc

    // Up Next: when the ExoPlayer stream ends and a next episode exists, roll to it automatically.
    // (VLC end-detection isn't reliable here, so VLC users use the always-visible Next button.)
    LaunchedEffect(reachedEnd) {
        if (reachedEnd && hasNextEpisode) onPlayEpisode(episodes[epIndex + 1], epIndex + 1)
    }

    DisposableEffect(url, engine) { onDispose { exo?.release() } }

    // Auto-fallback watchdog: when Auto put us on ExoPlayer but no video frame arrives within a
    // few seconds (ExoPlayer silently choking on TS-in-HLS — black with no hard error, so the
    // onPlayerError fallback never fires), hand the stream to VLC. Skipped when the user forced an
    // engine; runs once per URL so we never ping-pong between exo and vlc.
    LaunchedEffect(url, engine) {
        if (url != null && engine == "exo" && !exoWatchdogDone && Prefs.engine(ctx) != "exo") {
            delay(6000)
            if (engine == "exo" && !exoStartedVideo) { exoWatchdogDone = true; engine = "vlc" }
        }
    }

    // ticker: pull position/duration from the active engine, auto-hide controls
    LaunchedEffect(url, engine) {
        while (true) {
            if (engine == "exo" && exo != null) {
                position = exo.currentPosition.coerceAtLeast(0)
                duration = if (exo.duration > 0) exo.duration else 0
                playing = exo.isPlaying
            } else if (engine == "vlc") {
                position = vlc.positionMs(); duration = vlc.durationMs(); playing = vlc.isPlaying()
            } else if (engine == "mpv") {
                position = mpv.positionMs(); duration = mpv.durationMs(); playing = mpv.isPlaying()
            }
            // save resume for VOD/episodes (not live)
            if (!isLive && duration > 0) Prefs.saveResume(ctx, title, position, duration)
            if (controlsVisible && !barFocus && System.currentTimeMillis() - lastInteraction > 4000) controlsVisible = false
            delay(500)
        }
    }

    // VLC: subtitle tracks are not known until playback has actually started and the demuxer has
    // parsed the stream. So we poll after play begins and auto-enable the first subtitle track the
    // moment one appears — this forces embedded subs on without the user having to open the picker.
    var vlcSubEnabled by remember(url, engine) { mutableStateOf(false) }
    LaunchedEffect(url, engine) {
        if (engine != "vlc") return@LaunchedEffect
        // Poll for up to ~20s after playback starts.
        repeat(40) {
            delay(500)
            if (!vlcSubEnabled && vlc.enableFirstSubtitle() >= 0) vlcSubEnabled = true
        }
    }

    // mpv: same story. mpv frequently doesn't auto-show an embedded sub track on network streams,
    // so once the demuxer has parsed tracks we force the first one on — exactly like VLC above.
    // This is why movies played fine on mpv but showed no subs until now.
    var mpvSubEnabled by remember(url, engine) { mutableStateOf(false) }
    LaunchedEffect(url, engine) {
        if (engine != "mpv") return@LaunchedEffect
        // Poll up to ~5 min: on slow portal VOD (and TS streams where the sub track isn't announced
        // until sub data first flows) tracks can appear well after the old 20s window closed.
        repeat(600) {
            delay(500)
            if (!mpvSubEnabled && mpv.enableFirstSubtitle() >= 0) mpvSubEnabled = true
        }
    }

    // resume: seek to saved position once the stream has a known duration (VOD only)
    var resumed by remember { mutableStateOf(false) }
    LaunchedEffect(duration, engine) {
        if (!resumed && !isLive && duration > 0) {
            val r = Prefs.resumeMs(ctx, title)
            if (r in 1 until duration) {
                if (engine == "exo") exo?.seekTo(r) else active.seekTo(r)
            }
            resumed = true
        }
    }

    fun touch() { controlsVisible = true; lastInteraction = System.currentTimeMillis() }
    fun togglePlay() {
        rewinding = false
        if (engine == "exo") exo?.let { if (it.isPlaying) it.pause() else it.play() }
        else active.playPause()
        touch()
    }
    // Explicit (non-toggling) so a voice "pause" can never accidentally resume, and vice-versa.
    fun pausePlayer() {
        rewinding = false
        if (engine == "exo") exo?.pause() else { if (active.isPlaying()) active.playPause() }
        touch()
    }
    fun resumePlayer() {
        rewinding = false
        if (engine == "exo") exo?.play() else { if (!active.isPlaying()) active.playPause() }
        touch()
    }
    // Sleep timer: 0 = off, else minutes. When set, pause playback after that long (so the device
    // can sleep) and reset. Re-arms whenever the value changes (LaunchedEffect keyed on sleepMin).
    var sleepMin by remember { mutableStateOf(0) }
    LaunchedEffect(sleepMin) {
        if (sleepMin > 0) {
            kotlinx.coroutines.delay(sleepMin * 60_000L)
            pausePlayer()
            sleepMin = 0
        }
    }
    fun seekBy(delta: Long) {
        if (engine == "exo") exo?.let {
            val dur = if (it.duration > 0) it.duration else Long.MAX_VALUE
            it.seekTo((it.currentPosition + delta).coerceIn(0, dur))
        }
        else active.seekBy(delta)
        touch()
    }
    fun zap(step: Int) {
        if (liveList.isEmpty() || channel == null) return
        val i = liveList.indexOfFirst { it.number == channel.number }
        if (i < 0) return
        onZap(liveList[(i + step + liveList.size) % liveList.size])
    }

    // Live timeshift transport (server-DVR; nothing is recorded on the device). Swap the live edge for
    // the provider's DVR stream starting at `fromTs` (unix, wall clock) and play it — the same archive
    // link the catch-up path mints — so the user can pause / rewind / scrub recent live like a MAG's
    // TimeShift, except the buffer is the operator's ~14-day DVR, not local disk. Channels without
    // archive have nothing to mint, so this no-ops and we stay on the live edge.
    fun enterTimeshift(fromTs: Long) {
        val client = session.client ?: return
        val chId = channel?.id
        if (chId.isNullOrBlank()) return
        if (liveOriginalUrl == null) liveOriginalUrl = url      // remember the live edge to return to
        pausedLiveAt = null
        touch()
        tsScope.launch {
            val u = withContext(Dispatchers.IO) {
                runCatching {
                    val nowSec = System.currentTimeMillis() / 1000
                    val from = fromTs.coerceIn(nowSec - 14 * 24 * 3600, nowSec - 2)   // inside the DVR, behind live
                    val dur = (nowSec - from).coerceAtLeast(60)                        // window runs to ~now
                    client.createCatchupLinkByTime(chId, from, dur)
                }.getOrNull()
            }
            if (u != null) { error = null; triedMpvAfterVlc = false; tsAnchor = fromTs; url = u; engine = pickEngine(u) }
        }
    }

    fun goLive() {
        tsAnchor = null; pausedLiveAt = null
        val orig = liveOriginalUrl
        if (orig != null && orig != url) { error = null; triedMpvAfterVlc = false; url = orig; engine = pickEngine(orig) }
        else if (!playing) togglePlay()      // already on the live url but paused → just resume
        touch()
    }

    // Volume / mute via the system media stream (shows the standard volume UI). Safe no-op if the
    // AudioManager isn't available.
    fun adjustVolume(dir: Int) {
        val am = ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
        am.adjustStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            if (dir > 0) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
            android.media.AudioManager.FLAG_SHOW_UI
        )
        touch()
    }
    fun toggleMute() {
        val am = ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_TOGGLE_MUTE, android.media.AudioManager.FLAG_SHOW_UI)
        touch()
    }

    // VLC-style transport: smooth fast-forward by raising playback speed, smooth rewind by
    // continuously stepping the position back while engaged (true reverse playback isn't possible
    // with streaming decoders — VLC scrubs the same way).
    fun applySpeed(s: Float) {
        speed = s
        if (engine == "exo") exo?.setPlaybackSpeed(s) else active.setRate(s)
    }
    fun fastForward() {                       // cycle 1× → 2× → 4× → 8× → 1×
        rewinding = false
        applySpeed(when (speed) { 1f -> 2f; 2f -> 4f; 4f -> 8f; else -> 1f })
        touch()
    }
    fun toggleRewind() { applySpeed(1f); rewinding = !rewinding; touch() }
    // while rewinding, step the position back quickly until the start, then stop
    LaunchedEffect(rewinding, engine) {
        while (rewinding) {
            val cur = if (engine == "exo") (exo?.currentPosition ?: 0L) else active.positionMs()
            if (cur <= 0L) { rewinding = false; break }
            seekBy(-4_000)
            delay(250)
        }
    }
    // hold ▶▶ to race forward through the file with an accelerating skip — the longer it's held the
    // bigger each jump, and the jumps scale to the file length so even a multi-hour movie scrubs
    // across in a couple of seconds. A quick tap doesn't reach here (the wait is cancelled on
    // release) so tapping still cycles 1×/2×/4×/8× speed as before.
    LaunchedEffect(ffHold, engine) {
        if (!ffHold) return@LaunchedEffect
        delay(250)                                   // tap-vs-hold threshold
        var step = 12_000L
        while (ffHold) {
            val dur = duration
            // cap each jump at ~1/20th of the file (clamped 30s–10min); fall back to 2min if unknown
            val maxStep = if (dur > 0) (dur / 20).coerceIn(30_000L, 600_000L) else 120_000L
            seekBy(step)
            touch()
            step = (step + step / 2 + 8_000L).coerceAtMost(maxStep)   // ≈1.5× growth per tick
            delay(110)                               // fast ticks for a responsive feel
        }
    }

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focusRequester.requestFocus() } }
    // MAG-remote control-bar navigation. The ☰ Menu key toggles "bar focus": the amber ring lands
    // on the first on-screen control button, the arrows move it (Compose spatial focus), OK presses
    // it, and ☰ again (or Back) leaves. Arrows keep their normal meaning outside bar focus — this
    // remote has dedicated CHAN± (zap), media-transport, ℹ Info and number keys, so nothing needs
    // to be repurposed.
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(barFocus) { if (barFocus) runCatching { playFocus.requestFocus() } }
    fun enterBar() { controlsVisible = true; lastInteraction = System.currentTimeMillis(); barFocus = true }
    fun leaveBar() { barFocus = false; runCatching { focusRequester.requestFocus() }; touch() }
    // If the controls hide for any reason (tap, PiP) while in bar focus, drop bar focus too.
    LaunchedEffect(controlsVisible) { if (!controlsVisible && barFocus) { barFocus = false; runCatching { focusRequester.requestFocus() } } }
    // Typed channel number (MAG numpad): digits accumulate briefly, then tune to that channel.
    var chanEntry by remember { mutableStateOf("") }
    var chanEntryAt by remember { mutableStateOf(0L) }
    fun tuneToNumber(n: Int) {
        val target = liveList.firstOrNull { it.number == n } ?: return
        onZap(target)
    }
    fun pushDigit(d: Int) {
        val nowMs = System.currentTimeMillis()
        chanEntry = (if (nowMs - chanEntryAt > 2500) "" else chanEntry) + d.toString()
        chanEntryAt = nowMs
        touch()
    }
    // commit the typed number after a short pause
    LaunchedEffect(chanEntry, chanEntryAt) {
        if (chanEntry.isNotEmpty()) {
            kotlinx.coroutines.delay(2500)
            if (chanEntry.isNotEmpty() && System.currentTimeMillis() - chanEntryAt >= 2500) {
                chanEntry.toIntOrNull()?.let { tuneToNumber(it) }
                chanEntry = ""
            }
        }
    }

    BackHandler { onBack() }
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(focusRequester)
            .focusable()
            .onPreviewKeyEvent { e ->
                // MAG remote driving. Menu (☰) toggles control-bar focus; Info (ℹ) opens the
                // programme popup on live; CHAN± zap; number keys type a channel; the media transport
                // keys and arrows keep their normal jobs. Center/Enter & Play-Pause toggle playback;
                // Left/Right & FF/RW seek on VOD; Up/Down zap on live; Stop exits.
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                // ---- Bar focus: arrows move the ring (Compose), OK activates; Menu/Back leave. ----
                if (barFocus) {
                    when (e.key) {
                        Key.Menu, Key.Back, Key.Escape -> { leaveBar(); true }
                        else -> false   // Left/Right/Up/Down/OK handled by spatial focus + button onClick
                    }
                } else when (e.key) {
                    // ☰ Menu — enter control-bar navigation
                    Key.Menu -> { enterBar(); true }
                    // ℹ Info — programme detail on live (same as the on-screen EPG chip)
                    Key.Info -> { if (isLive && liveProg != null) { progInfo = liveProg; showProgInfo = true; touch() } else touch(); true }
                    // dedicated channel keys (and Page keys some remotes send) — zap on live
                    Key.ChannelUp, Key.PageUp -> { if (isLive) { touch(); zap(-1) }; true }
                    Key.ChannelDown, Key.PageDown -> { if (isLive) { touch(); zap(1) }; true }
                    // number pad — type a channel number on live
                    Key.Zero, Key.NumPad0 -> { if (isLive) pushDigit(0); true }
                    Key.One, Key.NumPad1 -> { if (isLive) pushDigit(1); true }
                    Key.Two, Key.NumPad2 -> { if (isLive) pushDigit(2); true }
                    Key.Three, Key.NumPad3 -> { if (isLive) pushDigit(3); true }
                    Key.Four, Key.NumPad4 -> { if (isLive) pushDigit(4); true }
                    Key.Five, Key.NumPad5 -> { if (isLive) pushDigit(5); true }
                    Key.Six, Key.NumPad6 -> { if (isLive) pushDigit(6); true }
                    Key.Seven, Key.NumPad7 -> { if (isLive) pushDigit(7); true }
                    Key.Eight, Key.NumPad8 -> { if (isLive) pushDigit(8); true }
                    Key.Nine, Key.NumPad9 -> { if (isLive) pushDigit(9); true }
                    // playback + arrows — unchanged from before
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { if (controlsVisible) togglePlay() else touch(); true }
                    Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause -> { togglePlay(); true }
                    Key.DirectionRight, Key.MediaNext -> { if (!isLive) seekBy(10_000) else touch(); true }
                    Key.DirectionLeft, Key.MediaPrevious -> { if (!isLive) seekBy(-10_000) else touch(); true }
                    Key.MediaFastForward -> { if (!isLive) fastForward() else touch(); true }
                    Key.MediaRewind -> { if (!isLive) toggleRewind() else touch(); true }
                    Key.DirectionUp -> { touch(); if (isLive) zap(-1); true }
                    Key.DirectionDown -> { touch(); if (isLive) zap(1); true }
                    Key.MediaStop -> { onBack(); true }
                    else -> false
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val u = url
        when {
            u == null && error != null -> Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(28.dp)
            ) {
                Text("⚠", fontSize = 34.sp)
                Spacer(Modifier.height(10.dp))
                Text(error!!, color = ErrCol, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { error = null; url = null; retry++ },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))
                    ) { Text("Try again", fontWeight = FontWeight.SemiBold) }
                    Button(
                        onClick = { onBack() },
                        colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = TextCol)
                    ) { Text("Go back") }
                }
            }
            u == null -> CircularProgressIndicator(color = Amber)
            engine == "exo" && exo != null -> AndroidView(
                factory = { c -> PlayerView(c).apply {
                    player = exo
                    useController = false
                    // Match VLC's clean subtitle look. ExoPlayer otherwise honours the device's
                    // system caption style, which on this tablet paints an opaque black box behind
                    // each line. Force white text with an outline and a transparent background.
                    subtitleView?.apply {
                        setApplyEmbeddedStyles(false)
                        setStyle(
                            androidx.media3.ui.CaptionStyleCompat(
                                android.graphics.Color.WHITE,
                                android.graphics.Color.TRANSPARENT,
                                android.graphics.Color.TRANSPARENT,
                                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                                android.graphics.Color.BLACK,
                                null
                            )
                        )
                        // per-player "ExoPlayer" slider: scale Exo's default caption fraction (~0.0533).
                        setFractionalTextSize(0.0533f * Prefs.subScaleFor(ctx, "exo") / 100f)
                    }
                } },
                modifier = Modifier.fillMaxSize()
            )
            engine == "mpv" -> key(u) {
                MpvPlayer(
                    url = u,
                    controller = mpv,
                    modifier = Modifier.fillMaxSize(),
                    userAgent = session.client?.streamUserAgent,
                    referer = session.client?.streamReferer,
                    onError = {
                        // mpv is the strongest engine and the end of the EXO -> VLC -> MPV fallback
                        // chain, so if it can't play the stream there's nowhere stronger to fall to.
                        error = "This stream could not be played."
                    }
                )
            }
            // key(u) forces VlcPlayer to FULLY REMOUNT when the URL changes (next episode, live
            // restart, consecutive Greek titles) instead of recomposing in place. Without this, a
            // URL change while staying on the VLC engine rebuilds the MediaPlayer but the AndroidView
            // factory doesn't re-run, so the old player gets released while still attached to the
            // on-screen layout — the position ticker then touches a freed native object → SIGSEGV
            // (the "app drops in VLC" crash). Remounting re-runs the factory and disposes cleanly.
            else -> key(u) {
                VlcPlayer(
                    url = u,
                    controller = vlc,
                    modifier = Modifier.fillMaxSize(),
                    userAgent = session.client?.streamUserAgent,
                    referer = session.client?.streamReferer,
                    onError = {
                        // VLC couldn't play it — escalate to mpv (the catch-all) once, unless VLC was
                        // forced from Settings. This VLC -> MPV link is what lets a manual VLC pick from
                        // the engine badge drop to mpv on failure instead of dead-ending.
                        if (Prefs.engine(ctx) != "vlc" && !triedMpvAfterVlc) {
                            triedMpvAfterVlc = true
                            engine = "mpv"
                        } else {
                            error = "This stream could not be played."
                        }
                    }
                )
            }
        }

        // Transparent layer above the video so a tap reliably toggles the controls even when the
        // ExoPlayer/VLC surface would otherwise swallow the touch.
        if (u != null) Box(
            Modifier.fillMaxSize().pointerInput(controlsVisible) {
                detectTapGestures(onTap = { if (controlsVisible) controlsVisible = false else touch() })
            }
        )

        if (controlsVisible && u != null) {
            // top bar: title + engine badge
            Row(
                Modifier.align(Alignment.TopStart).fillMaxWidth()
                    .background(Color(0xCC0B0E16)).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Clear Back chip — obvious way out of the player.
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.tvFocus(RoundedCornerShape(10.dp)).clickable { onBack() }
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(4.dp))
                    Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.width(10.dp))
                if (number > 0) {
                    Text(number.toString().padStart(3, '0'), color = Amber, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                }
                Text(title, color = TextCol, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                // Up Next: jump straight to the following episode (also the manual path for VLC playback).
                if (hasNextEpisode) {
                    Text("Next ▶❘", fontSize = 12.sp, color = Amber, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.tvFocus(RoundedCornerShape(10.dp)).clickable { onPlayEpisode(episodes[epIndex + 1], epIndex + 1) }
                            .border(1.dp, Amber, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 7.dp))
                    Spacer(Modifier.width(8.dp))
                }
                // Sleep timer — tap to cycle Off → 15 → 30 → 45 → 60 min
                Text(if (sleepMin > 0) "💤 ${sleepMin}m" else "💤", fontSize = 14.sp,
                    color = if (sleepMin > 0) Amber else Color.White,
                    modifier = Modifier.tvFocus(RoundedCornerShape(10.dp)).clickable {
                        sleepMin = when (sleepMin) { 0 -> 15; 15 -> 30; 30 -> 45; 45 -> 60; else -> 0 }; touch()
                    }
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp))
                Spacer(Modifier.width(8.dp))
                // Home button
                Text("🏠", fontSize = 15.sp,
                    modifier = Modifier.tvFocus(RoundedCornerShape(10.dp)).clickable { goHome() }
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 11.dp, vertical = 7.dp))
                Spacer(Modifier.width(8.dp))
                // Audio / subtitle track picker
                Text("CC", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.tvFocus(RoundedCornerShape(10.dp)).clickable { showTracks = true; touch() }
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp))
                Spacer(Modifier.width(8.dp))
                // Picture-in-picture — shrink playback into a floating window (API 26+; safe no-op otherwise)
                Text("⧉", fontSize = 14.sp, color = Color.White,
                    modifier = Modifier.tvFocus(RoundedCornerShape(10.dp)).clickable {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            controlsVisible = false
                            runCatching { ctx.findActivity()?.enterPictureInPictureMode(PictureInPictureParams.Builder().build()) }
                        }
                    }
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp))
                // EPG / programme-detail chip — appears when this channel has a now-playing programme.
                if (liveProg != null) {
                    Spacer(Modifier.width(8.dp))
                    Text("EPG", color = Amber, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.tvFocus(RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp))
                            .clickable {
                                progInfo = liveProg
                                showProgInfo = true
                                val cid = channel?.id
                                val cl = session.client
                                if (cl != null && !cid.isNullOrBlank()) {
                                    progInfoLoading = true
                                    tsScope.launch {
                                        val fresh = withContext(Dispatchers.IO) {
                                            runCatching {
                                                val now = System.currentTimeMillis() / 1000
                                                val list = cl.getShortEpg(cid)
                                                list.firstOrNull { it.startTs in 1..now && now < it.endTs } ?: list.firstOrNull()
                                            }.getOrNull()
                                        }
                                        if (fresh != null) progInfo = fresh
                                        progInfoLoading = false
                                    }
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 3.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(engine.uppercase(), color = Amber, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.border(1.dp, Line, RoundedCornerShape(6.dp))
                        .clickable { engine = when (engine) { "exo" -> "vlc"; "vlc" -> "mpv"; else -> "exo" }; touch() }
                        .padding(horizontal = 8.dp, vertical = 3.dp))
            }

            // center transport — VLC-style, same button set for live and on-demand so the live
            // player isn't missing controls. Live: ⏮ restart current programme · ◀◀ rewind into the
            // DVR window · ⏯ · ▶▶ step toward live · ⏭ jump to live edge · ⏹. On-demand: ⏮ restart ·
            // ◀◀ smooth rewind · ⏯ · ▶▶ speed-up FF · ⏭ skip +60s · ⏹.
            Row(
                Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLive) {
                    val shifting = tsAnchor != null
                    // ⏮ restart the current show from its start (in place, via the DVR)
                    CircleBtn("⏮", small = true) {
                        val s = liveProg?.startTs
                        if (s != null && s > 0) enterTimeshift(s) else liveProg?.let { onRestartProgramme(it) }
                    }
                    // ◀◀ rewind into the DVR window: drop 30s behind live, or smooth-rewind if already shifting
                    CircleBtn("◀◀", small = true, active = shifting && rewinding) {
                        if (shifting) toggleRewind() else enterTimeshift(System.currentTimeMillis() / 1000 - 30)
                    }
                    // ⏯ pause-live: freeze, then resume from that exact moment via the DVR (no device recording)
                    CircleBtn(if (playing) "⏸" else "▶", small = false, focusReq = playFocus) {
                        when {
                            shifting -> togglePlay()
                            playing -> { pausedLiveAt = System.currentTimeMillis() / 1000; togglePlay() }
                            else -> { val f = pausedLiveAt; if (f != null) enterTimeshift(f) else togglePlay() }
                        }
                    }
                    // ▶▶ speed toward live while shifting; otherwise (already live) refresh the edge
                    CircleBtn(if (shifting && speed != 1f) "${speed.toInt()}×" else "▶▶", small = true, active = shifting && speed != 1f) {
                        if (shifting) fastForward() else goLive()
                    }
                    // ⏭ jump to the live edge
                    CircleBtn("⏭", small = true) { goLive() }
                    CircleBtn("⏹", small = true) { onBack() }
                } else {
                    CircleBtn("⏮", small = true) { if (engine == "exo") exo?.seekTo(0) else active.seekTo(0); touch() }
                    CircleBtn("‹1m", small = true) { seekBy(-60_000); touch() }
                    CircleBtn("◀◀", small = true, active = rewinding) { toggleRewind() }
                    CircleBtn(if (playing) "⏸" else "▶", small = false, focusReq = playFocus) { togglePlay() }
                    CircleBtn(if (speed != 1f) "${speed.toInt()}×" else "▶▶", small = true, active = speed != 1f || ffHold, onHoldChange = { ffHold = it }) { fastForward() }
                    CircleBtn("1m›", small = true) { seekBy(60_000); touch() }
                    CircleBtn("⏹", small = true) { onBack() }
                }
            }

            // live channel zap (right side)
            if (isLive && tsAnchor == null && liveList.size > 1 && archiveStartTs == null) {
                Column(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircleBtn("ᐱ", small = true) { zap(-1) }
                    CircleBtn("ᐯ", small = true) { zap(1) }
                }
            }
            // catch-up: jump straight to LIVE for this channel
            if ((archiveStartTs != null || (isLive && tsAnchor != null)) && channel != null) {
                Row(
                    Modifier.align(Alignment.CenterEnd).padding(end = 14.dp)
                        .background(Color(0x33FF5449), RoundedCornerShape(12.dp))
                        .clickable { if (archiveStartTs != null) onZap(channel) else goLive() }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).background(Color(0xFFFF5449), RoundedCornerShape(4.dp)))
                    Spacer(Modifier.width(8.dp))
                    Text("Go to live", color = Color(0xFFFF8A80), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // bottom bar: time + seek (VOD) or LIVE badge
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Color(0xCC0B0E16)).padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                val shifting = isLive && tsAnchor != null
                if ((isLive && !shifting) || duration <= 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(Color(0xFFFF5449), RoundedCornerShape(4.dp)))
                        Spacer(Modifier.width(8.dp))
                        Text("LIVE", color = Color(0xFFFF5449), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.weight(1f))
                        Text(if (playing) "Playing" else "Paused", color = Muted, fontSize = 12.sp)
                    }
                } else {
                    val anchor = tsAnchor
                    if (shifting && anchor != null) {
                        val behindSec = ((System.currentTimeMillis() / 1000) - (anchor + position / 1000)).coerceAtLeast(0)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
                            Box(Modifier.size(8.dp).background(Amber, RoundedCornerShape(4.dp)))
                            Spacer(Modifier.width(8.dp))
                            Text("TIMESHIFT", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(Modifier.width(10.dp))
                            Text("\u2212${fmt(behindSec * 1000)} behind live", color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Slider(
                        value = if (duration > 0) position.toFloat() / duration else 0f,
                        onValueChange = { frac ->
                            val target = (frac * duration).toLong()
                            if (engine == "exo") exo?.seekTo(target) else active.seekTo(target)
                            touch()
                        },
                        colors = SliderDefaults.colors(thumbColor = Amber, activeTrackColor = Amber, inactiveTrackColor = Line)
                    )
                    Row {
                        Text(fmt(position), color = TextCol, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.weight(1f))
                        Text("-${fmt(duration - position)}", color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.width(10.dp))
                        Text(fmt(duration), color = TextCol, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Programme-detail popup — at the root layer so it survives the auto-hiding controls.
        if (showProgInfo) {
            EpgDetailSheet(
                program = progInfo,
                channelName = channel?.name ?: title,
                loading = progInfoLoading,
                onDismiss = { showProgInfo = false }
            )
        }

        // Audio / subtitle picker — root layer, above the auto-hiding controls.
        if (showTracks) {
            val isExo = engine == "exo"
            val audio = if (isExo) exoTrackList(exo, C.TRACK_TYPE_AUDIO)
                        else active.audioTracks().let { l -> val c = active.currentAudio(); l.map { it.copy(selected = it.id == c) } }
            val subs = if (isExo) exoTrackList(exo, C.TRACK_TYPE_TEXT)
                       else active.subtitleTracks().let { l -> val c = active.currentSpu(); l.map { it.copy(selected = it.id == c) } }
            Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable { showTracks = false },
                contentAlignment = Alignment.Center) {
                Column(Modifier.fillMaxWidth(0.84f).background(Panel, RoundedCornerShape(16.dp)).padding(20.dp)) {
                    Text("Audio & Subtitles", color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Text("AUDIO", color = Amber, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    if (audio.isEmpty()) Text("No alternate audio tracks", color = Muted, fontSize = 13.sp)
                    else audio.forEach { t ->
                        Row(Modifier.fillMaxWidth().clickable {
                                if (isExo) exoSelectTrack(exo, t.id) else active.selectAudio(t.id); showTracks = false
                            }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (t.selected) "● " else "    ", color = Amber, fontSize = 13.sp)
                            Text(t.label, color = TextCol, fontSize = 14.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("SUBTITLES", color = Amber, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth().clickable {
                            if (isExo) exoDisableType(exo, C.TRACK_TYPE_TEXT) else active.selectSpu(-1); showTracks = false
                        }.padding(vertical = 9.dp)) {
                        Text("Off", color = TextCol, fontSize = 14.sp)
                    }
                    if (subs.isEmpty()) Text("No subtitle tracks", color = Muted, fontSize = 13.sp)
                    else subs.forEach { t ->
                        Row(Modifier.fillMaxWidth().clickable {
                                if (isExo) exoSelectTrack(exo, t.id) else active.selectSpu(t.id); showTracks = false
                            }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (t.selected) "● " else "    ", color = Amber, fontSize = 13.sp)
                            Text(t.label, color = TextCol, fontSize = 14.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Close", color = Amber, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.align(Alignment.End).clickable { showTracks = false }.padding(8.dp))
                }
            }
        }
    }
}

@Composable
private fun CircleBtn(glyph: String, small: Boolean, active: Boolean = false, onHoldChange: ((Boolean) -> Unit)? = null, focusReq: FocusRequester? = null, onClick: () -> Unit) {
    val size = if (small) 52.dp else 68.dp
    var focused by remember { mutableStateOf(false) }
    var mod = Modifier.size(size)
    if (focusReq != null) mod = mod.focusRequester(focusReq)
    val base = mod
        .onFocusChanged { focused = it.isFocused }
        .focusable()
        .scale(if (focused) 1.10f else 1f)
        .background(if (active) Color(0xCC3A2E0A) else Color(0xCC141927), RoundedCornerShape(size / 2))
        .border(if (focused) 3.dp else 1.dp, if (focused || active) Amber else Line, RoundedCornerShape(size / 2))
    val interactive = if (onHoldChange != null)
        base.pointerInput(Unit) {
            detectTapGestures(
                onTap = { onClick() },
                onPress = { onHoldChange(true); tryAwaitRelease(); onHoldChange(false) }
            )
        }
    else base.clickable { onClick() }
    Box(interactive, contentAlignment = Alignment.Center) {
        Text(glyph, color = Amber, fontSize = if (small) 15.sp else 26.sp, fontWeight = FontWeight.Bold)
    }
}
