package com.streamline.app

import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * D-pad / TV-remote focus highlight. Apply to any focusable card so that when it
 * gains focus (via a remote's arrow keys) it lifts slightly and shows an amber ring.
 * On a touchscreen this is harmless — it only reacts to actual focus.
 *
 * This both MAKES the element focusable (so a TV remote can land on it) and shows
 * the highlight. Pass autoFocus=true on the first item of a screen so the remote
 * has somewhere to start.
 */
@Composable
fun Modifier.tvFocus(
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(14.dp),
    autoFocus: Boolean = false
): Modifier {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.04f else 1f, tween(120), label = "focusScale")
    val requester = remember { androidx.compose.ui.focus.FocusRequester() }
    if (autoFocus) {
        LaunchedEffect(Unit) {
            try { requester.requestFocus() } catch (_: Exception) {}
        }
    }
    return this
        .focusRequester(requester)
        .onFocusChanged { focused = it.isFocused }
        .focusable()
        .scale(scale)
        .border(if (focused) 2.dp else 0.dp, if (focused) Amber else Color.Transparent, shape)
}

/** A shimmering placeholder block shown while content loads. */
@Composable
fun SkeletonBox(modifier: Modifier = Modifier) {
    val alpha by rememberInfiniteAlpha()
    Box(modifier.background(Color(0xFF1C2336).copy(alpha = alpha), RoundedCornerShape(10.dp)))
}

@Composable
private fun rememberInfiniteAlpha(): State<Float> {
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "shimmer")
    return t.animateFloat(
        initialValue = 0.4f, targetValue = 0.9f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            tween(800), androidx.compose.animation.core.RepeatMode.Reverse
        ), label = "shimmerAlpha"
    )
}

/** A row of skeleton posters for the Video Club / lists while loading. */
@Composable
fun SkeletonRow() {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        SkeletonBox(Modifier.width(140.dp).height(16.dp))
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            repeat(4) { SkeletonBox(Modifier.width(104.dp).height(156.dp)) }
        }
    }
}

/** A friendly empty / error state with an icon glyph, message, and optional hint. */
@Composable
fun EmptyState(glyph: String, title: String, hint: String? = null, isError: Boolean = false) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(glyph, fontSize = 44.sp)
            Spacer(Modifier.height(12.dp))
            Text(title, color = if (isError) ErrCol else TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (hint != null) {
                Spacer(Modifier.height(6.dp))
                Text(hint, color = Muted, fontSize = 13.sp)
            }
        }
    }
}
