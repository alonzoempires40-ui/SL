package com.streamline.app

import okhttp3.OkHttpClient
import okhttp3.Request
import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Stalker/Ministra portal client.
 *
 * The authentication path (handshake → get_profile with the device-id, signature,
 * hw_version_2 and prehash) is the byte-exact StbEmu v2.0.21 algorithm, verified working
 * against a live Ministra line (returns status=0 and loads the real account profile).
 * Demo mode is the fallback only when no portal is configured.
 *
 * Auth fields:
 *  - mac:        the device MAC the portal account is tied to
 *  - deviceId1:  primary device id = uppercase-hex SHA-256 of the MAC (macDeviceId)
 *  - deviceId2:  secondary device id (equals deviceId1 for this portal family)
 *  - signature:  HMAC-SHA256(deviceId1, random), Base64 — validated at get_profile
 * See the "EXACT StbEmu auth crypto" block below for the verified derivations.
 */
class StalkerClient(
    portalInput: String,
    private val mac: String,
    deviceId1: String = "",
    deviceId2: String = "",
    signature: String = "",
    private val serialNumber: String = "",
    private val login: String = "",
    private val password: String = "",
    private val model: String = "MAG254",
    private val ministraMode: Boolean = true
) {

    private val base: String = normalize(portalInput)
    private var endpoint: String? = null
    private var token: String? = null
    private var random: String = ""   // from handshake reply; echoed back in get_profile metrics

    // Proven defaults from open-source Stalker clients (stalkerhek/IPTVnator):
    // most providers accept 64 'f' characters for device ids + signature. We only
    // StbEmu's REAL device-ID derivation (confirmed by reading the decompiled GetUID
    // overloads + ry.C + to.java's generator). For the MAC-based mode:
    //   device_id  = upperHex( SHA-256( MAC ) )   (ry.C uppercased; MAC kept as-is w/ colons)
    //   device_id2 = device_id                    (GetUID('device_id', token) returns device_id)
    //   signature  = ry.D(device_id, random)      (computed per-request in getProfileStep)
    // Explicit caller overrides still win.
    private val devId1: String = deviceId1.ifBlank { macDeviceId(mac) }
    private val devId2: String = deviceId2.ifBlank { devId1 }
    private val sig: String = signature.ifBlank { devId1 }


    // User-Agent that MATCHES the chosen model (STB Emu does this). A portal doing
    // strict_stb_type_check rejects a UA claiming a different model than stb_type.
    // The ver/rev firmware values are the standard ones per MAG model.
    private val UA: String = run {
        val (ver, rev) = when (model) {
            "MAG250" -> "2" to "250"
            "MAG254" -> "4" to "2721"
            "MAG256", "MAG322" -> "4" to "2721"
            "MAG349", "MAG351", "MAG352", "MAG420", "MAG424", "MAG424W3",
            "MAG520", "MAG524", "MAG540", "MAG544" -> "5" to "2721"
            else -> "4" to "2721"
        }
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) " +
            "$model stbapp ver: $ver rev: $rev Safari/533.3"
    }

    /** The exact User-Agent this session uses for portal calls — the player should reuse it
     *  so the stream fetch and the API calls present the SAME model to the CDN. */
    val streamUserAgent: String get() = UA
    /** Referer the box sends; some CDNs gate streams on it in addition to the UA. */
    val streamReferer: String get() = "$base/c/"

    /** A URL on the portal host, used by the in-app speed test to measure the real path. */
    fun speedTestUrl(): String {
        val origin = Regex("^(https?://[^/]+)").find(base)?.groupValues?.get(1) ?: base
        return "$origin/stalker_portal/misc/logos/320/"
    }

    /** In-app speed test latency: times a small AUTHENTICATED request to the portal using the
     *  same client/headers that load channels. (A raw HttpURLConnection with no UA/cookie/auth
     *  gets rejected, which is why the old speed test always failed.) */
    fun pingPortal(): Long {
        val ep = endpoint ?: return -1L
        return kotlin.system.measureTimeMillis {
            val req = okhttp3.Request.Builder()
                .url("$ep?type=stb&action=get_profile&JsHttpRequest=1-xml").build()
            http.newCall(req).execute().use { it.body?.byteStream()?.read() }
        }
    }

    /** Download-throughput sample: pulls a real authenticated portal response (the full channel
     *  list — a large JSON) through the working client and returns (bytesRead, millis). */
    fun speedSample(): Pair<Long, Long> {
        val ep = endpoint ?: throw RuntimeException("not connected")
        var bytes = 0L
        val ms = kotlin.system.measureTimeMillis {
            val req = okhttp3.Request.Builder()
                .url("$ep?type=itv&action=get_all_channels&JsHttpRequest=1-xml").build()
            http.newCall(req).execute().use { resp ->
                resp.body?.byteStream()?.use { input ->
                    val buf = ByteArray(16 * 1024)
                    while (true) { val n = input.read(buf); if (n < 0) break; bytes += n }
                }
            }
        }
        return bytes to ms
    }

    // Holds any cookies the portal sets (e.g. a PHP session). The real box keeps these
    // in the browser and sends them back; without this our fixed Cookie header clobbered
    // the portal's session, which is why data calls failed "Authorization failed" even
    // though get_profile (which established the session) succeeded.
    private val portalCookies = java.util.concurrent.ConcurrentHashMap<String, String>()

    private val cookieJar = object : okhttp3.CookieJar {
        override fun saveFromResponse(url: okhttp3.HttpUrl, cookies: List<okhttp3.Cookie>) {
            for (c in cookies) portalCookies[c.name] = c.value
        }
        override fun loadForRequest(url: okhttp3.HttpUrl): List<okhttp3.Cookie> {
            val host = url.host
            return portalCookies.map {
                okhttp3.Cookie.Builder().name(it.key).value(it.value).domain(host).path("/").build()
            }
        }
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .cookieJar(cookieJar)   // persist portal-set cookies (session) across calls
        // Re-apply our identity headers on EVERY request, including redirected ones
        // (a redirect from /s/ → /stalker_portal/ or http → https can otherwise drop
        //  the mac Cookie and Authorization, causing "Authorization failed").
        .addInterceptor { chain ->
            val orig = chain.request()
            // Merge our identity cookies (mac/lang/timezone) WITH any portal session cookies,
            // instead of overwriting. Identity values take priority for their keys.
            val merged = LinkedHashMap<String, String>()
            for ((k, v) in portalCookies) merged[k] = v
            merged["mac"] = URLEncoder.encode(mac, "UTF-8")
            merged["stb_lang"] = "en"
            merged["timezone"] = "Europe/London"
            val cookieHeader = merged.entries.joinToString("; ") { "${it.key}=${it.value}" }
            val b = orig.newBuilder()
                .header("User-Agent", UA)
                .header("Cookie", cookieHeader)
                .header("X-User-Agent", "Model: $model; Link: WiFi")
                .header("Referer", "$base/c/")
            token?.let { b.header("Authorization", "Bearer $it") }
            chain.proceed(b.build())
        }
        .build()

    companion object {
        /** A digest → uppercase hex. */
        private fun digestHex(algo: String, input: ByteArray): String {
            val md = java.security.MessageDigest.getInstance(algo)
            return md.digest(input).joinToString("") { "%02X".format(it) }
        }
        /** SHA-256 → uppercase hex (string input). */
        fun sha256Hex(input: String): String = digestHex("SHA-256", input.toByteArray(Charsets.UTF_8))

        // ─── The EXACT StbEmu auth crypto (decompiled from StbEmu v2.0.21) ───
        // These produce device_id, signature, hw_version_2 and prehash — the values a
        // strict Ministra portal validates. Without them the portal says "missing hash".

        /** ry.Q: lowercase-hex SHA-1, ISO-8859-1 charset (StbEmu's exact impl). */
        private fun qSha1(s: String): String {
            val md = java.security.MessageDigest.getInstance("SHA-1")
            val bytes = md.digest(s.toByteArray(Charsets.ISO_8859_1))
            return bytes.joinToString("") { ((it.toInt() and 0xFF) + 0x100).toString(16).substring(1) }
        }

        /** ry.C: lowercase-hex SHA-256, UTF-8 (StbEmu's exact impl). device_id = upper(C(mac)). */
        private fun cSha256(s: String): String {
            val md = java.security.MessageDigest.getInstance("SHA-256")
            val bytes = md.digest(s.toByteArray(Charsets.UTF_8))
            return bytes.joinToString("") { ((it.toInt() and 0xFF) + 0x100).toString(16).substring(1) }
        }

        /** StbEmu's hardcoded salt used inside GetHashVersion1. */
        private const val STB_SALT = "dA0j6HpVFcMgNjUBDr0QhwTBIzLHDIrynuQy4XNJ"

        /** GetHashVersion1(d1,d2) = Q( Q( Q(d1) + SALT ) + d2 ). Used for hw_version_2 & prehash. */
        fun getHashVersion1(data1: String, data2: String = ""): String {
            val inner = qSha1(qSha1(data1) + STB_SALT)
            return qSha1(inner + data2)
        }

        /**
         * ry.D: Base64( HMAC-SHA256(key, data) ) using Base64 flag 0 = DEFAULT, which
         * appends a trailing '\n'. We must keep that newline to byte-match StbEmu.
         * Used for the signature: ry.D(device_id, random).
         */
        fun hmacB64(data: String, key: String): String {
            return try {
                val mac = javax.crypto.Mac.getInstance("HmacSHA256")
                mac.init(javax.crypto.spec.SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
                // Base64.DEFAULT matches StbEmu's Base64.encode(..,0): includes the trailing newline.
                android.util.Base64.encodeToString(
                    mac.doFinal(data.toByteArray(Charsets.UTF_8)),
                    android.util.Base64.DEFAULT
                )
            } catch (e: Exception) { "" }
        }

        /** StbEmu's MAC-based device_id: upperHex( SHA-256( mac ) ). MAC kept as-is (colons). */
        fun macDeviceId(mac: String): String = cSha256(mac).uppercase()

        fun normalize(input: String): String {
            var s = input.trim()
            if (s.isEmpty()) throw IllegalArgumentException("Portal address is empty")
            // If they typed just a host (e.g. "a.ip4u.cfd"), default to https — modern
            // portals are https and starting there skips the http→https redirect. If they
            // explicitly typed http://, respect it.
            if (!s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
            s = s.removeSuffix("/")
            // tolerate a trailing "/c" or "/c/" (the box's client folder) — the API lives
            // at <portal>/server/load.php, not under /c.
            s = s.removeSuffix("/c").removeSuffix("/c/")
            s = s.removeSuffix("/")
            return s
        }

        fun sha256(input: String): String {
            val md = java.security.MessageDigest.getInstance("SHA-256")
            return md.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }.uppercase()
        }
    }

    private fun candidates(): List<String> {
        // Behave like a real MAG box: use the portal URL the user gave us, AS GIVEN.
        // The portal path can be anything — /stalker_portal/, /c/, /s/, /portal/, etc.
        // We must NOT assume it's called "stalker_portal".
        val u = base.lowercase()

        // 1. They gave the exact endpoint already — honour it, nothing else.
        if (u.endsWith("load.php") || u.endsWith("portal.php")) {
            return listOf(base)
        }

        // 2. They gave a portal base WITH a path (e.g. .../s, .../stalker_portal,
        //    .../portal). Use THEIR path and append the standard /server/load.php.
        //    base looks like  https://host[:port]/<path...>
        val afterHost = base.substringAfter("://").substringAfter("/", "")  // "" if bare host
        if (afterHost.isNotBlank()) {
            // they included a path — derive load.php under THAT path, as the box does
            return listOf(
                "$base/server/load.php",   // most common: <portal>/server/load.php
                "$base/load.php"           // some portals put load.php directly under the path
            )
        }

        // 3. A bare host with no path — try the usual Stalker locations, most common first.
        //    /stalker_portal/ is by far the most common, so it leads.
        return listOf(
            "$base/stalker_portal/server/load.php",
            "$base/server/load.php",
            "$base/portal.php",
            "$base/c/server/load.php"
        )
    }

    private fun get(url: String): JSONObject {
        // Data calls occasionally come back as an HTML page instead of JSON when the request passes
        // through the /s/ → /stalker_portal/ redirect (the redirect page itself, or a transient
        // session hiccup), and once connected a flaky link can drop a request outright. Retry a few
        // times with exponential backoff + jitter so a brief blip doesn't surface as a failure.
        // NETWORK errors are only retried after we hold a session token (mid-session); during the
        // initial handshake we fail fast so a dead endpoint is skipped quickly instead of multiplying
        // the connect timeout. HTML hiccups return instantly, so those always retry.
        var last: Exception? = null
        val maxAttempts = 3
        for (attempt in 1..maxAttempts) {
            try {
                return getOnce(url)
            } catch (e: HtmlNotJsonException) {
                last = e
                if (attempt >= maxAttempts) break
                sleepBackoff(attempt, "got HTML")
            } catch (e: java.io.IOException) {
                last = e
                if (token == null || attempt >= maxAttempts) break   // fail fast during handshake
                sleepBackoff(attempt, "network ${e.message ?: "blip"}")
            }
        }
        throw last ?: RuntimeException("Portal request failed")
    }

    /** Exponential backoff with jitter (~400ms, then ~800ms, plus up to half again at random) so
     *  retries don't hammer the portal in lockstep. */
    private fun sleepBackoff(attempt: Int, why: String) {
        val base = 400L shl (attempt - 1)
        val wait = base + (Math.random() * base * 0.5).toLong()
        ConnectLog.step("  retry", "$why; backing off ${wait}ms (attempt $attempt)")
        Thread.sleep(wait)
    }

    /** Thrown when the portal returns HTML (not JSON) so get() can retry. */
    private class HtmlNotJsonException : RuntimeException("Portal returned a web page, not data")

    private fun getOnce(url: String): JSONObject {
        // log the full request line tagged with WHAT the call is for, so the log reads at a glance
        val action = if (url.contains("action=")) url.substringAfter("action=").substringBefore("&") else "?"
        ConnectLog.step("→ GET [${friendlyTag(url)}] [$action]", url)
        ConnectLog.step("  headers", "Model: $model" + (token?.let { "; Bearer ${it.take(8)}…" } ?: ""))
        val b = Request.Builder().url(url)
        http.newCall(b.build()).execute().use { resp ->
            val finalUrl = resp.request.url.toString()
            if (finalUrl.substringBefore("?") != url.substringBefore("?")) {
                ConnectLog.step("  ↳ redirected to", finalUrl.substringBefore("?"))
            }
            resp.priorResponse?.let {
                ConnectLog.step("  ↳ via", "HTTP ${it.code} from ${it.request.url.toString().substringBefore("?")}")
            }
            var body = resp.body?.string() ?: ""
            if (body.startsWith("\uFEFF")) body = body.substring(1)
            ConnectLog.step("← HTTP ${resp.code}", "${body.length} bytes")
            val setCookies = resp.headers("Set-Cookie")
            if (setCookies.isNotEmpty()) {
                ConnectLog.step("  ↳ portal set cookies", setCookies.joinToString("; ") { it.substringBefore(";") })
            }
            if (!resp.isSuccessful) {
                ConnectLog.step("  reply", "HTTP error ${resp.code}: " + body.take(500).replace("\n", " "))
                throw RuntimeException("Portal answered HTTP ${resp.code}")
            }
            if (body.isBlank()) {
                ConnectLog.step("  reply", "empty")
                throw RuntimeException("Portal sent an empty reply")
            }
            val trimmed = body.trim()
            if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
                ConnectLog.step("  reply", "not JSON: " + trimmed.take(500).replace("\n", " "))
                throw HtmlNotJsonException()
            }
            // generous reply preview, then pull stream URLs / archive flags onto their own lines
            ConnectLog.step("  reply", "JSON: " + trimmed.take(240).replace("\n", " "))
            val parsed = JSONObject(trimmed)
            logStreamsAndArchive(parsed)
            return parsed
        }
    }

    /** Friendly category for a portal call, so the log reads at a glance. */
    private fun friendlyTag(url: String): String {
        val type = Regex("type=([a-z_]+)").find(url)?.groupValues?.get(1).orEmpty()
        val action = Regex("action=([a-z_]+)").find(url)?.groupValues?.get(1).orEmpty()
        return when {
            type == "radio" -> "RADIO"
            action == "create_link" && type == "vod" -> "VOD STREAM LINK"
            action == "create_link" -> "LIVE/STREAM LINK"
            action == "get_all_channels" -> "CHANNELS"
            action == "get_simple_data_table" -> "EPG/CATCH-UP"
            action == "get_short_epg" -> "EPG NOW/NEXT"
            action == "get_ordered_list" -> "VOD/SERIES LIST"
            action == "get_categories" || action == "get_genres" -> "CATEGORIES"
            action.contains("app") || type.contains("app") || action.contains("module") -> "PORTAL APPS"
            action == "handshake" -> "HANDSHAKE"
            action == "get_profile" -> "PROFILE"
            else -> action.uppercase().ifBlank { "CALL" }
        }
    }

    /** Pull the things needed to crack Flussonic / radio / apps out of a reply: a single
     *  create_link 'cmd' (the stream URL), and for list replies each item's name + cmd (the
     *  link behind the name) + tv_archive flag — full values, one compact entry per reply. */
    private fun logStreamsAndArchive(reply: JSONObject) {
        if (!ConnectLog.enabled) return
        when (val js = reply.opt("js")) {
            is JSONObject -> {
                js.optString("cmd").takeIf { it.isNotBlank() }?.let { ConnectLog.add("  ★ STREAM URL = $it") }
                js.optJSONArray("data")?.let { logListSample(it) }
            }
            is JSONArray -> logListSample(js)
        }
    }

    private fun logListSample(data: JSONArray) {
        val n = minOf(data.length(), 3)
        if (n == 0) return
        val sb = StringBuilder("  ★ list: ${data.length()} items, first $n (name → link behind it, + archive):")
        for (i in 0 until n) {
            val o = data.optJSONObject(i) ?: continue
            val name = o.optString("name").ifBlank { o.optString("title") }
            val cmd = o.optString("cmd")
            val arch = o.optString("tv_archive_duration").ifBlank { o.optString("tv_archive").ifBlank { o.optString("archive") } }
            sb.append("\n    • [$i]")
            if (name.isNotBlank()) sb.append(" name=").append(name)
            if (cmd.isNotBlank()) sb.append("  cmd=").append(cmd)
            if (arch.isNotBlank() && arch != "0") sb.append("  archive=").append(arch)
        }
        ConnectLog.add(sb.toString())
    }

    private fun api(params: String): Any {
        val ep = endpoint ?: throw IllegalStateException("Not connected")
        val obj = get("$ep?$params&JsHttpRequest=1-xml")
        if (!obj.has("js")) throw RuntimeException("Portal reply missing data")
        return obj.get("js")
    }

    /** Step 1: find a working endpoint and obtain a session token. */
    fun handshake() {
        ConnectLog.step("════════════ NEW CONNECTION ════════════", "portal base: $base")
        for (cand in candidates()) {
            try {
                ConnectLog.step("Trying endpoint", cand)
                // The real box sends prehash = GetHashVersion1(type, version[:56]) in handshake too.
                val preEnc = URLEncoder.encode(getHashVersion1(model, verStr.take(56)), "UTF-8")
                val obj = get("$cand?type=stb&action=handshake&token=&prehash=$preEnc&JsHttpRequest=1-xml")
                val js = obj.optJSONObject("js")
                val t = js?.optString("token").orEmpty()
                if (t.isNotEmpty()) {
                    endpoint = cand
                    token = t
                    random = js.optString("random").orEmpty()
                    ConnectLog.step("HANDSHAKE OK", "got token (${t.length} chars), random=${if (random.isBlank()) "none" else "yes"}")
                    return
                }
                ConnectLog.step("Handshake reply", "no token in JSON")
            } catch (e: Exception) {
                ConnectLog.step("Endpoint failed", e.message ?: "error")
            }
        }
        ConnectLog.step("HANDSHAKE FAILED", "no endpoint returned a token")
        throw RuntimeException("Couldn't connect to the portal. Check the address and your MAC, then try again.")
    }

    /** Step 2: register this device profile with the portal. */
    // The firmware image description StbEmu sends per model (read from the StbEmu APK).
    // Portals doing strict checks match this against the model.
    /** Per-model device identity, taken from StbEmu v2.0.21's own model table (decompiled APK,
     *  cross-checked against the StbEmu UI). Each MAG reports a different firmware image, image
     *  version and image date. ONLY the first 56 chars of the composite ver string feed the login
     *  prehash ("ImageDescription: <fw>; ImageDate: <DayOfWeek Month>"), so those are the load-bearing
     *  values; hw_version (1.7-BD-00) and num_banks (2) are constant across models (confirmed in
     *  StbEmu + on-device). MAG254 is kept BYTE-IDENTICAL to the proven-working config and is the safe
     *  default. MAG540/544 have no published StbEmu profile, so they borrow the newest real 4K box
     *  (524) as the closest same-generation match — if a portal refuses them, switch back to MAG254. */
    private data class StbId(val firmware: String, val imageVersion: String, val imageDate: String)
    private val stbId: StbId = when (model) {
        "MAG250"                          -> StbId("0.2.18-r14-pub-250", "218", "Fri Jan 15 15:20:44 EET 2016")
        "MAG254"                          -> StbId("0.2.18-r23-pub-254", "218", "Wed Aug 28 18:30:00 EEST 2019")
        "MAG254W1", "MAG254W2",
        "MAG255", "MAG255W1", "MAG255W2"  -> StbId("0.2.18-r23-pub-254", "218", "Wed Aug 29 10:49:26 EEST 2018")
        "MAG256"                          -> StbId("2.20.05-256-pub",    "220", "Thu Jul 12 18:20:04 EEST 2018")
        "MAG260"                          -> StbId("Release-R6",         "218", "30 Nov 2012 14:43:29 GMT+0200")
        "MAG270"                          -> StbId("0.2.18-r22-pub-270", "218", "Tue Dec 19 11:33:53 EET 2017")
        "MAG275"                          -> StbId("0.2.18-r19-pub-270", "218", "Mon Jun 12 11:44:43 EEST 2017")
        "MAG322", "MAG324"                -> StbId("2.20.10-pub-324",    "220", "Mon Nov 18 13:54:46 UTC 2019")
        "MAG349"                          -> StbId("2.20.03-pub-349",    "220", "Fri Aug 17 17:06:08 EEST 2018")
        "MAG351", "MAG352"                -> StbId("2.20.03-pub-351",    "220", "Thu May 31 14:11:57 EEST 2018")
        "MAG420"                          -> StbId("2.20.02-r6-pub-420", "220", "Fri Oct 4 10:13:21 UTC 2019")
        "MAG424", "MAG424W3"              -> StbId("2.20.02-pub-424",    "220", "Fri May 8 15:39:55 UTC 2020")
        "MAG520"                          -> StbId("2.20.02-pub-520",    "220", "Thu Apr 29 15:17:55 EEST 2021")
        "MAG524"                          -> StbId("2.20.02-pub-524",    "220", "Thu Apr 29 15:38:34 EEST 2021")
        "MAG540", "MAG544"                -> StbId("2.20.02-pub-524",    "220", "Thu Apr 29 15:38:34 EEST 2021")
        else                              -> StbId("0.2.18-r23-pub-254", "218", "Wed Aug 28 18:30:00 EEST 2019")
    }

    // The full composite version string the real box reports (xpcom.common.js:1059). The prehash
    // hashes its FIRST 56 CHARS ("ImageDescription: <fw>; ImageDate: <DayOfWeek Month>"), driven by
    // the per-model values above; the PORTAL/API tail past char 56 is cosmetic and kept constant.
    private val verStr: String =
        "ImageDescription: ${stbId.firmware}; ImageDate: ${stbId.imageDate}; PORTAL version: 5.6.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c"

    fun getProfile(): JSONObject {
        // First profile request (auth_second_step=0), then — for Ministra portals — a
        // SECOND request with auth_second_step=1. StbEmu's "Applying auth fix for Ministra"
        // does exactly this; it's what makes strict Ministra portals authorize the device.
        val first = getProfileStep(false)
        // If the portal didn't fully authorize on step 0 (Ministra behaviour), do step 1.
        val needsSecond = first.optInt("status", 0) == 1 || ministraMode
        if (needsSecond) {
            ConnectLog.step("MINISTRA", "applying auth fix (get_profile auth_second_step=1)")
            val second = getProfileStep(true)
            if (second.length() > 0) return second
        }
        return first
    }

    /**
     * Account info for the Account screen. Pulls type=account_info&action=get_main_info and
     * returns ONLY the non-sensitive fields (status, expiry date, tariff). The server URL,
     * account id, MAC, phone and balance are deliberately NOT returned — they're identifying
     * or private and shouldn't be shown on screen.
     */
    fun getAccountInfo(): AccountInfo {
        val obj = runCatching { api("type=account_info&action=get_main_info") as? JSONObject }.getOrNull()
        val endDate = obj?.optString("end_date").orEmpty()
        val tariff = obj?.optString("tariff_plan").orEmpty()
        // Status: parse end_date and compare to now. Ministra returns either a Unix timestamp
        // (seconds) or a human date like "October 15, 2025" / "2025-10-15". If we can read it,
        // report Active/Expired accurately; if it's blank or unparseable, "Unknown" (many lines
        // legitimately don't expose end_date — we don't claim Active we can't prove).
        val endMillis: Long? = run {
            if (endDate.isBlank()) return@run null
            endDate.trim().toLongOrNull()?.let { return@run it * 1000L }  // unix seconds
            val fmts = listOf("MMMM d, yyyy", "yyyy-MM-dd", "dd-MM-yyyy", "dd/MM/yyyy", "yyyy-MM-dd HH:mm:ss")
            for (f in fmts) {
                runCatching {
                    java.text.SimpleDateFormat(f, java.util.Locale.US)
                        .apply { isLenient = false }.parse(endDate.trim())?.time
                }.getOrNull()?.let { return@run it }
            }
            null
        }
        val status = when {
            endMillis == null -> "Unknown"
            endMillis >= System.currentTimeMillis() -> "Active"
            else -> "Expired"
        }
        return AccountInfo(status = status, expires = endDate, tariff = tariff)
    }

    private fun getProfileStep(secondStep: Boolean): JSONObject {
        val d1 = URLEncoder.encode(devId1, "UTF-8")
        val d2 = URLEncoder.encode(devId2, "UTF-8")
        // metrics MUST be an ORDERED JSON string (mac, sn, model, type, uid, random) — the
        // hash is order-sensitive and JSONObject.toString() doesn't guarantee key order.
        // uid = device_id2 (which == device_id). Build it by hand to fix the order.
        fun jStr(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")
        val metricsJson = "{" +
            "\"mac\":\"${jStr(mac)}\"," +
            "\"sn\":\"${jStr(serialNumber)}\"," +
            "\"model\":\"${jStr(model)}\"," +
            "\"type\":\"STB\"," +
            "\"uid\":\"${jStr(devId2)}\"," +
            "\"random\":\"${jStr(random)}\"" +
            "}"
        val metricsEnc = URLEncoder.encode(metricsJson, "UTF-8")
        val ts = (System.currentTimeMillis() / 1000).toString()
        val verEnc = URLEncoder.encode(verStr, "UTF-8")
        val step = if (secondStep) "1" else "0"

        // ── The StbEmu auth values the portal validates (all verified from decompiled StbEmu) ──
        // signature    = ry.D(device_id, random)               = Base64(HMAC-SHA256(key=random, device_id)) WITH trailing \n
        // hw_version_2 = GetHashVersion1(orderedMetrics, random)= the salted triple-SHA-1 (the "hash")
        // prehash      = GetHashVersion1(type, version[:56])    = hash of the 56-char slice of the COMPOSITE ver string
        // api_signature= count of gSTB props (fixed for the emulated API)
        val signature = hmacB64(devId1, random)
        val hwVersion2 = getHashVersion1(metricsJson, random)
        val prehash = getHashVersion1(model, verStr.take(56))
        val sgEnc = URLEncoder.encode(signature, "UTF-8")   // trailing \n becomes %0A — correct
        val hw2Enc = URLEncoder.encode(hwVersion2, "UTF-8")
        val preEnc = URLEncoder.encode(prehash, "UTF-8")

        val params = "type=stb&action=get_profile&hd=1&auth_second_step=$step" +
            "&device_id=$d1&device_id2=$d2&signature=$sgEnc" +
            "&sn=${URLEncoder.encode(serialNumber, "UTF-8")}&stb_type=$model&client_type=STB&hw_version=1.7-BD-00&not_valid_token=0" +
            "&metrics=$metricsEnc&hw_version_2=$hw2Enc&prehash=$preEnc&api_signature=263" +
            "&timestamp=$ts&ver=$verEnc&num_banks=2&image_version=${stbId.imageVersion}"
        val js = api(params)
        val profile = js as? JSONObject ?: JSONObject()
        if (profile.length() > 0) {
            ConnectLog.step("GET_PROFILE OK (step $step)", "fields: ${profile.length()}" +
                (profile.optString("name").takeIf { it.isNotBlank() }?.let { ", name=$it" } ?: "") +
                (profile.optString("status").takeIf { it.isNotBlank() }?.let { ", status=$it" } ?: "") +
                (profile.optString("msg").takeIf { it.isNotBlank() }?.let { ", msg=$it" } ?: ""))
        } else {
            ConnectLog.step("GET_PROFILE (step $step)", "empty profile returned")
        }
        return profile
    }

    /**
     * Step 2b (only some portals): username + password login.
     * The real box sends this via action=do_auth when the account is credential-based
     * (it reads login/password the user typed). Safe to call only when we have them.
     * Returns true if the portal accepted the credentials.
     */
    fun doAuth(): Boolean {
        if (login.isBlank() && password.isBlank()) {
            ConnectLog.step("DO_AUTH", "skipped (MAC-only, no username/password)")
            return true   // nothing to send; MAC-only portal
        }
        val d1 = URLEncoder.encode(devId1, "UTF-8")
        val d2 = URLEncoder.encode(devId2, "UTF-8")
        val params = "type=stb&action=do_auth" +
            "&login=${URLEncoder.encode(login, "UTF-8")}" +
            "&password=${URLEncoder.encode(password, "UTF-8")}" +
            "&device_id=$d1&device_id2=$d2"
        return try {
            val js = api(params)
            val ok = when (js) {
                is Boolean -> js
                is Int -> js == 1
                is String -> js == "1" || js.equals("true", true)
                else -> true
            }
            ConnectLog.step("DO_AUTH ${if (ok) "OK" else "REJECTED"}", "username login")
            ok
        } catch (e: Exception) {
            ConnectLog.step("DO_AUTH FAILED", e.message ?: "error")
            false
        }
    }

    // Per-session caches — the channel list is ~4.4 MB and genres rarely change within a
    // session, so fetch each once and reuse. Cleared only when the client is recreated
    // (i.e. on reconnect), which is the right lifetime for this data.
    @Volatile private var cachedGenres: List<Pair<String, String>>? = null
    @Volatile private var cachedChannels: List<PortalChannel>? = null

    /** Live TV genres (categories). */
    fun getGenres(): List<Pair<String, String>> {
        cachedGenres?.let { return it }
        val js = api("type=itv&action=get_genres")
        val arr = js as? JSONArray ?: run {
            ConnectLog.step("GET_GENRES", "no list returned (got ${js::class.simpleName})")
            return emptyList()
        }
        val out = mutableListOf<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val g = arr.optJSONObject(i) ?: continue
            out.add(g.optString("id") to g.optString("title"))
        }
        ConnectLog.step("GET_GENRES OK", "${out.size} categories")
        cachedGenres = out
        return out
    }

    /** Live genres as Category objects carrying the portal's own `censored` (adult) flag, so a Kids
     *  profile hides exactly what the provider marked adult — no keyword guessing. */
    fun getGenreCats(): List<Category> {
        val js = api("type=itv&action=get_genres")
        val arr = js as? JSONArray ?: return emptyList()
        val out = mutableListOf<Category>()
        for (i in 0 until arr.length()) {
            val g = arr.optJSONObject(i) ?: continue
            out.add(Category(g.optString("id"), g.optString("title"), g.optInt("censored", 0) == 1))
        }
        return out
    }

    /** Full channel list. Uses an on-disk cache to avoid re-downloading the ~4.4 MB payload on every
     *  connect: a fresh cache is served directly; otherwise we fetch from the portal and refresh the
     *  cache; if the fetch fails we fall back to whatever is cached so channels still load. */
    fun getAllChannels(): List<PortalChannel> {
        cachedChannels?.let { return it }
        val cacheKey = (base + "|" + mac).hashCode().toString()
        val ttlMs = 24L * 60 * 60 * 1000   // serve a cache younger than this without re-downloading

        // 1) Fresh disk cache → skip the download entirely.
        ChannelCache.load(cacheKey)?.let { hit ->
            if (hit.ageMs in 0 until ttlMs) {
                ConnectLog.step("GET_CHANNELS", "disk cache hit (${hit.channels.size} ch, ${hit.ageMs / 60000}m old) — skipped download")
                cachedChannels = hit.channels
                return hit.channels
            }
        }

        // 2) Fetch from the portal. On a hard failure, fall back to any disk cache before giving up.
        val data = try {
            (api("type=itv&action=get_all_channels") as? JSONObject)?.optJSONArray("data")
        } catch (e: Exception) {
            ChannelCache.load(cacheKey)?.let { fb ->
                ConnectLog.step("GET_CHANNELS", "fetch failed (${e.message}) — disk cache fallback (${fb.channels.size} ch, ${fb.ageMs / 60000}m old)")
                cachedChannels = fb.channels
                return fb.channels
            }
            throw e   // no cache to fall back to → behave exactly as before
        }
        if (data == null) {
            ConnectLog.step("GET_CHANNELS", "no data array returned")
            ChannelCache.load(cacheKey)?.let { fb ->
                ConnectLog.step("GET_CHANNELS", "using disk cache fallback (${fb.channels.size} ch, ${fb.ageMs / 60000}m old)")
                cachedChannels = fb.channels
                return fb.channels
            }
            return emptyList()
        }

        val out = mutableListOf<PortalChannel>()
        for (i in 0 until data.length()) {
            val c = data.optJSONObject(i) ?: continue
            out.add(
                PortalChannel(
                    id = c.optString("id"),
                    number = c.optString("number").toIntOrNull() ?: (i + 1),
                    name = c.optString("name"),
                    genreId = c.optString("tv_genre_id"),
                    cmd = c.optString("cmd"),
                    logo = resolveLogo(c.optString("logo").ifBlank { c.optString("logo_big") }),
                    archive = c.optInt("tv_archive_duration", 0) > 0 || c.optInt("enable_tv_archive", 0) == 1,
                    archiveDays = (c.optInt("tv_archive_duration", 0) / 24).coerceAtLeast(if (c.optInt("tv_archive_duration", 0) > 0) 1 else 0)
                )
            )
        }
        ConnectLog.step("GET_CHANNELS OK", "${out.size} channels")
        val sorted = out.sortedBy { it.number }
        cachedChannels = sorted
        if (sorted.isNotEmpty()) ChannelCache.save(cacheKey, sorted)   // refresh the on-disk cache
        return sorted
    }

    /** Ask the portal for a playable URL for a channel's cmd. */
    fun createLink(cmd: String): String {
        val enc = URLEncoder.encode(cmd, "UTF-8")
        val js = api("type=itv&action=create_link&cmd=$enc&series=&forced_storage=&disable_ad=0&download=0")
        val raw = (js as? JSONObject)?.optString("cmd").orEmpty()
        val url = extractUrl(raw.ifEmpty { cmd })
        if (url.isEmpty()) throw RuntimeException("Portal gave no stream link")
        return url
    }

    /** cmd values look like "ffmpeg http://..." — keep from the first http. */
    fun extractUrl(cmd: String): String {
        // Pull a stream URL out of a portal cmd, tolerating a prefix like "ffmpeg " or "auto ".
        // Detect by SCHEME (http://, https://, rtsp://, rtmp://, ...), NOT by file extension, so any
        // container plays equally: .mkv, .mp4, .avi, .ts, .m3u8, .wmv, etc. Returns "" when there is
        // no URL (e.g. a "/media/<id>.mpg" token) — that signals the caller to use create_link.
        return Regex("[a-zA-Z][a-zA-Z0-9+.\\-]*://\\S+").find(cmd)?.value?.trim() ?: ""
    }

    /**
     * VOD posters come back as screenshot_uri, which may be a full URL, a root-relative
     * path (/stalker_portal/...), or a bare relative path. AsyncImage needs an absolute URL,
     * so resolve it against the portal origin. Returns "" if there's nothing usable (callers
     * treat blank as "no poster").
     */
    private fun resolvePoster(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return ""
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        // origin = scheme://host[:port] from base
        val origin = Regex("^(https?://[^/]+)").find(base)?.groupValues?.get(1) ?: base
        return if (s.startsWith("/")) "$origin$s" else "$origin/$s"
    }

    /**
     * Channel logos: the portal's `logo` field is usually a bare filename served from
     * /<portal_path>/misc/logos/320/<file>, but some portals already give a full URL or a
     * root-relative path. Resolve all three shapes to an absolute URL, or "" if none.
     */
    private fun resolveLogo(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return ""
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        val origin = Regex("^(https?://[^/]+)").find(base)?.groupValues?.get(1) ?: base
        if (s.startsWith("/")) return "$origin$s"
        // bare filename → build the standard logos path (320px is the common large size)
        return "$origin/stalker_portal/misc/logos/320/$s"
    }

    /** VOD categories. */
    @Volatile private var cachedVodCategories: List<VodCategory>? = null
    private val cachedVodLists = java.util.concurrent.ConcurrentHashMap<String, List<PortalMovie>>()

    fun getVodCategories(): List<VodCategory> {
        cachedVodCategories?.let { return it }
        val js = api("type=vod&action=get_categories")
        val arr = js as? JSONArray ?: return emptyList()
        val out = mutableListOf<VodCategory>()
        for (i in 0 until arr.length()) {
            val g = arr.optJSONObject(i) ?: continue
            out.add(VodCategory(g.optString("id"), g.optString("title"), g.optInt("censored", 0) == 1))
        }
        cachedVodCategories = out
        return out
    }

    /**
     * The only categories that are safe to SHOW or to AGGREGATE titles from. The portal censors
     * adult content at the CATEGORY level only — individual titles carry no flag — so any title
     * pulled outside its category arrives ungated. Two things are therefore unsafe and excluded
     * here: censored categories, and the "*"/All aggregate (which mixes adult titles in and is
     * itself NOT marked censored). Every cross-category feature (search, recommendations, rows)
     * must build only from this list, never from "*".
     */
    fun safeVodCategories(): List<VodCategory> =
        getVodCategories().filter { it.id != "*" && !it.censored }

    /** One page (14 items) of a VOD category, sorted/searched server-side, plus the total count.
     *  sortby is the portal sort key ("added", "name", "year"); search filters by title when set. */
    fun getVodPage(categoryId: String, page: Int, sortby: String = "added", search: String = "", allowAdult: Boolean = false): VodPage {
        // Refuse the "*"/All aggregate always. Censored (adult) categories are refused too UNLESS the
        // caller passes allowAdult — i.e. the parental lock is off, or already unlocked this session.
        // Search/recommendations never pass it, so adult titles still can't leak into those features.
        if (categoryId == "*" || categoryId.isBlank()) return VodPage(emptyList(), 0)
        if (!allowAdult && cachedVodCategories?.any { it.id == categoryId && it.censored } == true) return VodPage(emptyList(), 0)
        val searchParam = if (search.isNotBlank()) "&search=" + URLEncoder.encode(search, "UTF-8") else ""
        val js = api("type=vod&action=get_ordered_list&category=$categoryId&sortby=$sortby$searchParam&p=$page")
        val obj = js as? JSONObject
        val total = obj?.optString("total_items")?.toIntOrNull() ?: 0
        val data = obj?.optJSONArray("data") ?: return VodPage(emptyList(), total)
        val out = mutableListOf<PortalMovie>()
        for (i in 0 until data.length()) {
            val m = data.optJSONObject(i) ?: continue
            out.add(
                PortalMovie(
                    id = m.optString("id"),
                    name = m.optString("name"),
                    description = m.optString("description").ifBlank { m.optString("plot") },
                    poster = resolvePoster(m.optString("screenshot_uri").ifBlank { m.optString("pic") }),
                    year = m.optString("year"),
                    cmd = m.optString("cmd"),
                    director = m.optString("director"),
                    actors = m.optString("actors"),
                    trailer = m.optString("trailer").ifBlank { m.optString("youtube_id") },
                    isSeries = m.optInt("is_series", 0) == 1 || m.optString("is_series") == "1",
                    added = m.optString("added"),
                    runtimeMin = parseRuntimeMin(m)
                )
            )
        }
        return VodPage(out, total)
    }

    /** Runtime in MINUTES from a list row. Stalker portals usually send "time" (minutes, may be "0"
     *  or absent); some send "duration" in seconds instead. 0 = unknown — callers must tolerate it. */
    private fun parseRuntimeMin(m: JSONObject): Int {
        m.optString("time").trim().toIntOrNull()?.let { if (it in 1..600) return it }        // minutes
        m.optString("duration").trim().toIntOrNull()?.let { if (it >= 60) return it / 60 }   // seconds
        return 0
    }

    /** First page of a VOD category, cached for the session (used by rails and search). */
    fun getVodList(categoryId: String): List<PortalMovie> {
        cachedVodLists[categoryId]?.let { return it }
        val items = getVodPage(categoryId, 1).items
        if (items.isNotEmpty()) cachedVodLists[categoryId] = items
        return items
    }

    /** Create a playable link for a VOD title. */
    fun createVodLink(cmd: String): String {
        // Primary path: ask the portal for the cmd exactly as the catalogue listed it. With
        // forced_storage left EMPTY (not "undefined"), the portal selects a storage that actually
        // holds the file (its "first_media") and returns the real stream URL. The earlier bug was
        // sending forced_storage=undefined, which the portal treated as a real storage name, found
        // none, and emptied the storage list -> "nothing_to_play". This works for normal movies.
        tryVodLink(cmd)?.let { return it }
        // Fallback: a few titles are containers whose movie-level id has no first_media. Drill into
        // the movie's file rows (get_ordered_list&movie_id=<id>) and retry with the file's own cmd.
        val resolved = resolvePlayableCmd(cmd)
        if (resolved != cmd) {
            // KEY: the file's cmd is frequently ALREADY a full URL (e.g. http://host/movie.mkv).
            // The real STB plays such a URL DIRECTLY and never calls create_link on it (vclub.js
            // get_link: `if (cmd.indexOf('://') < 0) create_link; else play directly`). Sending a
            // finished URL back through create_link is exactly what returned a second
            // "nothing_to_play". So if the resolved cmd is already a URL, use it as the stream.
            extractUrl(resolved).let { direct -> if (direct.isNotEmpty()) return direct }
            // Otherwise it's still a "/media/<file_id>.mpg" style cmd — let the portal link it.
            tryVodLink(resolved)?.let { return it }
        }
        // Genuinely nothing to play — the provider hasn't put this title's file on a storage yet.
        throw RuntimeException("This title isn't available to stream yet")
    }

    /** One VOD create_link attempt; returns a playable URL, or null if the portal had nothing. */
    private fun tryVodLink(cmd: String): String? {
        val enc = URLEncoder.encode(cmd, "UTF-8")
        val js = api("type=vod&action=create_link&cmd=$enc&series=&forced_storage=&disable_ad=0&download=0")
        val raw = (js as? JSONObject)?.optString("cmd").orEmpty()
        return extractUrl(raw).ifEmpty { null }
    }

    /**
     * Resolve the actually-playable cmd for a VOD title. A list item is usually a MOVIE container
     * whose own "/media/<movie_id>.mpg" has no file (→ "nothing_to_play"). The STB drills into the
     * movie (get_ordered_list&movie_id=<id>) to list its FILE rows; the file carries the real cmd.
     * For the normal single-file movie this returns that one file's cmd. If anything is missing we
     * fall back to the original cmd so behaviour is never worse than before.
     */
    private fun resolvePlayableCmd(originalCmd: String): String {
        // Pull the movie id out of "/media/<id>.mpg" (also tolerates "ffmpeg /media/<id>.mpg").
        val movieId = Regex("/media/(\\d+)\\.mpg").find(originalCmd)?.groupValues?.getOrNull(1)
            ?: return originalCmd
        val js = api("type=vod&action=get_ordered_list&movie_id=$movieId&p=1")
        val data = (js as? JSONObject)?.optJSONArray("data") ?: return originalCmd
        if (data.length() == 0) return originalCmd
        // Find the first row that represents a playable file. The portal marks a file row with
        // is_file=1 OR a file_type ("video"); its cmd holds the real target — usually a full http
        // URL (played directly) and sometimes a "/media/<file_id>.mpg" handed to create_link.
        for (i in 0 until data.length()) {
            val row = data.optJSONObject(i) ?: continue
            val isFile = row.optInt("is_file", 0) == 1 || row.optString("is_file") == "1" ||
                row.optString("file_type").isNotBlank()
            val rowCmd = row.optString("cmd")
            if (rowCmd.isNotBlank() && rowCmd != originalCmd &&
                (isFile || rowCmd.contains("://") || Regex("/media/\\d+\\.mpg").containsMatchIn(rowCmd))) {
                return rowCmd
            }
        }
        // No explicit file row — if the single row carries any cmd, use it; else keep original.
        val first = data.optJSONObject(0)
        val firstCmd = first?.optString("cmd").orEmpty()
        return if (firstCmd.isNotBlank() && firstCmd != originalCmd) firstCmd else originalCmd
    }

    /** Short EPG (now + next few) for one channel. */
    fun getShortEpg(channelId: String): List<EpgProgram> {
        val js = api("type=itv&action=get_short_epg&ch_id=$channelId&size=6")
        val arr = (js as? JSONArray) ?: (js as? JSONObject)?.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<EpgProgram>()
        for (i in 0 until arr.length()) {
            val p = arr.optJSONObject(i) ?: continue
            out.add(
                EpgProgram(
                    name = p.optString("name"),
                    start = p.optString("t_time"),
                    end = p.optString("t_time_to"),
                    startTs = p.optLong("start_timestamp"),
                    endTs = p.optLong("stop_timestamp"),
                    desc = p.optString("descr"),
                    id = p.optString("id"),
                    hasArchive = p.optInt("mark_archive", 0) == 1,
                    category = p.optString("category"),
                    director = p.optString("director"),
                    actor = p.optString("actor")
                )
            )
        }
        if (out.isNotEmpty()) EpgStore.merge(channelId, out)   // every now/next view feeds the 2-week store
        return out
    }

    // Session state for the catch-up guide.
    private var datedEpgRefusals = 0                          // times get_simple_data_table answered {"js":false}
    private val datedEpgGiveUp = 3                            // stop trying the per-day table only after a few refusals (not just one)
    private var dataTableRefusals = 0                        // times get_data_table answered {"js":false}
    private val harvestedThisSession = HashSet<String>()
    @Volatile private var epgInfoHarvested = false           // get_epg_info bulk sweep done once per session

    /**
     * Bulk multi-day EPG — the method MAG / StbEmu use to build the whole grid. get_epg_info with a
     * period (in days) returns programmes for ALL channels in one request, and that response can be
     * very large (the box itself holds the whole grid in RAM). So we do NOT load it as a single
     * string or build a full JSON tree — either could OutOfMemory a phone, and an OOM is an Error a
     * normal catch wouldn't even stop. Instead we STREAM-parse with JsonReader: one programme at a
     * time, keep only name + start/stop, merge per channel into the lean 2-week store, then discard.
     * Peak memory stays small whatever the response size; a global cap bounds the store too. Runs
     * once per session. Wrapped in catch(Throwable) so not even an OOM here can drop the app.
     */
    fun harvestEpgInfo(periodDays: Int) {
        if (epgInfoHarvested) return
        val ep = endpoint ?: return
        val url = "$ep?type=itv&action=get_epg_info&period=$periodDays&JsHttpRequest=1-xml"
        var chCount = 0
        var progCount = 0
        var minTs = Long.MAX_VALUE
        var maxTs = 0L
        try {
            ConnectLog.step("\u2192 GET [EPG/INFO bulk] [get_epg_info]", url)
            // a longer read timeout just for this potentially big download (a steady stream won't trip it)
            val client = http.newBuilder().readTimeout(120, TimeUnit.SECONDS).build()
            client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                if (!resp.isSuccessful) { ConnectLog.add("  [EPG/INFO] HTTP ${resp.code}"); return@use }
                val raw = resp.body?.charStream()?.buffered() ?: run { ConnectLog.add("  [EPG/INFO] empty body"); return@use }
                // skip a leading UTF-8 BOM if present (JsonReader would choke on it)
                raw.mark(1)
                val first = raw.read()
                if (first == -1) { ConnectLog.add("  [EPG/INFO] empty body"); return@use }
                if (first != 0xFEFF) raw.reset()
                val jr = JsonReader(raw)
                jr.setLenient(true)

                // read one channel's [ {programme}, ... ] and merge it as a single batch
                fun readChannelArray(chId: String) {
                    if (jr.peek() != JsonToken.BEGIN_ARRAY) { jr.skipValue(); return }
                    val batch = ArrayList<EpgProgram>(64)
                    jr.beginArray()
                    while (jr.hasNext()) {
                        if (jr.peek() != JsonToken.BEGIN_OBJECT) { jr.skipValue(); continue }
                        var name = ""
                        var sTs = 0L
                        var eTs = 0L
                        jr.beginObject()
                        while (jr.hasNext()) {
                            val k = jr.nextName()
                            if (jr.peek() == JsonToken.NULL) { jr.nextNull(); continue }
                            when (k) {
                                "name" -> name = jr.nextString()
                                "start_timestamp" -> sTs = jr.nextLong()
                                "stop_timestamp" -> eTs = jr.nextLong()
                                else -> jr.skipValue()
                            }
                        }
                        jr.endObject()
                        if (sTs > 0 && name.isNotBlank()) {
                            batch.add(EpgProgram(name = name, start = "", end = "", startTs = sTs, endTs = eTs, desc = ""))
                            progCount++
                            if (sTs < minTs) minTs = sTs
                            if (sTs > maxTs) maxTs = sTs
                            if (progCount >= 1_000_000) throw RuntimeException("EPG cap reached")   // safety valve
                        }
                    }
                    jr.endArray()
                    if (batch.isNotEmpty()) { EpgStore.merge(chId, batch); chCount++ }
                }

                if (jr.peek() != JsonToken.BEGIN_OBJECT) { ConnectLog.add("  [EPG/INFO] unexpected top-level JSON"); return@use }
                jr.beginObject()
                while (jr.hasNext()) {
                    if (jr.nextName() == "js" && jr.peek() == JsonToken.BEGIN_OBJECT) {
                        jr.beginObject()
                        while (jr.hasNext()) {
                            val key = jr.nextName()
                            when {
                                jr.peek() == JsonToken.BEGIN_ARRAY -> readChannelArray(key)              // js: { ch_id: [...] }
                                key == "data" && jr.peek() == JsonToken.BEGIN_OBJECT -> {                 // js: { data: { ch_id: [...] } }
                                    jr.beginObject()
                                    while (jr.hasNext()) readChannelArray(jr.nextName())
                                    jr.endObject()
                                }
                                else -> jr.skipValue()
                            }
                        }
                        jr.endObject()
                    } else jr.skipValue()
                }
                jr.endObject()
            }
            // Mark the once-per-session bulk sweep done ONLY after a clean streamed parse. A transient
            // first failure (timeout / 5xx) now leaves the flag unset so the next call retries, instead
            // of disabling the efficient bulk path for the whole session.
            epgInfoHarvested = true
        } catch (t: Throwable) {
            ConnectLog.add("  [EPG/INFO] get_epg_info stopped: ${t.message}")
        }
        val span = if (progCount > 0) {
            val fmt = java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault())
            "spanning ${fmt.format(java.util.Date(minTs * 1000))} -> ${fmt.format(java.util.Date(maxTs * 1000))}"
        } else ""
        ConnectLog.add("  [EPG/INFO] get_epg_info period=$periodDays -> $chCount channels, $progCount programmes (streamed) $span")
    }

    /**
     * One large get_short_epg sweep per channel per session, merged into the 2-week store.
     * get_short_epg returns the current programme + the next N, so a big size harvests days of
     * UPCOMING names in a single call — that's what fills future tabs now and past tabs later.
     */
    fun harvestShortEpg(channelId: String) {
        if (channelId.isBlank() || channelId in harvestedThisSession) return
        try {
            val js = api("type=itv&action=get_short_epg&ch_id=$channelId&size=200")
            val arr = (js as? JSONArray) ?: (js as? JSONObject)?.optJSONArray("data") ?: return
            // This same sweep reveals the portal's clock offset (server-local "time" vs the UTC
            // start_timestamp on the first row), so detect it here rather than with a separate call.
            if (serverOffsetSecCache == null) {
                val p0 = arr.optJSONObject(0)
                val off = if (p0 != null) computeOffset(p0.optString("time"), p0.optLong("start_timestamp")) else null
                if (off != null) {
                    serverOffsetSecCache = off
                    ConnectLog.add("  \u2605 portal clock offset = UTC${if (off >= 0) "+" else ""}${"%.1f".format(off / 3600.0)} (from EPG time vs timestamp)")
                }
            }
            val out = ArrayList<EpgProgram>(arr.length())
            for (i in 0 until arr.length()) {
                val p = arr.optJSONObject(i) ?: continue
                out.add(
                    EpgProgram(
                        name = p.optString("name"),
                        start = p.optString("t_time"), end = p.optString("t_time_to"),
                        startTs = p.optLong("start_timestamp"), endTs = p.optLong("stop_timestamp"),
                        desc = p.optString("descr"), id = p.optString("id"),
                        hasArchive = p.optInt("mark_archive", 0) == 1,
                        category = p.optString("category"), director = p.optString("director"), actor = p.optString("actor")
                    )
                )
            }
            if (out.isNotEmpty()) {
                harvestedThisSession.add(channelId)
                EpgStore.merge(channelId, out)
                ConnectLog.add("  \u2605 [EPG/HARVEST] ch=$channelId \u2192 cached ${out.size} upcoming (store now ${EpgStore.count(channelId)} for this ch)")
            }
        } catch (_: Exception) { }
    }

    /**
     * The portal keeps its own clock (Stalker's timezone / locale, separate from the device). EPG
     * rows are filed against that server-local clock, but each row also carries the UTC
     * start_timestamp, so the difference between the server-local "time" string and the UTC stamp is
     * the portal's exact UTC offset. We detect it once from a short-EPG row and cache it, so catch-up
     * day boundaries line up with the portal's clock (exactly what a real MAG box shows). Returns the
     * offset in seconds (0 if it can't be determined, i.e. treat the portal as UTC).
     */
    @Volatile private var serverOffsetSecCache: Int? = null
    fun serverUtcOffsetSeconds(sampleChannelId: String): Int? {
        serverOffsetSecCache?.let { return it }
        // No dedicated request: the harvest sweep detects and caches the offset as a side effect and
        // is needed anyway, so trigger it (no-op if already done) and read the cached value.
        runCatching { harvestShortEpg(sampleChannelId) }
        return serverOffsetSecCache
    }

    // Pure offset math from one EPG row: server-local wall-clock string vs the UTC start_timestamp.
    // All real zones are whole 15-min multiples, so snap to absorb seconds skew. No network call.
    private fun computeOffset(timeStr: String, startTs: Long): Int? {
        if (timeStr.isBlank() || startTs <= 0) return null
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        fmt.timeZone = java.util.TimeZone.getTimeZone("UTC")   // read the wall clock as if it were UTC
        val asUtc = runCatching { fmt.parse(timeStr)?.time }.getOrNull() ?: return null
        return (Math.round(((asUtc / 1000) - startTs) / 900.0) * 900).toInt()
    }

    /**
     * Catch-up: all programmes for one channel on one calendar day. The box uses
     * get_simple_data_table with ch_id + date (YYYY-MM-DD). Each programme carries an id and a
     * mark_archive flag — the ones with archive available can be replayed via createArchiveLink.
     */
    fun getEpgForDay(
        channelId: String,
        date: String,
        windowStartSec: Long = 0L,
        windowEndSec: Long = 0L
    ): List<EpgProgram> {
        val nowSec = System.currentTimeMillis() / 1000
        val winStart = windowStartSec
        val winEnd = when {
            windowEndSec > 0 -> windowEndSec
            winStart > 0     -> winStart + 86_400
            else             -> 0L
        }

        // 1) Harvest EPG into the persistent 2-week store. Two sources, both forward-merged:
        //    - get_epg_info: the bulk multi-day method MAG/StbEmu use (ALL channels at once), once
        //      per session — this is what should fill the full 10-day range (past + future).
        //    - get_short_epg: this channel's now/next sweep (the action we already know answers here).
        harvestEpgInfo(15)
        harvestShortEpg(channelId)

        // 2) Try the portal's per-day tables. MAG can use two methods (get_simple_data_table and
        //    get_data_table); both paginate identically, so both route through fetchDatedTable rather
        //    than duplicating the loop. get_simple_data_table is primary (any day); on this account it
        //    returns {"js":false}, so get_data_table is tried for recent PAST days (within the portal's
        //    ~1-week EPG retention). Once a method refuses we stop asking it for the rest of the session
        //    instead of re-hammering it on every day tab. Whichever returns rows is merged into the
        //    2-week store and served as the named guide.
        data class DatedMethod(
            val action: String,
            val refusals: () -> Int,
            val onRefuse: () -> Unit,
            val pastOnly: Boolean
        )
        val datedMethods = listOf(
            DatedMethod("get_simple_data_table", { datedEpgRefusals }, { datedEpgRefusals++ }, pastOnly = false),
            DatedMethod("get_data_table",        { dataTableRefusals }, { dataTableRefusals++ }, pastOnly = true)
        )
        for (m in datedMethods) {
            if (m.refusals() >= datedEpgGiveUp) continue
            // past-only methods skip today/future (those are served from now/next below)
            if (m.pastOnly && !(winStart > 0 && nowSec >= winEnd)) continue
            val res = try { fetchDatedTable(m.action, channelId, date, nowSec) } catch (e: Exception) { null }
            when {
                res == null -> {
                    m.onRefuse()
                    ConnectLog.add("  \u2605 [EPG/CATCH-UP] ${m.action} refused ({\"js\":false}) for $date \u2014 using the 2-week local store + recording grid")
                }
                res.isNotEmpty() -> {
                    ConnectLog.add("  \u2605 [EPG/CATCH-UP] ${m.action} $date \u2192 ${res.size} programmes")
                    EpgStore.merge(channelId, res)
                    return res
                }
                else -> ConnectLog.add("  [EPG/CATCH-UP] ${m.action} $date \u2192 0 rows")
            }
        }

        // 3) Serve the requested day from the persistent store (named wherever we've captured it).
        if (winStart > 0) {
            val cached = EpgStore.forDay(channelId, winStart, winEnd)
            if (cached.isNotEmpty()) {
                ConnectLog.add("  \u2605 [EPG/CATCH-UP] $date from 2-week store \u2192 ${cached.size} programmes")
                return cached
            }
        }

        // 4) Current-day fallback: show the now/next short EPG so whatever is airing now stays
        //    replayable from the archive even before the store has built up.
        val isCurrentDay = if (winStart > 0) nowSec in winStart until winEnd
                           else date == java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (isCurrentDay) {
            return getShortEpg(channelId).map { it.copy(hasArchive = it.startTs in 1 until nowSec) }
        }

        // 5) Nothing for this day yet -> the caller shows the hour scrubber (playback still works).
        return emptyList()
    }

    /** Fetch a paginated dated EPG table (get_simple_data_table / get_data_table) for one day.
     *  Returns the parsed programmes, or null if the portal refused the method ({"js":false}). */
    private fun fetchDatedTable(action: String, channelId: String, date: String, nowSec: Long): List<EpgProgram>? {
        val rows = mutableListOf<JSONObject>()
        var page = 1
        var total = -1
        while (page <= 80) {
            val js = api("type=itv&action=$action&ch_id=$channelId&date=$date&p=$page")
            if (js is Boolean) { if (!js) return null; break }   // {"js":false} = method refused
            val obj = js as? JSONObject
            val arr = obj?.optJSONArray("data") ?: (js as? JSONArray)
            if (total < 0) total = obj?.optInt("total_items", -1) ?: -1
            val n = arr?.length() ?: 0
            if (arr != null) for (i in 0 until n) arr.optJSONObject(i)?.let { rows.add(it) }
            if (n == 0) break
            if (total in 0..rows.size) break
            if (total < 0 && n < 10) break
            if (rows.size > 5000) break
            page++
        }
        val out = ArrayList<EpgProgram>(rows.size)
        for (p in rows) {
            val sTs = p.optLong("start_timestamp")
            val eTs = p.optLong("stop_timestamp")
            out.add(
                EpgProgram(
                    name = p.optString("name"),
                    start = p.optString("t_time"),
                    end = p.optString("t_time_to"),
                    startTs = sTs,
                    endTs = eTs,
                    desc = p.optString("descr"),
                    id = p.optString("id"),
                    hasArchive = (p.optInt("mark_archive", 0) == 1) || (eTs in 1 until nowSec),
                    category = p.optString("category"),
                    director = p.optString("director"),
                    actor = p.optString("actor")
                )
            )
        }
        out.sortBy { it.startTs }
        return out
    }

    /**
     * Play a past programme from the archive. The box sends create_link with
     * cmd = "auto /media/<program_id>.mpg" and the portal returns the recording's stream URL.
     */
    fun createArchiveLink(programId: String): String {
        val cmd = "auto /media/$programId.mpg"
        val enc = URLEncoder.encode(cmd, "UTF-8")
        val js = api("type=itv&action=create_link&cmd=$enc&series=&forced_storage=&disable_ad=0&download=0")
        val obj = js as? JSONObject
        val raw = obj?.optString("cmd").orEmpty()
        val url = extractUrl(raw.ifEmpty { cmd })
        if (url.isEmpty()) throw RuntimeException("This programme isn't available to replay")
        return url
    }

    /** Series categories. */
    fun getSeriesCategories(): List<Pair<String, String>> {
        val js = api("type=series&action=get_categories")
        val arr = js as? JSONArray ?: return emptyList()
        val out = mutableListOf<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val g = arr.optJSONObject(i) ?: continue
            out.add(g.optString("id") to g.optString("title"))
        }
        return out
    }

    /** Series categories as Category objects carrying the portal's `censored` flag (for Kids mode). */
    fun getSeriesCats(): List<Category> {
        val js = api("type=series&action=get_categories")
        val arr = js as? JSONArray ?: return emptyList()
        val out = mutableListOf<Category>()
        for (i in 0 until arr.length()) {
            val g = arr.optJSONObject(i) ?: continue
            out.add(Category(g.optString("id"), g.optString("title"), g.optInt("censored", 0) == 1))
        }
        return out
    }

    /** Series titles in a category (first page). */
    fun getSeriesList(categoryId: String): List<PortalMovie> {
        val js = api("type=series&action=get_ordered_list&category=$categoryId&sortby=added&p=1")
        val data = (js as? JSONObject)?.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<PortalMovie>()
        for (i in 0 until data.length()) {
            val m = data.optJSONObject(i) ?: continue
            out.add(
                PortalMovie(
                    id = m.optString("id"),
                    name = m.optString("name"),
                    description = m.optString("description").ifBlank { m.optString("plot") },
                    poster = resolvePoster(m.optString("screenshot_uri").ifBlank { m.optString("pic") }),
                    year = m.optString("year"),
                    cmd = m.optString("cmd"),
                    director = m.optString("director"),
                    actors = m.optString("actors"),
                    trailer = m.optString("trailer").ifBlank { m.optString("youtube_id") },
                    added = m.optString("added"),
                    runtimeMin = parseRuntimeMin(m)
                )
            )
        }
        return out
    }

    /** One page of a series category WITH the portal's total count — the paged twin of
     *  getSeriesList, added for the catalog index sweep (which must walk every page, not just
     *  page 1). Same parse as getSeriesList; existing callers of getSeriesList are untouched. */
    fun getSeriesPage(categoryId: String, page: Int): VodPage {
        if (categoryId.isBlank() || categoryId == "*") return VodPage(emptyList(), 0)
        val js = api("type=series&action=get_ordered_list&category=$categoryId&sortby=added&p=$page")
        val obj = js as? JSONObject
        val total = obj?.optString("total_items")?.toIntOrNull() ?: 0
        val data = obj?.optJSONArray("data") ?: return VodPage(emptyList(), total)
        val out = mutableListOf<PortalMovie>()
        for (i in 0 until data.length()) {
            val m = data.optJSONObject(i) ?: continue
            out.add(
                PortalMovie(
                    id = m.optString("id"),
                    name = m.optString("name"),
                    description = m.optString("description").ifBlank { m.optString("plot") },
                    poster = resolvePoster(m.optString("screenshot_uri").ifBlank { m.optString("pic") }),
                    year = m.optString("year"),
                    cmd = m.optString("cmd"),
                    director = m.optString("director"),
                    actors = m.optString("actors"),
                    trailer = m.optString("trailer").ifBlank { m.optString("youtube_id") },
                    isSeries = true,
                    added = m.optString("added"),
                    runtimeMin = parseRuntimeMin(m)
                )
            )
        }
        return VodPage(out, total)
    }

    // ───────── Voice/title search. The portal searches server-side per category (get_ordered_list
    // &search=…), and we fan that out across every SAFE category in parallel (capped) and merge the
    // matches. We never use the "*"/All aggregate (it mixes in adult titles — see safeVodCategories).
    // Each category failure yields an empty list, so one bad category can't sink the whole search.

    /** Search ALL safe VOD categories for a title, server-side, in parallel. */
    suspend fun searchVodAll(query: String): List<PortalMovie> {
        if (query.isBlank()) return emptyList()
        val cats = safeVodCategories()
        return coroutineScope {
            val gate = Semaphore(6)
            cats.map { cat ->
                async(Dispatchers.IO) {
                    gate.withPermit {
                        runCatching { getVodPage(cat.id, 1, "name", query).items }.getOrDefault(emptyList())
                    }
                }
            }.awaitAll().flatten()
        }
    }

    /** Search ALL series categories for a title, server-side, in parallel. */
    suspend fun searchSeriesAll(query: String): List<PortalMovie> {
        if (query.isBlank()) return emptyList()
        val cats = getSeriesCategories()
        return coroutineScope {
            val gate = Semaphore(6)
            cats.map { (id, _) ->
                async(Dispatchers.IO) {
                    gate.withPermit {
                        runCatching { searchSeriesPage(id, query) }.getOrDefault(emptyList())
                    }
                }
            }.awaitAll().flatten()
        }
    }

    /** One page of a series category with a server-side title filter (mirrors getSeriesList + search). */
    private fun searchSeriesPage(categoryId: String, search: String): List<PortalMovie> {
        if (categoryId.isBlank()) return emptyList()
        val sp = if (search.isNotBlank()) "&search=" + URLEncoder.encode(search, "UTF-8") else ""
        val js = api("type=series&action=get_ordered_list&category=$categoryId&sortby=added$sp&p=1")
        val data = (js as? JSONObject)?.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<PortalMovie>()
        for (i in 0 until data.length()) {
            val m = data.optJSONObject(i) ?: continue
            out.add(
                PortalMovie(
                    id = m.optString("id"),
                    name = m.optString("name"),
                    description = m.optString("description").ifBlank { m.optString("plot") },
                    poster = resolvePoster(m.optString("screenshot_uri").ifBlank { m.optString("pic") }),
                    year = m.optString("year"),
                    cmd = m.optString("cmd"),
                    director = m.optString("director"),
                    actors = m.optString("actors"),
                    trailer = m.optString("trailer").ifBlank { m.optString("youtube_id") },
                    added = m.optString("added")
                )
            )
        }
        return out
    }

    /** Radio stations — paged. The portal returns ~14 per page via get_ordered_list, so loop
     *  pages until we've collected every station (total_items), instead of stopping at page 1. */
    fun getRadioChannels(): List<PortalChannel> {
        fun parse(js: Any?): List<PortalChannel> {
            val data = (js as? JSONObject)?.optJSONArray("data") ?: (js as? JSONArray) ?: return emptyList()
            val out = mutableListOf<PortalChannel>()
            for (i in 0 until data.length()) {
                val c = data.optJSONObject(i) ?: continue
                out.add(
                    PortalChannel(
                        id = c.optString("id"),
                        number = c.optString("number").toIntOrNull() ?: (i + 1),
                        name = c.optString("name"),
                        genreId = "",
                        cmd = c.optString("cmd")
                    )
                )
            }
            return out
        }
        // A few portals expose radio via get_all_channels in one shot — take it if non-empty.
        val viaAll = parse(api("type=radio&action=get_all_channels"))
        if (viaAll.isNotEmpty()) return viaAll
        // Otherwise page through get_ordered_list until we have them all.
        val out = mutableListOf<PortalChannel>()
        var page = 1
        while (page <= 100) {
            val js = api("type=radio&action=get_ordered_list&genre=*&p=$page")
            val pageList = parse(js)
            if (pageList.isEmpty()) break
            out.addAll(pageList)
            val total = (js as? JSONObject)?.optString("total_items")?.toIntOrNull() ?: 0
            if (total in 1..out.size) break          // collected everything
            page++
        }
        return out
    }

    /**
     * Episodes for a VOD series, flat-listed and tagged with season + episode number so the
     * Episodes screen can group them under "Season N" headers. On this portal a series lives in
     * the VOD tree: drill movie_id -> seasons, then movie_id+season_id -> episodes. Each episode's
     * cmd is an "ep:<movieId>:<seasonId>:<episodeId>" sentinel that createSeriesLink resolves to the
     * real file at PLAY time, so we don't drill every episode's file up front.
     */
    private val seriesEpisodeCache = java.util.concurrent.ConcurrentHashMap<String, List<PortalEpisode>>()

    suspend fun getSeriesEpisodes(seriesId: String): List<PortalEpisode> {
        seriesEpisodeCache[seriesId]?.let { return it }
        // Seasons and episodes are BOTH paginated (max_page_items ~14). Read every season, then fetch
        // each season's episodes CONCURRENTLY (capped at 4 in-flight) instead of one season at a time —
        // a multi-season series used to be a dozen+ sequential round-trips before anything could show.
        // A failed season yields an empty list rather than sinking the whole series. Cached per series
        // so re-opening is instant.
        val seasons = fetchAllPages("type=vod&action=get_ordered_list&movie_id=$seriesId")
        data class SeasonRef(val num: String, val id: String)
        val refs = ArrayList<SeasonRef>()
        for (si in 0 until seasons.length()) {
            val s = seasons.optJSONObject(si) ?: continue
            val isSeason = s.optInt("is_season", 0) == 1 || s.optString("is_season") == "1" ||
                s.optString("season_number").isNotBlank()
            if (!isSeason) continue
            refs.add(SeasonRef(s.optString("season_number").ifBlank { (si + 1).toString() }, s.optString("id")))
        }
        val result = coroutineScope {
            val gate = Semaphore(4)
            refs.map { ref ->
                async(Dispatchers.IO) {
                    gate.withPermit {
                        runCatching {
                            val eps = fetchAllPages("type=vod&action=get_ordered_list&movie_id=$seriesId&season_id=${ref.id}")
                            val list = mutableListOf<PortalEpisode>()
                            for (ei in 0 until eps.length()) {
                                val e = eps.optJSONObject(ei) ?: continue
                                val epId = e.optString("id")
                                val epNum = e.optString("series_number").ifBlank { (ei + 1).toString() }
                                val epName = e.optString("name").ifBlank { e.optString("o_name") }
                                    .ifBlank { e.optString("title") }.ifBlank { "Episode $epNum" }
                                list.add(PortalEpisode(epName, ref.num, epNum, "ep:$seriesId:${ref.id}:$epId"))
                            }
                            list.toList()
                        }.getOrDefault(emptyList())
                    }
                }
            }.awaitAll().flatten()
        }
        if (result.isNotEmpty()) seriesEpisodeCache[seriesId] = result
        return result
    }

    // ----- F1 seasons-first drill-down: list seasons cheaply, then fetch ONE season's episodes on
    // demand, instead of pre-fetching every season's episodes the moment a series is opened. -----
    private val seriesSeasonCache = java.util.concurrent.ConcurrentHashMap<String, List<PortalSeason>>()
    private val seasonEpisodeCache = java.util.concurrent.ConcurrentHashMap<String, List<PortalEpisode>>()

    /** Just the SEASON rows of a series (one paginated get_ordered_list on movie_id) — no episodes,
     *  so the series screen can show seasons immediately. Cached per series. Caller runs this on IO. */
    suspend fun getSeriesSeasons(seriesId: String): List<PortalSeason> {
        seriesSeasonCache[seriesId]?.let { return it }
        val seasons = fetchAllPages("type=vod&action=get_ordered_list&movie_id=$seriesId")
        val out = ArrayList<PortalSeason>()
        for (si in 0 until seasons.length()) {
            val s = seasons.optJSONObject(si) ?: continue
            val isSeason = s.optInt("is_season", 0) == 1 || s.optString("is_season") == "1" ||
                s.optString("season_number").isNotBlank()
            if (!isSeason) continue
            val num = s.optString("season_number").ifBlank { (si + 1).toString() }
            val name = s.optString("name").ifBlank { "Season $num" }
            out.add(PortalSeason(s.optString("id"), num, name))
        }
        if (out.isNotEmpty()) seriesSeasonCache[seriesId] = out
        return out
    }

    /** Episodes for ONE season, fetched only when the user opens that season. Same "ep:" cmd sentinel
     *  as before, so createSeriesLink resolves it unchanged at play time. Cached per season. */
    suspend fun getSeasonEpisodes(seriesId: String, seasonId: String, seasonNumber: String): List<PortalEpisode> {
        val key = "$seriesId/$seasonId"
        seasonEpisodeCache[key]?.let { return it }
        val eps = fetchAllPages("type=vod&action=get_ordered_list&movie_id=$seriesId&season_id=$seasonId")
        val list = mutableListOf<PortalEpisode>()
        for (ei in 0 until eps.length()) {
            val e = eps.optJSONObject(ei) ?: continue
            val epId = e.optString("id")
            val epNum = e.optString("series_number").ifBlank { (ei + 1).toString() }
            val epName = e.optString("name").ifBlank { e.optString("o_name") }
                .ifBlank { e.optString("title") }.ifBlank { "Episode $epNum" }
            list.add(PortalEpisode(epName, seasonNumber, epNum, "ep:$seriesId:$seasonId:$epId"))
        }
        val out = list.toList()
        if (out.isNotEmpty()) seasonEpisodeCache[key] = out
        return out
    }

    /** Page through a get_ordered_list query until every item is collected (the portal caps each
     *  page at max_page_items, ~14). Returns the concatenated "data" arrays from all pages. */
    private fun fetchAllPages(baseQuery: String): JSONArray {
        val all = JSONArray()
        var page = 1
        while (page <= 200) {
            val js = api("$baseQuery&p=$page")
            val obj = js as? JSONObject ?: break
            val data = obj.optJSONArray("data") ?: break
            for (i in 0 until data.length()) all.put(data.get(i))
            val total = obj.optString("total_items").toIntOrNull() ?: obj.optInt("total_items", 0)
            val perPage = (obj.optString("max_page_items").toIntOrNull()
                ?: obj.optInt("max_page_items", 14)).coerceAtLeast(1)
            if (data.length() == 0 || all.length() >= total || page.toLong() * perPage >= total) break
            page++
        }
        return all
    }

    /**
     * Resolve a series episode to a stream. cmd is normally an "ep:<movieId>:<seasonId>:<episodeId>"
     * sentinel from getSeriesEpisodes: drill that episode's file, then play its direct URL or resolve
     * the /media/file_<id>.mpg token via create_link. Falls back to the legacy token+series form.
     */
    fun createSeriesLink(cmd: String, episode: String): String {
        if (cmd.startsWith("ep:")) {
            val parts = cmd.removePrefix("ep:").split(":")
            if (parts.size >= 3) {
                val movieId = parts[0]; val seasonId = parts[1]; val episodeId = parts[2]
                val js = api("type=vod&action=get_ordered_list&movie_id=$movieId&season_id=$seasonId&episode_id=$episodeId&p=1")
                val row = (js as? JSONObject)?.optJSONArray("data")?.optJSONObject(0)
                val fileCmd = row?.optString("cmd").orEmpty()
                extractUrl(fileCmd).let { if (it.isNotEmpty()) return it }       // direct URL
                if (fileCmd.isNotBlank()) tryVodLink(fileCmd)?.let { return it }  // /media/file_<id>.mpg token
                throw RuntimeException("This episode isn't available to stream yet")
            }
        }
        val enc = URLEncoder.encode(cmd, "UTF-8")
        val js = api("type=vod&action=create_link&cmd=$enc&series=$episode&forced_storage=&disable_ad=0&download=0")
        val raw = (js as? JSONObject)?.optString("cmd").orEmpty()
        val url = extractUrl(raw.ifEmpty { cmd })
        if (url.isEmpty()) throw RuntimeException("Portal gave no stream link")
        return url
    }

    /**
     * Catch-up (Flussonic DVR). This portal's live streams are Flussonic — create_link turns a
     * channel into e.g. https://host/ErtNews/mpegts?token=XYZ. A past programme's recording is the
     * SAME url with the media segment rewritten to archive-<startUnix>-<durationSec>. So resolve the
     * live url first (which also gives the valid token), then swap in the archive window and play it.
     */
    fun createCatchupLink(programId: String, channelCmd: String, startTs: Long, durationSec: Long): String {
        val dur = if (durationSec > 0) durationSec else 3600L

        // PRIMARY — let the portal build the archive link. It looks up which DVR storage server holds
        // the recording (a DIFFERENT host than the live edge) and returns a ready url with a fresh
        // token. The MAG box asks for this with a /media/<programID>.mpg cmd; we just use the url it
        // hands back. This is the only reliable way — synthesising off the live host hits the wrong
        // server.
        if (programId.isNotBlank()) {
            val portalUrl = resolveArchiveViaPortal(programId)
            if (!portalUrl.isNullOrBlank()) {
                ConnectLog.add("  \u2605 CATCH-UP URL (portal) = $portalUrl")
                return portalUrl
            }
        }

        // FALLBACK — synthesise off the live host (only works if DVR happens to share the live host).
        val live = createLink(channelCmd)
        val query   = live.substringAfter('?', "")
        val noQuery = live.substringBefore('?')
        val base    = noQuery.substringBeforeLast('/').replaceFirst("https://", "http://")
        val suffix  = if (query.isNotBlank()) "?$query" else ""
        val candidates = listOf(
            "archive" to "$base/archive-$startTs-$dur.m3u8$suffix",
            "mono"    to "$base/mono-$startTs-$dur.m3u8$suffix"
        )
        ConnectLog.step("CATCH-UP BUILD (fallback)", buildString {
            append("from=$startTs dur=${dur}s\n")
            append("      live  = $live\n")
            append("      try#1 = ${candidates[0].second}\n")
            append("      try#2 = ${candidates[1].second}")
        })
        for ((tag, u) in candidates) {
            val (code, snip) = probePlaylist(u)
            ConnectLog.add("  \u21AA $tag \u2192 HTTP $code   ${snip.take(120).replace("\n", " ").trim()}")
            if (code in 200..299 && snip.contains("#EXT")) {
                ConnectLog.add("  \u2605 CATCH-UP URL = $u")
                return u
            }
        }
        ConnectLog.add("  \u2716 CATCH-UP: portal returned no archive url and live-host synth failed")
        throw RuntimeException("This programme isn't in the channel's archive")
    }

    /**
     * Timestamp seek — play an arbitrary past moment with NO EPG programme behind it.
     * This portal serves no per-day guide (get_simple_data_table returns false for past dates), so
     * older catch-up days have no programme ids to resolve. But the Flussonic temp token the portal
     * mints authorises the WHOLE channel DVR for ~8h and is NOT pinned to a time window — proven on
     * device: the portal handed back .../ert3/mono-<start>-<dur>.m3u8?token=… and that token plays
     * any window in retention. So we bootstrap a real archive url+token from the channel's CURRENT
     * programme (short_epg always returns it), then rewrite the mono window to the chosen moment.
     * absStartTs is a unix timestamp; works for any time inside the DVR retention (336h / 14 days here).
     */
    fun createCatchupLinkByTime(channelId: String, absStartTs: Long, durationSec: Long): String {
        val dur = durationSec.coerceAtLeast(60)
        ConnectLog.step("CATCH-UP/SEEK", "ch=$channelId target=$absStartTs dur=${dur}s")
        if (channelId.isBlank()) throw RuntimeException("No channel id to seek the archive")
        // anchor on the channel's current programme to get a valid DVR storage url + token
        val js = try { api("type=itv&action=get_short_epg&ch_id=$channelId&size=1") }
                 catch (e: Exception) { throw RuntimeException("Couldn't reach the archive server") }
        val nowId = ((js as? JSONArray) ?: (js as? JSONObject)?.optJSONArray("data"))
            ?.optJSONObject(0)?.optString("id").orEmpty()
        if (nowId.isBlank()) throw RuntimeException("Channel has no live programme to anchor the archive")
        val base = resolveArchiveViaPortal(nowId)
            ?: throw RuntimeException("Portal gave no archive link to seek from")
        // retarget the Flussonic window to the requested moment (mono- is playback, archive- is download)
        val retargeted = base
            .replace(Regex("""mono-\d+-\d+"""), "mono-$absStartTs-$dur")
            .replace(Regex("""archive-\d+-\d+"""), "archive-$absStartTs-$dur")
        ConnectLog.add("  \u2605 CATCH-UP/SEEK url = $retargeted")
        if (!retargeted.contains("mono-$absStartTs") && !retargeted.contains("archive-$absStartTs"))
            throw RuntimeException("Couldn't build a seek link for this time")
        return retargeted
    }

    /** Ask the portal to build the catch-up/archive link for a programme id. The portal resolves the
     *  DVR storage server + a fresh token and returns the full url (typically http, on a different
     *  host than the live edge). We don't probe it (the token may be one-shot) — we log it and hand it
     *  straight to the player. Tries the known request shapes; returns the first url the portal gives. */
    private fun resolveArchiveViaPortal(programId: String): String? {
        val mediaCmd = "/media/$programId.mpg"
        val enc = java.net.URLEncoder.encode(mediaCmd, "UTF-8")
        val encAuto = java.net.URLEncoder.encode("auto $mediaCmd", "UTF-8")
        val requests = listOf(
            "type=tv_archive&action=create_link&cmd=$enc&series=0&forced_storage=&disable_ad=0&download=0",
            "type=itv&action=create_link&cmd=$encAuto&series=0&forced_storage=&disable_ad=0&download=0"
        )
        ConnectLog.step("CATCH-UP (portal)", "program id=$programId  cmd=$mediaCmd")
        for (q in requests) {
            val js = try { api(q) } catch (e: Exception) {
                ConnectLog.add("  \u21AA ${q.substringBefore("&cmd")} \u2192 ${e.message}"); continue
            }
            val obj = js as? JSONObject ?: continue
            val raw = obj.optString("cmd")
            val err = obj.optString("error")
            ConnectLog.add("  \u21AA ${q.substringBefore("&cmd")} \u2192 cmd='${raw.take(180)}'" +
                if (err.isNotBlank()) " error='$err'" else "")
            if (raw.isBlank()) continue
            val url = Regex("""https?://\S+""").find(raw)?.value ?: continue
            return url
        }
        return null
    }

    /** GET a catch-up playlist and return (httpCode, first bytes) — used to choose mono vs archive
     *  and to record exactly what the DVR server answered. */
    private fun probePlaylist(url: String): Pair<Int, String> = try {
        val req = okhttp3.Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Referer", streamReferer)
            .build()
        http.newCall(req).execute().use { resp ->
            val snip = try { resp.peekBody(2048L).string() } catch (e: Exception) { "" }
            resp.code to snip
        }
    } catch (e: Exception) {
        -1 to (e.message ?: "request failed")
    }
}

/** Compact local clock for an EPG entry — from the absolute timestamp when present (robust and
 *  unambiguous), else parsed from the portal's t_time ("09:00 PM" -> "21:00"). The old code split
 *  t_time on the space and kept the wrong half, so every time rendered as just "AM"/"PM". */
fun epgClock(p: EpgProgram): String {
    if (p.startTs > 0) {
        return java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date(p.startTs * 1000))
    }
    val s = p.start.trim()
    return when {
        s.contains("AM", true) || s.contains("PM", true) -> try {
            val inF  = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.US)
            val outF = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
            outF.format(inF.parse(s)!!)
        } catch (e: Exception) { s.substringBefore(' ').take(5) }
        s.contains(' ') -> s.substringAfter(' ').take(5)   // datetime "2026-06-14 21:00:00" -> "21:00"
        else -> s.take(5)
    }
}

data class AccountInfo(val status: String, val expires: String, val tariff: String)

data class VodCategory(val id: String, val title: String, val censored: Boolean)

data class PortalChannel(
    val id: String,
    val number: Int,
    val name: String,
    val genreId: String,
    val cmd: String,
    val logo: String? = null,
    val archive: Boolean = false,
    val archiveDays: Int = 0
)

data class PortalMovie(
    val id: String,
    val name: String,
    val description: String,
    val poster: String,
    val year: String,
    val cmd: String,
    val director: String,
    val actors: String,
    val trailer: String = "",
    val isSeries: Boolean = false,
    val added: String = "",
    val runtimeMin: Int = 0        // minutes; 0 = the portal didn't say (provider-dependent field)
)

/** One page of a VOD category: the items plus the portal's total count (for paging). */
data class VodPage(val items: List<PortalMovie>, val total: Int)

data class EpgProgram(
    val name: String,
    val start: String,
    val end: String,
    val startTs: Long,
    val endTs: Long,
    val desc: String,
    val id: String = "",
    val hasArchive: Boolean = false,
    // Programme detail — only present on a FRESH get_short_epg row (the 2-week EpgStore keeps
    // name+time only). Blank for stored/past rows. Defaulted so every existing call site compiles.
    val category: String = "",
    val director: String = "",
    val actor: String = ""
)

data class PortalEpisode(
    val name: String,
    val season: String,
    val episode: String,
    val cmd: String
)

data class PortalSeason(
    val id: String,
    val number: String,
    val name: String
)
