package com.streamline.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * The Vault — StreamLine's own encryption module.
 *
 * WHAT IT PROTECTS AGAINST: anyone copying the app's files off the device — a rooted file
 * manager, an emulator image (BlueStacks etc.), a stolen/cloned tablet, forensic tools. Values
 * sealed by the Vault are ciphertext on disk; without THIS device's key they stay ciphertext.
 *
 * HOW: the cipher is standard AES-256-GCM (we deliberately do NOT invent a cipher — homemade
 * ciphers are how data gets broken; what's "our own" here is the module, the storage format and
 * the migration, not the math). The key is generated INSIDE the Android Keystore and marked
 * non-exportable: on real tablets it lives in the security chip and can never be read out — not
 * by the app, not by root. Encrypt/decrypt requests go INTO the chip; the key never comes out.
 * On emulators the Keystore is software-backed (weaker) but a copied data image still doesn't
 * carry a usable key.
 *
 * HONEST LIMIT: the app itself must be able to decrypt, so a live, unlocked, rooted device where
 * an attacker impersonates the running app can still reach the plaintext. Nothing beats that —
 * this closes the copy-the-files class of attack, which is the realistic one.
 *
 * DESIGN RULES (same never-crash contract as EpgStore):
 *  - seal() NEVER loses data: if the Keystore is broken on some odd device, it returns the value
 *    unencrypted rather than failing — the app keeps working, just without the extra armor there.
 *  - open() accepts BOTH sealed and legacy-plaintext values, so existing installs migrate
 *    seamlessly: old plaintext reads fine, and Prefs re-saves it sealed on first touch.
 *  - If a sealed value can't be decrypted (key vanished — e.g. data image moved to another
 *    device), open() returns "" — the app simply behaves as "not set" and asks to reconnect.
 *  - NO user-authentication requirement on the key: the nightly 2:30am worker must decrypt the
 *    credentials headlessly, and Keystore keys without an auth requirement work while locked.
 *
 * FORMAT: "ov1:" + Base64(iv[12] + ciphertext-with-GCM-tag). The prefix is how open() tells
 * sealed values from legacy plaintext.
 */
object Vault {

    private const val KEY_ALIAS = "openstream_vault_v1"
    private const val PREFIX = "ov1:"
    private const val IV_LEN = 12
    private val lock = Any()

    /** Encrypt for storage. Returns the input UNCHANGED (plaintext) if the Keystore is unusable —
     *  never throws, never loses the value. Blank stays blank. */
    fun seal(plain: String): String {
        if (plain.isEmpty() || plain.startsWith(PREFIX)) return plain   // blank or already sealed
        return try {
            synchronized(lock) {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, key())
                val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
                val out = ByteArray(c.iv.size + ct.size)
                c.iv.copyInto(out, 0); ct.copyInto(out, c.iv.size)
                PREFIX + Base64.encodeToString(out, Base64.NO_WRAP)
            }
        } catch (_: Throwable) { plain }
    }

    /** Read a stored value: decrypts if sealed, passes legacy plaintext through unchanged,
     *  returns "" if sealed but undecryptable (foreign/lost key). Never throws. */
    fun open(stored: String?): String {
        val s = stored ?: return ""
        if (!s.startsWith(PREFIX)) return s                             // legacy plaintext (or blank)
        return try {
            synchronized(lock) {
                val all = Base64.decode(s.substring(PREFIX.length), Base64.NO_WRAP)
                if (all.size <= IV_LEN) return ""
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all, 0, IV_LEN))
                String(c.doFinal(all, IV_LEN, all.size - IV_LEN), Charsets.UTF_8)
            }
        } catch (_: Throwable) { "" }
    }

    /** True if this stored value is sealed (used by Prefs to decide one-time migration). */
    fun isSealed(stored: String?): Boolean = stored?.startsWith(PREFIX) == true

    /** Fetch-or-create the non-exportable AES key inside the Android Keystore. */
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                // deliberately NO setUserAuthenticationRequired / setUnlockedDeviceRequired:
                // the nightly background worker must be able to decrypt unattended.
                .build()
        )
        return kg.generateKey()
    }
}
