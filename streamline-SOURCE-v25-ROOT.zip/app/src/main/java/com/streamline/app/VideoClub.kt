package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.scale
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun hueColor(hex: String): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Color(0xFF2C3A66))

// A VOD category counts as "series" purely by its name. This provider files box-set/series
// content in categories named like "TV Series (Gr Subs)". Greek "σειρ" covers Σειρές/σειρές.
fun isSeriesCategory(title: String): Boolean {
    val t = title.lowercase()
    return t.contains("series") || t.contains("σειρ") || t.contains("box set") || t.contains("boxset")
}

// ---------- Netflix-style browse ----------
@Composable
fun VideoClubScreen(
    session: Session,
    onlySeries: Boolean = false,
    onOpen: (UiMovie) -> Unit,
    onPlay: (UiMovie) -> Unit,
    onOpenCategory: (Category) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // Lazy rails: load just the category list first (one fast call), show the rows
    // immediately, then each rail fetches its own posters when it scrolls into view.
    var categories by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    // cache of loaded rail items per category id, survives scrolling
    val railItems = remember { mutableStateMapOf<String, List<UiMovie>>() }
    var featured by remember { mutableStateOf<UiMovie?>(null) }
    // Rotating hero: collect the first poster of each rail into a pool and cycle through them.
    val featuredPool = remember { mutableStateListOf<UiMovie>() }
    var heroIndex by remember { mutableStateOf(0) }
    LaunchedEffect(featuredPool.size) {
        while (featuredPool.size > 1) { delay(7000); heroIndex = (heroIndex + 1) % featuredPool.size }
    }

    LaunchedEffect(onlySeries) {
        if (session.client == null) {
            // demo: keep the existing demo rails as-is (filtered to match the tile)
            val rails = demoVodRails.filter { isSeriesCategory(it.title) == onlySeries }
            categories = rails.map { it.title to it.title }
            rails.forEach { railItems[it.title] = it.items }
            featured = rails.firstOrNull()?.items?.firstOrNull()
            return@LaunchedEffect
        }
        try {
            categories = withContext(Dispatchers.IO) {
                // Single safe source: excludes the "*"/All aggregate and any adult category, so
                // no adult title can reach a rail (the portal only censors at category level).
                // Name-based Movies/Series split: keep only the side this tile asked for.
                session.client.safeVodCategories()
                    .filter { isSeriesCategory(it.title) == onlySeries }
                    .map { it.id to it.title }.take(40)
            }
        } catch (e: Exception) { error = e.message ?: "Could not load video club" }
    }

    when {
        error != null -> Column(Modifier.fillMaxSize().padding(20.dp)) { TopBar("Video club", onBack); EmptyState("⚠", "Couldn't load the video club", error, isError = true) }
        categories == null -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().padding(20.dp)) { TopBar("Video club", onBack) }
            SkeletonRow(); SkeletonRow()
        }
        categories!!.isEmpty() -> Column(Modifier.fillMaxSize().padding(20.dp)) { TopBar("Video club", onBack); EmptyState("🎬", "No titles yet", "Your provider hasn't shared any movies, or none are available.") }
        else -> {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    val f = featuredPool.getOrNull(heroIndex) ?: featured
                    if (f != null) HeroBanner(f, onPlay = { onPlay(f) }, onInfo = { onOpen(f) }, onBack = onBack, autoFocus = true)
                    else {
                        // simple header until the first rail's hero item is available
                        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onBack() }.background(Color(0x33FFFFFF), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }; Spacer(Modifier.width(10.dp))
                            Text("Movies", color = TextCol, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text("VIDEO CLUB", color = Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                // Continue Watching + My List rails (only when they have items) — tap a Continue item
                // to resume, a My List item to open its detail.
                item {
                    val cont = remember { Prefs.continueList(ctx) }
                    if (cont.isNotEmpty()) RailRow(Rail("Continue watching", cont), onPlay)
                    val mine = remember { Prefs.myList(ctx) }
                    if (mine.isNotEmpty()) RailRow(Rail("My list", mine), onOpen)
                }
                items(categories!!) { (id, title) ->
                    LazyRailRow(
                        session = session,
                        categoryId = id,
                        title = title,
                        cache = railItems,
                        onOpen = onOpen,
                        onOpenCategory = { onOpenCategory(Category(id, title)) },
                        onItemsLoaded = { its ->
                            // first rail to load contributes the hero banner; collect a few for rotation
                            if (featured == null) featured = its.firstOrNull()
                            its.firstOrNull()?.let { first ->
                                if (featuredPool.size < 6 && featuredPool.none { it.name == first.name }) featuredPool.add(first)
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

/**
 * A single Video Club rail that fetches its own titles lazily the first time it composes
 * (so the screen paints instantly and posters stream in on scroll). Results are cached in
 * the shared map so scrolling back doesn't refetch.
 */
@Composable
private fun LazyRailRow(
    session: Session,
    categoryId: String,
    title: String,
    cache: MutableMap<String, List<UiMovie>>,
    onOpen: (UiMovie) -> Unit,
    onOpenCategory: () -> Unit,
    onItemsLoaded: (List<UiMovie>) -> Unit
) {
    var items by remember(categoryId) { mutableStateOf(cache[categoryId]) }
    LaunchedEffect(categoryId) {
        if (items != null) { onItemsLoaded(items!!); return@LaunchedEffect }
        val client = session.client ?: return@LaunchedEffect
        val loaded = withContext(Dispatchers.IO) {
            runCatching {
                client.getVodList(categoryId).take(15).map { pm ->
                    UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                        listOfNotNull(pm.year.ifBlank { null }).joinToString(" · "),
                        cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                        seriesId = if (pm.isSeries) pm.id else null,
                        added = pm.added, actors = pm.actors, director = pm.director, categoryId = categoryId)
                }
            }.getOrDefault(emptyList())
        }
        cache[categoryId] = loaded
        items = loaded
        if (loaded.isNotEmpty()) onItemsLoaded(loaded)
    }

    val current = items
    when {
        current == null -> {
            // not loaded yet — show the title + a skeleton strip
            Column(Modifier.padding(top = 6.dp, bottom = 12.dp)) {
                Text(title, color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 18.dp, bottom = 9.dp))
                SkeletonRow()
            }
        }
        current.isEmpty() -> { /* category had no titles — render nothing */ }
        else -> RailRow(Rail(title, current), onOpen, 0, onOpenCategory)
    }
}

@Composable
private fun HeroBanner(m: UiMovie, onPlay: () -> Unit, onInfo: () -> Unit, onBack: () -> Unit, autoFocus: Boolean = false) {
    val playFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    if (autoFocus) {
        LaunchedEffect(Unit) { try { playFocus.requestFocus() } catch (_: Exception) {} }
    }
    Box(Modifier.fillMaxWidth().height(330.dp)) {
        if (!m.poster.isNullOrBlank())
            AsyncImage(model = m.poster, contentDescription = m.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(m.hue), Color(0xFF10162A)))))
        // scrim
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0f to Color.Transparent, 0.55f to Color(0x99000000), 1f to Ink)))
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onBack() }.background(Color(0x33FFFFFF), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }; Spacer(Modifier.width(10.dp))
            Text("Movies", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text("VIDEO CLUB", color = Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
            Text("Featured tonight", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Text(m.name, color = TextCol, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            if (m.meta.isNotBlank())
                Text(m.meta, color = Color(0xFFC6CCDB), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Button(onClick = onPlay, modifier = Modifier.focusRequester(playFocus), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0B0E16))) {
                    Text("▶ Play", fontWeight = FontWeight.Bold)
                }
                Button(onClick = onInfo, colors = ButtonDefaults.buttonColors(containerColor = Color(0xD9282E42), contentColor = Color.White)) {
                    Text("ⓘ More info", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun RailRow(rail: Rail, onOpen: (UiMovie) -> Unit, railIndex: Int = 0, onOpenCategory: (() -> Unit)? = null) {
    Column(Modifier.padding(top = 6.dp, bottom = 12.dp)) {
        // Tappable title row → opens the full category grid ("see all")
        Row(
            Modifier.fillMaxWidth()
                .then(if (onOpenCategory != null) Modifier.clickable { onOpenCategory() } else Modifier)
                .padding(start = 18.dp, end = 18.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(rail.title, color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (onOpenCategory != null) {
                Spacer(Modifier.weight(1f))
                Text("See all ›", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 18.dp)
        ) {
            itemsIndexed(rail.items) { _, m -> RailPoster(m, onOpen) }
        }
    }
}

/** True if the title was added within the last ~14 days (drives the NEW badge). */
private fun isRecentlyAdded(added: String): Boolean {
    if (added.length < 10) return false
    return runCatching {
        val d = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(added.take(10)) ?: return false
        (System.currentTimeMillis() - d.time) in 0..(14L * 24 * 3600 * 1000)
    }.getOrDefault(false)
}

/** Pull a quality tag (4K/1080/720/HD) out of a title for the poster badge, or null if none. */
private fun qualityTag(name: String): String? {
    val n = name.uppercase()
    return when {
        Regex("\\b(4K|UHD|2160P?)\\b").containsMatchIn(n) -> "4K"
        Regex("\\b(1080P?|FHD)\\b").containsMatchIn(n) -> "1080"
        Regex("\\b720P?\\b").containsMatchIn(n) -> "720"
        Regex("\\bHD\\b").containsMatchIn(n) -> "HD"
        else -> null
    }
}

@Composable
private fun RailPoster(m: UiMovie, onOpen: (UiMovie) -> Unit, autoFocus: Boolean = false) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 1.07f else 1f, label = "poster")
    Column(Modifier.width(128.dp).scale(scale).tvFocus(androidx.compose.foundation.shape.RoundedCornerShape(12.dp), autoFocus)
        .clickable(interactionSource = interaction, indication = null) { onOpen(m) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(10.dp))
            .border(1.dp, Line, RoundedCornerShape(10.dp))) {
            if (!m.poster.isNullOrBlank())
                AsyncImage(model = m.poster, contentDescription = m.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(m.hue), Color(0xFF0C101D)))),
                    contentAlignment = Alignment.BottomStart) {
                    Text(m.name, color = TextCol, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(8.dp))
                }
            if (m.progress > 0)
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color(0x80000000))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(m.progress / 100f).background(Color(0xFFE0563B)))
                }
            if (isRecentlyAdded(m.added))
                Text("NEW", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopEnd).padding(5.dp)
                        .background(Color(0xFFE0563B), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp))
            qualityTag(m.name)?.let { q ->
                Text(q, color = Amber, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(5.dp)
                        .background(Color(0xCC0B0E16), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp))
            }
        }
    }
}

// ---------- Netflix-style detail page (backdrop) ----------
@Composable
fun VideoDetailScreen(movie: UiMovie, session: Session, onPlay: () -> Unit, onOpenSeries: (() -> Unit)? = null, onOpenMovie: (UiMovie) -> Unit = {}, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var inList by remember { mutableStateOf(Prefs.inMyList(ctx, movie.name)) }
    // "More like this" — other titles from the same category (honest approximation; no recsys).
    var moreLike by remember { mutableStateOf<List<UiMovie>>(emptyList()) }
    LaunchedEffect(movie.categoryId, movie.name) {
        val client = session.client
        if (movie.categoryId.isNotBlank() && client != null) {
            moreLike = withContext(Dispatchers.IO) {
                runCatching {
                    client.getVodList(movie.categoryId).filter { it.name != movie.name }.take(12).map { pm ->
                        UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                            cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                            seriesId = if (pm.isSeries) pm.id else null, added = pm.added,
                            actors = pm.actors, director = pm.director, categoryId = movie.categoryId)
                    }
                }.getOrDefault(emptyList())
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(250.dp)) {
            if (!movie.poster.isNullOrBlank())
                AsyncImage(model = movie.poster, contentDescription = movie.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(movie.hue), Color(0xFF10162A)))))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                0f to Color(0x22000000), 0.65f to Color(0x99000000), 1f to Ink)))
            Row(verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.align(Alignment.TopStart).padding(16.dp).clickable { onBack() }
                    .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 7.dp)) {
                Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(4.dp))
                Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(movie.name, color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.align(Alignment.BottomStart).padding(18.dp))
        }
        Column(Modifier.padding(18.dp)) {
            if (movie.meta.isNotBlank())
                Text(movie.meta, color = Color(0xFFC6CCDB), fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
            qualityTag(movie.name)?.let { q ->
                Text(q, color = Amber, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                        .background(Color(0x22FFFFFF), RoundedCornerShape(5.dp)).padding(horizontal = 7.dp, vertical = 2.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onPlay, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0B0E16))) {
                    Text("▶ Play", fontWeight = FontWeight.Bold)
                }
                if (onOpenSeries != null) {
                    // Series: an explicit button that opens the seasons & episodes list.
                    Button(onClick = onOpenSeries, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                        Text("≣ Open", fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Button(onClick = { Prefs.toggleMyList(ctx, movie); inList = !inList }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (inList) Amber else Color(0xD9282E42),
                            contentColor = if (inList) Color(0xFF1A1304) else Color.White)) {
                        Text(if (inList) "✓ My list" else "+ My list", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            if (movie.description.isNotBlank())
                Text(movie.description, color = Color(0xFFC6CCDB), fontSize = 13.sp, lineHeight = 20.sp)
            else Text("No description available.", color = Muted, fontSize = 13.sp)

            if (movie.director.isNotBlank() || movie.actors.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                if (movie.director.isNotBlank())
                    Text("Director: ${movie.director}", color = Muted, fontSize = 12.sp)
                if (movie.actors.isNotBlank())
                    Text("Cast: ${movie.actors}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }

            Spacer(Modifier.height(16.dp))

            if (moreLike.isNotEmpty()) {
                Spacer(Modifier.height(20.dp))
                Text("More like this", color = TextCol, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(end = 18.dp)) {
                    itemsIndexed(moreLike) { _, mm -> RailPoster(mm, onOpenMovie) }
                }
            }
        }
    }
}
