package com.streamline.app

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * Fallback playback engine using libVLC, which carries FFmpeg's decoders inside
 * it (HEVC on old hardware, AC3/E-AC3, DTS, MPEG-2, VC-1, odd streams).
 *
 * Exposes a small control surface so the custom overlay can drive it the same
 * way it drives ExoPlayer: play/pause, seek, position and duration.
 */
/** Engine-agnostic control surface the player overlay drives, so ExoPlayer, VLC and mpv can be
 *  swapped under it without the controls caring which engine is live. */
interface PlaybackController {
    fun playPause()
    fun isPlaying(): Boolean
    fun positionMs(): Long
    fun durationMs(): Long
    fun seekTo(ms: Long)
    fun seekBy(deltaMs: Long)
    fun setRate(rate: Float)
    fun audioTracks(): List<TrackOption>
    fun subtitleTracks(): List<TrackOption>
    fun currentAudio(): Int
    fun currentSpu(): Int
    fun selectAudio(id: Int)
    fun selectSpu(id: Int)
    fun enableFirstSubtitle(): Int
}

class VlcController : PlaybackController {
    var player: MediaPlayer? = null
    // Captured libVLC internal log lines (filtered to subtitle/SPU/render-relevant ones). Shown
    // on-screen so we can see what libVLC is actually doing with the subtitle without needing adb.
    val logLines = ArrayDeque<String>()
    fun addLog(line: String) {
        // Keep only the most recent ~12 relevant lines so the overlay stays readable.
        logLines.addLast(line)
        while (logLines.size > 12) logLines.removeFirst()
    }
    fun logText(): String = logLines.joinToString("\n")
    override fun playPause() { player?.let { if (it.isPlaying) it.pause() else it.play() } }
    override fun isPlaying(): Boolean = player?.isPlaying ?: false
    override fun positionMs(): Long {
        val p = player ?: return 0
        val len = p.length
        return if (len > 0) (p.position * len).toLong() else 0
    }
    override fun durationMs(): Long = player?.length ?: 0
    override fun seekTo(ms: Long) {
        val p = player ?: return
        val len = p.length
        if (len > 0) p.position = (ms.toFloat() / len).coerceIn(0f, 1f)
    }
    override fun seekBy(deltaMs: Long) = seekTo((positionMs() + deltaMs).coerceAtLeast(0))
    override fun setRate(rate: Float) { runCatching { player?.setRate(rate) } }

    // ---- Audio / subtitle track selection (libVLC 3.x TrackDescription API) ----
    override fun audioTracks(): List<TrackOption> =
        runCatching { player?.audioTracks?.map { TrackOption(it.id, it.name ?: "Audio ${it.id}") } }.getOrNull().orEmpty()
    override fun subtitleTracks(): List<TrackOption> =
        // libVLC's spuTracks includes a synthetic "Disable" entry with id -1; filter it out so the
        // picker shows only real subtitle tracks (and our own "Off" row handles disabling).
        runCatching { player?.spuTracks?.filter { it.id >= 0 }?.map { TrackOption(it.id, it.name ?: "Subtitle ${it.id}") } }.getOrNull().orEmpty()
    override fun currentAudio(): Int = runCatching { player?.audioTrack }.getOrNull() ?: -1
    override fun currentSpu(): Int = runCatching { player?.spuTrack }.getOrNull() ?: -1
    override fun selectAudio(id: Int) { runCatching { player?.audioTrack = id } }
    override fun selectSpu(id: Int) { runCatching { player?.spuTrack = id } }

    /** Auto-enable the first real subtitle track. Called after playback starts (tracks aren't known
     *  until then). Returns the id it selected, or -1 if no track was available. */
    override fun enableFirstSubtitle(): Int {
        val tracks = runCatching { player?.spuTracks?.filter { it.id >= 0 } }.getOrNull().orEmpty()
        val first = tracks.firstOrNull() ?: return -1
        runCatching { player?.spuTrack = first.id }
        return first.id
    }
}

/** One selectable audio or subtitle track, engine-agnostic (id is engine-specific). */
data class TrackOption(val id: Int, val label: String, val selected: Boolean = false)

@Composable
fun VlcPlayer(
    url: String,
    controller: VlcController,
    modifier: Modifier = Modifier,
    userAgent: String? = null,
    referer: String? = null,
    onError: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val libVlc = remember(url) {
        // Text subtitles render via libVLC's freetype module. The real fix was bumping
        // libvlc-all to 3.7.0 (the old 3.3.10 build couldn't render text on this device) plus
        // forcing a known system font, since Android font auto-discovery is unreliable.
        // The freetype-* options just style the result: white text, no background box, normal size.
        LibVLC(ctx, arrayListOf(
            "--no-drop-late-frames",
            "--no-skip-frames",
            "--rtsp-tcp",
            "--subsdec-encoding=Windows-1253",
            "--freetype-color=16777215",            // white text (0xFFFFFF)
            "--freetype-background-opacity=0",       // transparent (no box)
            "--freetype-background-color=0",
            "--freetype-outline-thickness=4",        // outline keeps text readable
            "--freetype-rel-fontsize=${(1800 / Prefs.subScaleFor(ctx, "vlc")).coerceIn(6, 80)}",  // per-player "VLC" slider: 100%→18 (bigger % = bigger text)
            "--sub-margin=40",                       // lift off the very bottom edge
            "--freetype-font=/system/fonts/Roboto-Regular.ttf"
        ))
    }
    val mediaPlayer = remember(url) { MediaPlayer(libVlc) }

    AndroidView(
        factory = { c ->
            VLCVideoLayout(c).apply {
                // attachViews(layout, sub, enableSubtitles, useTextureView).
                // 3rd arg = true so the SPU has a surface. 4th arg = FALSE: use SurfaceView.
                // TextureView might actually BREAK libVLC's SPU rendering (tried it in 274, still no subs).
                // libVLC's subtitle pipeline is tuned for SurfaceView. Keep it there.
                mediaPlayer.attachViews(this, null, true, false)
                // Surface VLC playback errors so the host can fall back to ExoPlayer.
                mediaPlayer.setEventListener { ev ->
                    if (ev.type == MediaPlayer.Event.EncounteredError) onError()
                }
                val media = Media(libVlc, Uri.parse(url))
                // Force SOFTWARE decoding. libVLC's hardware-decode path on Android frequently fails
                // to composite subtitles onto the video surface, leaving them invisible even when the
                // SPU track is selected. Software decode renders video + subtitles together. A
                // high-end tablet handles 1080p SW decode comfortably. (v242 had this set to true.)
                media.setHWDecoderEnabled(false, false)
                // Stalker CDNs gate on the box User-Agent (and sometimes Referer); pass the
                // session's values so VLC's fetch matches the API calls.
                val ua = userAgent ?: "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG254 stbapp ver: 4 rev: 2721 Safari/533.3"
                media.addOption(":http-user-agent=$ua")
                if (referer != null) media.addOption(":http-referrer=$referer")
                media.addOption(":http-reconnect")
                mediaPlayer.media = media
                media.release()
                controller.player = mediaPlayer
                mediaPlayer.play()
            }
        },
        modifier = modifier
    )

    DisposableEffect(url) {
        onDispose {
            controller.player = null
            runCatching {
                mediaPlayer.stop()
                mediaPlayer.detachViews()
                mediaPlayer.release()
                libVlc.release()
            }
        }
    }
}
