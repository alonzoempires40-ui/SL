package com.streamline.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Weather — original implementation (not copied from any vendor).
 * Uses the free Open-Meteo API: no key, no account, no server. Free for non-commercial use.
 * Location is a city name the user sets in Settings (no GPS permission needed — works on TV boxes).
 * Styled after a clean modern weather card: large temperature, condition, and an hourly strip.
 */

data class WeatherNow(
    val tempC: Int,
    val code: Int,
    val humidity: Int,
    val city: String,
    val hourly: List<HourTemp>,
    val windKmh: Int = 0,
    val highC: Int = 0,
    val lowC: Int = 0
) {
    /** Serialize to JSON so it can be cached and shown instantly next time. */
    fun toJson(): String {
        val h = org.json.JSONArray()
        hourly.forEach { h.put(JSONObject().put("h", it.hour).put("t", it.tempC).put("c", it.code)) }
        return JSONObject()
            .put("temp", tempC).put("code", code).put("hum", humidity)
            .put("city", city).put("hourly", h)
            .put("wind", windKmh).put("high", highC).put("low", lowC).toString()
    }
    companion object {
        fun fromJson(s: String): WeatherNow? = runCatching {
            val o = JSONObject(s)
            val arr = o.optJSONArray("hourly") ?: org.json.JSONArray()
            val list = mutableListOf<HourTemp>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                list.add(HourTemp(e.getString("h"), e.getInt("t"), e.getInt("c")))
            }
            WeatherNow(o.getInt("temp"), o.getInt("code"), o.getInt("hum"), o.getString("city"), list,
                o.optInt("wind", 0), o.optInt("high", 0), o.optInt("low", 0))
        }.getOrNull()
    }
}
data class HourTemp(val hour: String, val tempC: Int, val code: Int)

object Weather {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()

    /** Geocode a city name → lat/lon using Open-Meteo's free geocoding, then fetch the forecast. */
    suspend fun fetch(city: String): WeatherNow? = withContext(Dispatchers.IO) {
        runCatching {
            val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                java.net.URLEncoder.encode(city, "UTF-8") + "&count=1"
            val geo = JSONObject(get(geoUrl))
            val results = geo.optJSONArray("results") ?: return@runCatching null
            if (results.length() == 0) return@runCatching null
            val place = results.getJSONObject(0)
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val name = place.optString("name", city)

            val wUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min" +
                "&hourly=temperature_2m,weather_code&forecast_days=1&timezone=auto"
            val w = JSONObject(get(wUrl))
            val cur = w.getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").toInt()
            val hum = cur.optInt("relative_humidity_2m", 0)
            val code = cur.optInt("weather_code", 0)
            val wind = cur.optDouble("wind_speed_10m", 0.0).toInt()
            // daily high / low
            var high = 0; var low = 0
            w.optJSONObject("daily")?.let { dl ->
                dl.optJSONArray("temperature_2m_max")?.let { if (it.length() > 0) high = it.getDouble(0).toInt() }
                dl.optJSONArray("temperature_2m_min")?.let { if (it.length() > 0) low = it.getDouble(0).toInt() }
            }

            val hourly = mutableListOf<HourTemp>()
            val h = w.optJSONObject("hourly")
            if (h != null) {
                val times = h.getJSONArray("time")
                val temps = h.getJSONArray("temperature_2m")
                val codes = h.getJSONArray("weather_code")
                // start near the current hour, take the next 6
                val nowHour = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH", java.util.Locale.US)
                    .format(java.util.Date())
                var startIdx = 0
                for (i in 0 until times.length()) {
                    if (times.getString(i).startsWith(nowHour)) { startIdx = i; break }
                }
                var i = startIdx
                while (i < times.length() && hourly.size < 6) {
                    val t = times.getString(i)            // "2026-06-13T14:00"
                    val hh = t.substringAfter("T").substring(0, 5)
                    hourly.add(HourTemp(hh, temps.getDouble(i).toInt(), codes.getInt(i)))
                    i++
                }
            }
            WeatherNow(temp, code, hum, name, hourly, wind, high, low)
        }.getOrNull()
    }

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", "StreamLine").build()
        http.newCall(req).execute().use { r ->
            return r.body?.string() ?: ""
        }
    }

    /** Map an Open-Meteo weather code to a simple glyph + label. */
    fun glyph(code: Int): String = when (code) {
        0 -> "☀"                       // clear
        1, 2 -> "⛅"                    // mainly clear / partly cloudy
        3 -> "☁"                       // overcast
        45, 48 -> "🌫"                  // fog
        in 51..57 -> "🌦"              // drizzle
        in 61..67 -> "🌧"              // rain
        in 71..77 -> "❄"              // snow
        in 80..82 -> "🌦"             // showers
        in 95..99 -> "⛈"             // thunderstorm
        else -> "☁"
    }
    fun label(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        in 95..99 -> "Thunderstorm"
        else -> "Cloudy"
    }
}

/** The weather card, styled like a clean modern widget. Shown on the menu when a city is set. */
@Composable
fun WeatherCard(city: String) {
    val ctx = LocalContext.current
    // start from cache (if it matches this city) so the card shows INSTANTLY, then refresh
    var data by remember(city) {
        val cached = Weather.let { WeatherNow.fromJson(Prefs.weatherCache(ctx)) }
        mutableStateOf(if (cached != null && cached.city.equals(city.trim(), true)) cached else null)
    }
    var failed by remember(city) { mutableStateOf(false) }
    LaunchedEffect(city) {
        if (city.isBlank()) return@LaunchedEffect
        val w = Weather.fetch(city)
        if (w != null) {
            data = w
            Prefs.saveWeatherCache(ctx, w.toJson())   // cache for instant load next time
        } else if (data == null) {
            failed = true
        }
    }
    if (city.isBlank()) return

    Box(
        Modifier.fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(Color(0xFF1B2740), Color(0xFF141927))),
                RoundedCornerShape(18.dp)
            )
            .padding(18.dp)
    ) {
        when {
            failed -> Text("Weather unavailable for \"$city\" — check the city name in Settings.",
                color = Muted, fontSize = 13.sp)
            data == null -> Text("Loading weather…", color = Muted, fontSize = 13.sp)
            else -> {
                val d = data!!
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(Weather.glyph(d.code), fontSize = 40.sp)
                        Spacer(Modifier.width(14.dp))
                        Text("${d.tempC}°", color = TextCol, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(d.city, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(Weather.label(d.code), color = Muted, fontSize = 13.sp)
                            if (d.highC != 0 || d.lowC != 0)
                                Text("H:${d.highC}°  L:${d.lowC}°", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        // right side: humidity + wind, so the wide card isn't empty
                        Column(horizontalAlignment = Alignment.End) {
                            Text("💧 ${d.humidity}%", color = Amber, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text("Humidity", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("💨 ${d.windKmh} km/h", color = Amber, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text("Wind", color = Muted, fontSize = 11.sp)
                        }
                    }
                    if (d.hourly.isNotEmpty()) {
                        Spacer(Modifier.height(16.dp))
                        // spread the hours evenly across the full width so the card feels full
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            d.hourly.forEach { h ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 3.dp)
                                        .background(Color(0x33000000), RoundedCornerShape(12.dp))
                                        .padding(vertical = 12.dp)
                                ) {
                                    Text(h.hour, color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(Weather.glyph(h.code), fontSize = 20.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("${h.tempC}°", color = TextCol, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
