#!/usr/bin/env python3
"""Kotlin-aware brace/paren balance scanner.
States: code, line comment, block comment (nested), string, triple string, char.
Inside strings, ${ ... } template regions are scanned as code (their inner
braces/parens pair; the template's own { } delimiters are excluded).
A compiling Kotlin file must report 0/0."""
import sys

def scan(path):
    s = open(path, encoding='utf-8').read()
    i, n = 0, len(s)
    brace = paren = 0
    block_depth = 0            # nested /* */
    mode = 'code'              # code | line | str | tstr | char
    tmpl = []                  # stack of template brace depths (per nested template)
    while i < n:
        c = s[i]
        c2 = s[i:i+2]
        if mode == 'line':
            if c == '\n': mode = 'code'
            i += 1; continue
        if block_depth:
            if c2 == '/*': block_depth += 1; i += 2; continue
            if c2 == '*/': block_depth -= 1; i += 2; continue
            i += 1; continue
        if mode == 'char':
            if c == '\\': i += 2; continue
            if c == "'": mode = 'code'
            i += 1; continue
        if mode in ('str', 'tstr'):
            if tmpl and tmpl[-1] is not None:
                # inside ${...}: count as code until the matching }
                if c == '{': tmpl[-1] += 1; brace += 1; i += 1; continue
                if c == '}':
                    if tmpl[-1] == 0: tmpl.pop(); i += 1; continue
                    tmpl[-1] -= 1; brace -= 1; i += 1; continue
                if c == '(': paren += 1
                if c == ')': paren -= 1
                if c == '"':  # nested string inside template: treat as plain (rare)
                    j = i+1
                    while j < n and s[j] != '"':
                        if s[j] == '\\': j += 1
                        j += 1
                    i = j+1; continue
                i += 1; continue
            if mode == 'str':
                if c == '\\': i += 2; continue
                if c == '"': mode = 'code'; i += 1; continue
            else:  # tstr
                if s[i:i+3] == '"""':
                    # closing only if not more quotes ahead (""" ""..) – good enough
                    mode = 'code'; i += 3; continue
            if c2 == '${': tmpl.append(0); i += 2; continue
            i += 1; continue
        # mode == code
        if c2 == '//': mode = 'line'; i += 2; continue
        if c2 == '/*': block_depth = 1; i += 2; continue
        if s[i:i+3] == '"""': mode = 'tstr'; i += 3; continue
        if c == '"': mode = 'str'; i += 1; continue
        if c == "'": mode = 'char'; i += 1; continue
        if c == '{': brace += 1
        elif c == '}': brace -= 1
        elif c == '(': paren += 1
        elif c == ')': paren -= 1
        i += 1
    return brace, paren

if __name__ == '__main__':
    bad = 0
    for p in sys.argv[1:]:
        b, pr = scan(p)
        flag = 'OK ' if (b == 0 and pr == 0) else 'BAD'
        if flag == 'BAD': bad += 1
        print(f'{flag} braces={b:+d} parens={pr:+d}  {p}')
    sys.exit(1 if bad else 0)
