package com.streamline.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.scale
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.transform.Transformation
import android.graphics.Bitmap
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun hueColor(hex: String): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Color(0xFF2C3A66))

// A VOD category counts as "series" purely by its name. This provider files box-set/series
// content in categories named like "TV Series (Gr Subs)". Greek "σειρ" covers Σειρές/σειρές.
fun isSeriesCategory(title: String): Boolean {
    val t = title.lowercase()
    return t.contains("series") || t.contains("σειρ") || t.contains("box set") || t.contains("boxset")
}

// ---------- Netflix-style browse ----------
@Composable
fun VideoClubScreen(
    session: Session,
    onlySeries: Boolean = false,
    onOpen: (UiMovie) -> Unit,
    onPlay: (UiMovie) -> Unit,
    onOpenCategory: (Category) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // Lazy rails: load just the category list first (one fast call), show the rows
    // immediately, then each rail fetches its own posters when it scrolls into view.
    var categories by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    // cache of loaded rail items per category id, survives scrolling
    val railItems = remember { mutableStateMapOf<String, List<UiMovie>>() }
    // Adult categories (portal-flagged censored, or adult by name) now appear as rails AFTER the
    // normal ones. While the parental lock is on (default PIN 0000) each shows a 🔒 card — no
    // network fetch, no pictures — until the PIN is entered; the unlock lasts until app restart.
    var adultIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var adultLocked by remember { mutableStateOf(Prefs.adultLocked(ctx)) }
    var pinRequest by remember { mutableStateOf<Pair<Category, Boolean>?>(null) }   // (category, open it after unlock)
    var featured by remember { mutableStateOf<UiMovie?>(null) }
    // Rotating hero: collect the first poster of each rail into a pool and cycle through them.
    val featuredPool = remember { mutableStateListOf<UiMovie>() }
    var heroIndex by remember { mutableStateOf(0) }
    LaunchedEffect(featuredPool.size) {
        while (featuredPool.size > 1) { delay(7000); heroIndex = (heroIndex + 1) % featuredPool.size }
    }
    // Build 40 (StreamLine for MAG v14): Top 10, New this week, and how many titles each category tile has.
    // Both rows come from the portal's whole list, so they keep ONLY titles whose own category is one of
    // this side's normal (non-adult) categories (safeSideIds).
    var safeSideIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var top10 by remember { mutableStateOf<List<UiMovie>>(emptyList()) }
    var newWeek by remember { mutableStateOf<List<UiMovie>>(emptyList()) }
    val catCounts = remember { mutableStateMapOf<String, Int>() }

    LaunchedEffect(onlySeries) {
        if (session.client == null) {
            // demo: keep the existing demo rails as-is (filtered to match the tile)
            val rails = demoVodRails.filter { isSeriesCategory(it.title) == onlySeries }
            categories = rails.map { it.title to it.title }
            rails.forEach { railItems[it.title] = it.items }
            rails.forEach { catCounts[it.title] = it.items.size }     // build 40: demo tile counts
            featured = rails.firstOrNull()?.items?.firstOrNull()
            return@LaunchedEffect
        }
        try {
            val (normal, adult) = withContext(Dispatchers.IO) {
                // The "*"/All aggregate is never used (it mixes adult titles in). Name-based
                // Movies/Series split: keep only the side this tile asked for. Normal rails keep their
                // order and 40-rail cap; adult categories are appended after them (locked by default).
                val side = session.client.getVodCategories()
                    .filter { it.id != "*" && isSeriesCategory(it.title) == onlySeries }
                val isAdult = { c: VodCategory -> Prefs.isAdultCat(c.title, c.censored) }
                side.filter { !isAdult(it) }.take(40) to side.filter { isAdult(it) }
            }
            adultIds = adult.map { it.id }.toSet()
            // Build 38: adult titles never stay in Continue watching / My list. Clear any saved by
            // earlier builds, using EVERY adult category (movie and series side) so neither home
            // can show one. Runs before the rails are drawn, so they read the cleaned lists.
            val allAdult = withContext(Dispatchers.IO) {
                session.client.getVodCategories().filter { Prefs.isAdultCat(it.title, it.censored) }.map { it.id }.toSet()
            }
            Prefs.dropAdultSaved(ctx, allAdult)
            // Build 40: every normal (non-adult) category of this side — Top 10 / New this week keep only their titles.
            safeSideIds = withContext(Dispatchers.IO) {
                session.client.getVodCategories()
                    .filter { it.id != "*" && isSeriesCategory(it.title) == onlySeries && !Prefs.isAdultCat(it.title, it.censored) }
                    .map { it.id }.toSet()
            }
            categories = (normal + adult).map { it.id to it.title }
        } catch (e: Exception) { error = e.message ?: "Could not load video club" }
    }

    // Build 40 (v14): Top 10 = the first 10 of the portal's most-watched list (3 pages); New this week =
    // newest first (3 pages), added in the last 7 days, at most 20. Either row is hidden when empty.
    LaunchedEffect(safeSideIds) {
        val client = session.client ?: return@LaunchedEffect
        val ids = safeSideIds
        if (ids.isEmpty()) return@LaunchedEffect
        val toUi = { pm: PortalMovie ->
            UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                listOfNotNull(pm.year.ifBlank { null }).joinToString(" · "),
                cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                seriesId = if (pm.isSeries) pm.id else null,
                added = pm.added, actors = pm.actors, director = pm.director, categoryId = pm.categoryId,
                genres = pm.genres, age = pm.age, country = pm.country, runtimeMin = pm.runtimeMin)
        }
        top10 = withContext(Dispatchers.IO) {
            runCatching { client.getVodAcross("top", 3, ids).take(10).map(toUi) }.getOrDefault(emptyList())
        }
        newWeek = withContext(Dispatchers.IO) {
            runCatching { client.getVodAcross("added", 3, ids).filter { daysOld(it) in 0..6 }.take(20).map(toUi) }.getOrDefault(emptyList())
        }
    }

    // Build 40 (v14): the tiles' "N titles", asked one by one in the background (1.5 s, then 0.3 s apart).
    // Adult categories are never asked. A category whose row already loaded is counted without asking again.
    LaunchedEffect(categories) {
        val client = session.client ?: return@LaunchedEffect
        val cats = categories ?: return@LaunchedEffect
        delay(1500)
        for ((id, _) in cats) {
            if (id in adultIds || catCounts.containsKey(id)) continue
            val known = client.knownVodTotal(id)
            if (known != null) { catCounts[id] = known; continue }
            val n = withContext(Dispatchers.IO) { runCatching { client.getVodTotal(id) }.getOrNull() }
            if (n != null) catCounts[id] = n
            delay(300)
        }
    }

    when {
        error != null -> Column(Modifier.fillMaxSize().padding(20.dp)) { TopBar("Video club", onBack); EmptyState("⚠", "Couldn't load the video club", error, isError = true) }
        categories == null -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().padding(20.dp)) { TopBar("Video club", onBack) }
            SkeletonRow(); SkeletonRow()
        }
        categories!!.isEmpty() -> Column(Modifier.fillMaxSize().padding(20.dp)) { TopBar("Video club", onBack); EmptyState("🎬", "No titles yet", "Your provider hasn't shared any movies, or none are available.") }
        else -> {
            // Build 39 (StreamLine for MAG v14): the row with the poster you are on moves to the top.
            val colState = rememberLazyListState()
            val colScope = rememberCoroutineScope()
            val toTop: (Int) -> Unit = { index -> colScope.launch { runCatching { colState.animateScrollToItem(index) } } }
            // Build 40 (v14): a title in the Top 10 shows "#N in Movies" / "#N in Series" under any row.
            val sideWord = if (onlySeries) "Series" else "Movies"
            val rankText: (UiMovie) -> String? = { m ->
                top10.indexOfFirst { it.name == m.name }.takeIf { it >= 0 }?.let { "#${it + 1} in $sideWord" }
            }
            LazyColumn(Modifier.fillMaxSize(), state = colState) {
                item {
                    val f = featuredPool.getOrNull(heroIndex) ?: featured
                    if (f != null) HeroBanner(f, onPlay = { onPlay(f) }, onInfo = { onOpen(f) }, onBack = onBack, autoFocus = true)
                    else {
                        // simple header until the first rail's hero item is available
                        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onBack() }.background(Color(0x33FFFFFF), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }; Spacer(Modifier.width(10.dp))
                            Text("Movies", color = TextCol, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text("VIDEO CLUB", color = Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                // Build 40 (v14): coloured category tiles under the banner — picture, name, how many titles.
                item {
                    CategoryTilesRow(
                        cats = categories!!, adultIds = adultIds, locked = adultLocked, counts = catCounts,
                        onFocused = { toTop(1) },
                        onOpen = { id, title ->
                            if (adultLocked && id in adultIds) pinRequest = Category(id, title, true) to true
                            else onOpenCategory(Category(id, title, id in adultIds))
                        })
                }
                // Continue Watching + My List rails (only when they have items) — tap a Continue item
                // to resume, a My List item to open its detail.
                // (build 39: Continue watching and My list are now two list entries, so each can move to the top)
                item {
                    // While locked, titles saved from an adult category are left out (no pictures).
                    val cont = remember { Prefs.continueList(ctx) }.let { l -> if (adultLocked) l.filter { it.categoryId !in adultIds } else l }
                    if (cont.isNotEmpty()) RailRow(Rail("Continue watching", cont), onPlay, onExpanded = { toTop(2) }, rankText = rankText)
                }
                item {
                    val mine = remember { Prefs.myList(ctx) }.let { l -> if (adultLocked) l.filter { it.categoryId !in adultIds } else l }
                    if (mine.isNotEmpty()) RailRow(Rail("My list", mine), onOpen, onExpanded = { toTop(3) }, rankText = rankText)
                }
                // Build 40 (v14): Top 10 of this side, with the big numbers beside the posters
                item {
                    if (top10.isNotEmpty()) RailRow(Rail(if (onlySeries) "Top 10 Series" else "Top 10 Movies", top10), onOpen,
                        onExpanded = { toTop(4) }, rankText = rankText, topTen = true)
                }
                // Build 40 (v14): titles added in the last 7 days
                item {
                    if (newWeek.isNotEmpty()) RailRow(Rail("New this week", newWeek), onOpen, onExpanded = { toTop(5) }, rankText = rankText)
                }
                itemsIndexed(categories!!) { catIndex, (id, title) ->
                    LazyRailRow(
                        onExpanded = { toTop(6 + catIndex) },
                        rankText = rankText,
                        session = session,
                        categoryId = id,
                        title = title,
                        adult = id in adultIds,
                        locked = adultLocked && id in adultIds,
                        onUnlockRequest = { openAfter -> pinRequest = Category(id, title, true) to openAfter },
                        cache = railItems,
                        onOpen = onOpen,
                        onOpenCategory = { onOpenCategory(Category(id, title, id in adultIds)) },
                        onItemsLoaded = { its ->
                            // first rail to load contributes the hero banner; collect a few for rotation
                            if (featured == null) featured = its.firstOrNull()
                            its.firstOrNull()?.let { first ->
                                if (featuredPool.size < 6 && featuredPool.none { it.name == first.name }) featuredPool.add(first)
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    pinRequest?.let { (cat, openAfter) ->
        AdultLockDialog(
            onDismiss = { pinRequest = null },
            onUnlocked = { pinRequest = null; adultLocked = false; if (openAfter) onOpenCategory(cat) }
        )
    }
}

/**
 * A single Video Club rail that fetches its own titles lazily the first time it composes
 * (so the screen paints instantly and posters stream in on scroll). Results are cached in
 * the shared map so scrolling back doesn't refetch.
 */
@Composable
private fun LazyRailRow(
    session: Session,
    categoryId: String,
    title: String,
    cache: MutableMap<String, List<UiMovie>>,
    onOpen: (UiMovie) -> Unit,
    onOpenCategory: () -> Unit,
    onItemsLoaded: (List<UiMovie>) -> Unit,
    adult: Boolean = false,
    locked: Boolean = false,
    onUnlockRequest: (openAfter: Boolean) -> Unit = {},
    onExpanded: () -> Unit = {},
    rankText: (UiMovie) -> String? = { null }
) {
    var items by remember(categoryId) { mutableStateOf(cache[categoryId]) }
    LaunchedEffect(categoryId, locked) {
        if (locked) return@LaunchedEffect                    // adult + locked: no fetch, no pictures
        // Adult rails never feed the rotating hero banner at the top of the screen.
        if (items != null) { if (!adult) onItemsLoaded(items!!); return@LaunchedEffect }
        val client = session.client ?: return@LaunchedEffect
        val loaded = withContext(Dispatchers.IO) {
            runCatching {
                // Adult rails (only reached once unlocked) must ask with allowAdult — the default
                // fetch refuses censored categories and would come back empty.
                (if (adult) client.getVodPage(categoryId, 1, allowAdult = true).items else client.getVodList(categoryId)).take(15).map { pm ->
                    UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                        listOfNotNull(pm.year.ifBlank { null }).joinToString(" · "),
                        cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                        seriesId = if (pm.isSeries) pm.id else null,
                        added = pm.added, actors = pm.actors, director = pm.director, categoryId = categoryId, adult = adult, genres = pm.genres, age = pm.age, country = pm.country, runtimeMin = pm.runtimeMin)
                }
            }.getOrDefault(emptyList())
        }
        cache[categoryId] = loaded
        items = loaded
        if (loaded.isNotEmpty() && !adult) onItemsLoaded(loaded)
    }

    val current = items
    when {
        locked -> {
            // Locked adult rail: the category button (with 🔒) and one card — never any pictures.
            Column(Modifier.padding(top = 6.dp, bottom = 12.dp)) {
                Row(Modifier.padding(start = 18.dp, end = 18.dp, bottom = 9.dp)) {
                    CategoryButton(title, locked = true) { onUnlockRequest(true) }
                }
                LockedRailCard { onUnlockRequest(false) }
            }
        }
        current == null -> {
            // not loaded yet — show the category button + a skeleton strip
            Column(Modifier.padding(top = 6.dp, bottom = 12.dp)) {
                Row(Modifier.padding(start = 18.dp, end = 18.dp, bottom = 9.dp)) {
                    CategoryButton(title) { onOpenCategory() }
                }
                SkeletonRow()
            }
        }
        current.isEmpty() -> { /* category had no titles — render nothing */ }
        else -> RailRow(Rail(title, current), onOpen, 0, onOpenCategory, onExpanded = onExpanded, rankText = rankText)
    }
}

@Composable
private fun HeroBanner(m: UiMovie, onPlay: () -> Unit, onInfo: () -> Unit, onBack: () -> Unit, autoFocus: Boolean = false) {
    val playFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    if (autoFocus) {
        LaunchedEffect(Unit) { try { playFocus.requestFocus() } catch (_: Exception) {} }
    }
    Box(Modifier.fillMaxWidth().height(330.dp)) {
        if (!m.poster.isNullOrBlank())
            AsyncImage(model = m.poster, contentDescription = m.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(m.hue), Color(0xFF10162A)))))
        // scrim
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0f to Color.Transparent, 0.55f to Color(0x99000000), 1f to Ink)))
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onBack() }.background(Color(0x33FFFFFF), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }; Spacer(Modifier.width(10.dp))
            Text("Movies", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text("VIDEO CLUB", color = Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
            Text("Featured tonight", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Text(m.name, color = TextCol, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            if (m.meta.isNotBlank())
                Text(m.meta, color = Color(0xFFC6CCDB), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Button(onClick = onPlay, modifier = Modifier.focusRequester(playFocus), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0B0E16))) {
                    Text("▶ Play", fontWeight = FontWeight.Bold)
                }
                Button(onClick = onInfo, colors = ButtonDefaults.buttonColors(containerColor = Color(0xD9282E42), contentColor = Color.White)) {
                    Text("ⓘ More info", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun RailRow(rail: Rail, onOpen: (UiMovie) -> Unit, railIndex: Int = 0, onOpenCategory: (() -> Unit)? = null,
                    onExpanded: () -> Unit = {}, rankText: (UiMovie) -> String? = { null }, topTen: Boolean = false) {
    // Build 39 (StreamLine for MAG v14): the poster you are on grows 25% with no frame; its row opens
    // up above and below so nothing is covered; its information appears under the row; its title and
    // year show in amber in the row's heading. With a remote only (a touch tap opens the title).
    val k = railScale()
    val growTop = 315f * k * 0.125f + 5f * k        // room above the bigger poster (v14 zoom_top)
    val growBottom = 315f * k * 0.125f              // room below it (v14 zoom_gd)
    var focusedIdx by remember(rail.title) { mutableStateOf(-1) }
    var seeAllFocused by remember(rail.title) { mutableStateOf(false) }
    val expanded = focusedIdx >= 0 || seeAllFocused
    LaunchedEffect(expanded) { if (expanded) onExpanded() }
    val listState = rememberLazyListState()
    // the first poster fully in view grows to the right only (its left edge stays put), like v14
    val firstFull by remember { derivedStateOf { listState.layoutInfo.visibleItemsInfo.firstOrNull { it.offset >= 0 }?.index ?: 0 } }
    val focusedItem = rail.items.getOrNull(focusedIdx)
    Column(Modifier.padding(top = 6.dp, bottom = 12.dp)) {
        // Title row → opens the full category grid ("see all"). For a category the NAME is a real
        // button (pill + remote focus ring). The row stays tappable for touch but is not a separate
        // remote focus stop, so the D-pad lands on one visible target per header: the button.
        Row(
            Modifier.fillMaxWidth()
                .then(if (onOpenCategory != null) Modifier.focusProperties { canFocus = false }.clickable { onOpenCategory() } else Modifier)
                .padding(start = 18.dp, end = 18.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (onOpenCategory != null) Arrangement.SpaceBetween else Arrangement.Start
        ) {
            if (onOpenCategory != null) {
                CategoryButton(rail.title, modifier = Modifier.weight(1f, fill = false)) { onOpenCategory() }
                Spacer(Modifier.width(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    focusedItem?.let { FocusedTitle(it, k); Spacer(Modifier.width(14.dp)) }
                    Text("See all ›", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                if (topTen) { TopTenPill(); Spacer(Modifier.width(9.dp)) }     // build 40 (v14)
                Text(rail.title, color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                focusedItem?.let { Spacer(Modifier.weight(1f)); FocusedTitle(it, k) }
            }
        }
        LazyRow(
            state = listState,
            horizontalArrangement = Arrangement.spacedBy((18f * k).dp),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp,
                top = if (expanded) growTop.dp else 0.dp, bottom = if (expanded) growBottom.dp else 0.dp)
        ) {
            itemsIndexed(rail.items) { i, m ->
                if (topTen)
                    // build 40 (v14): the rank number sits left of the poster, the poster drawn over it
                    Row(Modifier.zIndex(if (focusedIdx == i) 1f else 0f)) {
                        TopNumber(i + 1, k)
                        RailPoster(m, onOpen, zoom = true, growRight = i == firstFull,
                            onFocusChange = { f -> if (f) focusedIdx = i else if (focusedIdx == i) focusedIdx = -1 })
                    }
                else
                RailPoster(m, onOpen, zoom = true, growRight = i == firstFull,
                    onFocusChange = { f -> if (f) focusedIdx = i else if (focusedIdx == i) focusedIdx = -1 })
            }
            // v14: every category row ends with a "See all" card (it grows like the posters)
            if (onOpenCategory != null) item {
                SeeAllCard(k, growRight = rail.items.size == firstFull, onFocusChange = { f -> seeAllFocused = f }) { onOpenCategory() }
            }
        }
        if (focusedItem != null) RailInfoPanel(focusedItem, k, rankText(focusedItem))
    }
}

/** True if the title was added within the last ~14 days (drives the NEW badge). */
private fun isRecentlyAdded(added: String): Boolean {
    if (added.length < 10) return false
    return runCatching {
        val d = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(added.take(10)) ?: return false
        (System.currentTimeMillis() - d.time) in 0..(14L * 24 * 3600 * 1000)
    }.getOrDefault(false)
}

/** Pull a quality tag (4K/1080/720/HD) out of a title for the poster badge, or null if none. */
private fun qualityTag(name: String): String? {
    val n = name.uppercase()
    return when {
        Regex("\\b(4K|UHD|2160P?)\\b").containsMatchIn(n) -> "4K"
        Regex("\\b(1080P?|FHD)\\b").containsMatchIn(n) -> "1080"
        Regex("\\b720P?\\b").containsMatchIn(n) -> "720"
        Regex("\\bHD\\b").containsMatchIn(n) -> "HD"
        else -> null
    }
}

@Composable
private fun RailPoster(m: UiMovie, onOpen: (UiMovie) -> Unit, autoFocus: Boolean = false,
                       zoom: Boolean = false, growRight: Boolean = false,
                       onFocusChange: (Boolean) -> Unit = {}, widthDp: Float? = null) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 1.07f else 1f, label = "poster")
    // Build 39: StreamLine for MAG v14 sizes. v14 was designed on a 1280-wide screen with 210 × 315
    // posters 18 apart, so every screen shows 5 and part of a 6th (≈277 wide on the 14" tablet,
    // ≈158 on the 70" TV). Replaces build 36's 6-per-row width. widthDp: a caller's own size.
    val posterW = widthDp ?: (210f * railScale())
    var focused by remember { mutableStateOf(false) }
    val focusMod = if (zoom)
        // the poster you are on: 25% bigger, drawn over its neighbours, no frame (v14);
        // the first one in view grows to the right (its left edge stays put)
        Modifier.zIndex(if (focused) 1f else 0f)
            .graphicsLayer {
                val s = if (focused) 1.25f else scale
                scaleX = s; scaleY = s
                transformOrigin = TransformOrigin(if (growRight) 0f else 0.5f, 0.5f)
            }
            .onFocusChanged { focused = it.hasFocus; onFocusChange(it.hasFocus) }
            .focusable()
    else Modifier.scale(scale).tvFocus(androidx.compose.foundation.shape.RoundedCornerShape(12.dp), autoFocus)
    Column(Modifier.width(posterW.dp).then(focusMod)
        .clickable(interactionSource = interaction, indication = null) { onOpen(m) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(10.dp))
            .border(1.dp, Line, RoundedCornerShape(10.dp))) {
            if (!m.poster.isNullOrBlank())
                AsyncImage(model = m.poster, contentDescription = m.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(m.hue), Color(0xFF0C101D)))),
                    contentAlignment = Alignment.BottomStart) {
                    Text(m.name, color = TextCol, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(8.dp))
                }
            if (m.progress > 0)
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color(0x80000000))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(m.progress / 100f).background(Color(0xFFE0563B)))
                }
            if (isRecentlyAdded(m.added))
                Text("NEW", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopEnd).padding(5.dp)
                        .background(Color(0xFFE0563B), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp))
            qualityTag(m.name)?.let { q ->
                Text(q, color = Amber, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(5.dp)
                        .background(Color(0xCC0B0E16), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp))
            }
        }
    }
}

/** Build 39: StreamLine for MAG v14 was designed on a 1280-wide screen; this scales its sizes to this one. */
@Composable
private fun railScale(): Float = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp / 1280f

/** v14: the poster you are on, as "name · year" in amber at the right of the row's heading. */
@Composable
private fun FocusedTitle(m: UiMovie, k: Float) {
    val year = m.year.takeIf { it.isNotBlank() && it != "0" }
    Text(m.name + (if (year != null) " · $year" else ""), color = Amber, fontSize = (16f * k).sp, fontWeight = FontWeight.Medium,
        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = (568f * k).dp))
}

/** v14: under the row — title; age pill; year · length · genre · country; two lines of the story. */
@Composable
private fun RailInfoPanel(m: UiMovie, k: Float, rank: String? = null) {
    val meta = listOfNotNull(
        m.year.takeIf { it.isNotBlank() && it != "0" },
        m.runtimeMin.takeIf { it > 0 }?.let { "$it min" },
        m.genres.ifBlank { null },
        m.country.ifBlank { null }
    ).joinToString(" · ")
    Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = (9f * k).dp)) {
        Text(m.name, color = Color.White, fontSize = (26f * k).sp, lineHeight = (32f * k).sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (rank != null || m.age.isNotBlank() || meta.isNotBlank())
            Row(Modifier.padding(top = (6f * k).dp), verticalAlignment = Alignment.CenterVertically) {
                // build 40 (v14): "#N in Movies" — white pill, first
                if (rank != null)
                    Text(rank, color = Ink, fontSize = (15f * k).sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = (9f * k).dp)
                            .background(Color.White, RoundedCornerShape((8f * k).dp))
                            .padding(horizontal = (13f * k).dp, vertical = (5f * k).dp))
                if (m.age.isNotBlank())
                    Text(m.age, color = TextCol, fontSize = (15f * k).sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = (9f * k).dp)
                            .background(Color(0xFF262E45), RoundedCornerShape((8f * k).dp))
                            .padding(horizontal = (13f * k).dp, vertical = (5f * k).dp))
                if (meta.isNotBlank())
                    Text(meta, color = Color(0xFFC6CCDB), fontSize = (17f * k).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        if (m.description.isNotBlank())
            Text(m.description, color = Muted, fontSize = (17f * k).sp, lineHeight = (25f * k).sp, maxLines = 2,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = (8f * k).dp).fillMaxWidth(0.76f))
    }
}

/** v14: the "See all" card at the end of a category row; it grows like a poster when you are on it. */
@Composable
private fun SeeAllCard(k: Float, growRight: Boolean, onFocusChange: (Boolean) -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.width((210f * k).dp).aspectRatio(2f / 3f)
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer {
                val s = if (focused) 1.25f else 1f
                scaleX = s; scaleY = s
                transformOrigin = TransformOrigin(if (growRight) 0f else 0.5f, 0.5f)
            }
            .onFocusChanged { focused = it.hasFocus; onFocusChange(it.hasFocus) }
            .focusable()
            .clickable { onClick() }
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF141927))
            .border(1.dp, Line, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("See all ›", color = Amber, fontSize = (18f * k).sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Build 40 (v14): the red "TOP 10" label before the Top 10 row's title. */
@Composable
private fun TopTenPill() {
    Text("TOP 10", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
        modifier = Modifier.background(Color(0xFFE0563B), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
}

/** Build 40 (v14): a Top 10 rank as a big outlined number (dark inside, blue-grey edge), standing on the
 *  poster's bottom line. Its box is 36% of a poster wide; the rest of the number goes under the poster. */
@Composable
private fun TopNumber(n: Int, k: Float) {
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    Box(Modifier.width((210f * 0.36f * k).dp).height((315f * k).dp).drawBehind {
        paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        paint.textSize = 299f * k * density
        paint.letterSpacing = -11f / 299f
        // a little above the bottom line, so the round bottoms of 3, 5, 6, 8, 9, 0 are not cut by the row's edge
        val base = size.height - 8f * k * density
        drawIntoCanvas { c ->
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = 0xFF0B0E16.toInt()
            c.nativeCanvas.drawText(n.toString(), 0f, base, paint)
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 5f * k * density
            paint.color = 0xFF3A4566.toInt()
            c.nativeCanvas.drawText(n.toString(), 0f, base, paint)
        }
    })
}

/** Build 40 (v14): days since the portal added the title (0 = today); -1 when it gives no date. */
private fun daysOld(pm: PortalMovie): Int {
    if (pm.today) return 0
    if (pm.yesterday) return 1
    val m = Regex("^(\\d{4})-(\\d{1,2})-(\\d{1,2})").find(pm.added) ?: return -1
    return runCatching {
        val added = java.time.LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
        java.time.temporal.ChronoUnit.DAYS.between(added, java.time.LocalDate.now()).toInt()
    }.getOrDefault(-1)
}

/** Build 40 (v14): the category tile colours (top-left → bottom-right); adult tiles use the grey lock colours. */
private val tileColors = listOf(
    Color(0xFF7A2A3A) to Color(0xFF2A1220), Color(0xFF2A3F7A) to Color(0xFF141C38),
    Color(0xFF7A5A1A) to Color(0xFF2A1E0C), Color(0xFF1F6A5A) to Color(0xFF0E2A26),
    Color(0xFF3C5A2A) to Color(0xFF16220F), Color(0xFF5A2A7A) to Color(0xFF22102E),
    Color(0xFF7A3A1A) to Color(0xFF2A140C), Color(0xFF1F4F7A) to Color(0xFF0E2236)
)

/** Build 40 (v14): the tile picture, chosen from the category name (English and Greek words, v14's list). */
private fun categoryEmoji(title: String, adult: Boolean): String {
    if (adult) return "🔒"
    val t = title.lowercase()
    val map = listOf(
        "💥" to listOf("action", "δράσ", "δραση"), "😂" to listOf("comed", "κωμωδ"), "🎭" to listOf("drama", "δράμα", "δραμα"),
        "🧸" to listOf("kid", "child", "παιδ"), "👪" to listOf("family", "οικογ"), "🎨" to listOf("anim", "cartoon", "κινουμ", "κινούμ"),
        "🌍" to listOf("docu", "ντοκιμ"), "👻" to listOf("horror", "τρόμ", "τρομ"), "🔪" to listOf("thrill", "θρίλ", "θριλ"),
        "🕵️" to listOf("crime", "αστυν"), "🚀" to listOf("sci", "επιστ"), "🐉" to listOf("fantas", "φαντασ"),
        "💕" to listOf("roman", "ρομαντ"), "🎵" to listOf("music", "μουσ"), "⚽" to listOf("sport", "αθλη"), "🎖️" to listOf("war", "πολεμ"),
        "🤠" to listOf("western", "γουέστ"), "🧭" to listOf("advent", "περιπ"), "🏛️" to listOf("histor", "ιστορ"),
        "🇬🇷" to listOf("greek", "ελλην"), "📺" to listOf("series", "σειρ", "box set", "boxset"), "🔒" to listOf("adult", "xxx", "18+", "ενηλ"),
        "📽️" to listOf("4k", "uhd")
    )
    for ((emoji, words) in map) if (words.any { t.contains(it) }) return emoji
    return "🎬"
}

/** Build 40 (v14): the row of coloured category tiles under the banner. The tile you are on grows 15%
 *  (the first one in view grows to the right); a locked adult tile asks for the PIN. */
@Composable
private fun CategoryTilesRow(cats: List<Pair<String, String>>, adultIds: Set<String>, locked: Boolean,
                             counts: Map<String, Int>, onFocused: () -> Unit, onOpen: (String, String) -> Unit) {
    if (cats.isEmpty()) return
    val k = railScale()
    val listState = rememberLazyListState()
    val firstFull by remember { derivedStateOf { listState.layoutInfo.visibleItemsInfo.firstOrNull { it.offset >= 0 }?.index ?: 0 } }
    var rowFocused by remember { mutableStateOf(false) }
    LaunchedEffect(rowFocused) { if (rowFocused) onFocused() }
    Column(Modifier.padding(top = 6.dp, bottom = 12.dp)) {
        Text("Categories", color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 9.dp))
        LazyRow(
            modifier = Modifier.onFocusChanged { rowFocused = it.hasFocus },
            state = listState,
            horizontalArrangement = Arrangement.spacedBy((18f * k).dp),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = (10f * k).dp, bottom = (10f * k).dp)
        ) {
            itemsIndexed(cats) { i, (id, title) ->
                val adult = id in adultIds
                val count = if (adult && locked) "Locked" else counts[id]?.let { "$it titles" } ?: ""
                CategoryTile(title, i, adult, count, k, growRight = i == firstFull) { onOpen(id, title) }
            }
        }
    }
}

@Composable
private fun CategoryTile(title: String, index: Int, adult: Boolean, count: String, k: Float, growRight: Boolean,
                         onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val colors = if (adult) Color(0xFF3A3F52) to Color(0xFF16181F) else tileColors[index % tileColors.size]
    val shape = RoundedCornerShape((18f * k).dp)
    Box(
        Modifier.width((250f * k).dp).height((120f * k).dp)
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer {
                val s = if (focused) 1.15f else 1f
                scaleX = s; scaleY = s
                transformOrigin = TransformOrigin(if (growRight) 0f else 0.5f, 0.5f)
            }
            .shadow(if (focused) (13f * k).dp else 0.dp, shape)
            .onFocusChanged { focused = it.hasFocus }
            .focusable()
            .clickable { onClick() }
            .clip(shape)
            .background(Brush.linearGradient(listOf(colors.first, colors.second)))
    ) {
        Box(Modifier.align(Alignment.TopEnd).padding(end = (16f * k).dp, top = (14f * k).dp).size((48f * k).dp),
            contentAlignment = Alignment.Center) {
            Text(categoryEmoji(title, adult), fontSize = (34f * k).sp)
        }
        Text(title, color = Color.White, fontSize = (23f * k).sp, lineHeight = (28f * k).sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = (20f * k).dp, end = (14f * k).dp, bottom = (36f * k).dp))
        if (count.isNotBlank())
            Text(count, color = Color(0xB8FFFFFF), fontSize = (13f * k).sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.BottomStart).padding(start = (20f * k).dp, bottom = (15f * k).dp))
    }
}

// Detail-page backdrop (option C): shrink the poster to a few pixels by repeated halving (each step
// averages, so no sparkle); drawn stretched, it becomes soft colour on every Android version.
private object SoftBackdrop : Transformation {
    override val cacheKey: String = "streamline.softBackdrop.v1"
    override suspend fun transform(input: Bitmap, size: coil.size.Size): Bitmap {
        var b: Bitmap = if (input.config == Bitmap.Config.HARDWARE) (input.copy(Bitmap.Config.ARGB_8888, false) ?: return input) else input
        while (b.width > 24 || b.height > 24)
            b = Bitmap.createScaledBitmap(b, maxOf(1, b.width / 2), maxOf(1, b.height / 2), true)
        return b
    }
}

// ---------- Netflix-style detail page (backdrop) ----------
@Composable
fun VideoDetailScreen(movie: UiMovie, session: Session, onPlay: () -> Unit, onOpenSeries: (() -> Unit)? = null, onOpenMovie: (UiMovie) -> Unit = {}, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var inList by remember(movie.name) { mutableStateOf(Prefs.inMyList(ctx, movie.name)) }
    // "More like this" — other titles from the same category (honest approximation; no recsys).
    var moreLike by remember { mutableStateOf<List<UiMovie>>(emptyList()) }
    LaunchedEffect(movie.categoryId, movie.name) {
        val client = session.client
        if (movie.categoryId.isNotBlank() && client != null) {
            moreLike = withContext(Dispatchers.IO) {
                runCatching {
                    client.getVodList(movie.categoryId).filter { it.name != movie.name }.take(12).map { pm ->
                        UiMovie(pm.name, pm.year, pm.description, pm.poster.ifBlank { null },
                            cmd = pm.cmd, portalTrailer = pm.trailer.ifBlank { null },
                            seriesId = if (pm.isSeries) pm.id else null, added = pm.added,
                            actors = pm.actors, director = pm.director, categoryId = movie.categoryId, adult = movie.adult, genres = pm.genres, age = pm.age, country = pm.country, runtimeMin = pm.runtimeMin)
                    }
                }.getOrDefault(emptyList())
            }
        }
    }

    // Option C (build 34): the strip shows the same picture blurred into colour (loaded tiny and
    // stretched, so it also works on Android 9 where Compose's blur does nothing) and the whole
    // poster sits in front of it as a card — the picture is never cut or blown up.
    val backdrop = remember(movie.poster) {
        ImageRequest.Builder(ctx).data(movie.poster).transformations(SoftBackdrop).build()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(250.dp).background(Color(0xFF10162A))) {
                if (!movie.poster.isNullOrBlank())
                    AsyncImage(model = backdrop, contentDescription = null, modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop, alpha = 0.85f)
                else
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(movie.hue), Color(0xFF10162A)))))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                    0f to Color(0x22000000), 0.55f to Color(0x22000000), 1f to Ink)))
                Row(verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.align(Alignment.TopStart).padding(16.dp).clickable { onBack() }
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 7.dp)) {
                    Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(4.dp))
                    Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Row(Modifier.fillMaxWidth().padding(start = 24.dp, top = 130.dp, end = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                // The whole poster, never cropped (Fit), as a card overlapping the strip.
                Box(Modifier.width(170.dp).aspectRatio(2f / 3f).shadow(12.dp, RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp)).background(Panel2)
                    .border(1.dp, Line, RoundedCornerShape(12.dp))) {
                    if (!movie.poster.isNullOrBlank())
                        AsyncImage(model = movie.poster, contentDescription = movie.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else
                        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(hueColor(movie.hue), Color(0xFF10162A)))))
                }
        Column(Modifier.weight(1f).padding(top = 70.dp)) {
            Text(movie.name, color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(bottom = 6.dp))
            if (movie.meta.isNotBlank())
                Text(movie.meta, color = Color(0xFFC6CCDB), fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
            qualityTag(movie.name)?.let { q ->
                Text(q, color = Amber, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                        .background(Color(0x22FFFFFF), RoundedCornerShape(5.dp)).padding(horizontal = 7.dp, vertical = 2.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth()) {
                Button(onClick = onPlay, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0B0E16))) {
                    Text("▶ Play", fontWeight = FontWeight.Bold)
                }
                if (onOpenSeries != null) {
                    // Series: an explicit button that opens the seasons & episodes list.
                    Button(onClick = onOpenSeries, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304))) {
                        Text("≣ Open", fontWeight = FontWeight.SemiBold)
                    }
                    // Series favourite: same My list as movies (the stored record keeps seriesId, so a
                    // saved series reopens as a series from the My list rail on Movies and Series homes).
                    Button(onClick = {
                        // Build 38: adult titles are never saved to My list — say so instead of saving.
                        if (movie.adult && !inList) android.widget.Toast.makeText(ctx, "Adult titles are not saved to My list", android.widget.Toast.LENGTH_SHORT).show()
                        else { Prefs.toggleMyList(ctx, movie); inList = !inList }
                    }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (inList) Amber else Color(0xD9282E42),
                            contentColor = if (inList) Color(0xFF1A1304) else Color.White)) {
                        Text(if (inList) "✓ My list" else "+ My list", fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Button(onClick = {
                        // Build 38: adult titles are never saved to My list — say so instead of saving.
                        if (movie.adult && !inList) android.widget.Toast.makeText(ctx, "Adult titles are not saved to My list", android.widget.Toast.LENGTH_SHORT).show()
                        else { Prefs.toggleMyList(ctx, movie); inList = !inList }
                    }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (inList) Amber else Color(0xD9282E42),
                            contentColor = if (inList) Color(0xFF1A1304) else Color.White)) {
                        Text(if (inList) "✓ My list" else "+ My list", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            if (movie.description.isNotBlank())
                Text(movie.description, color = Color(0xFFC6CCDB), fontSize = 13.sp, lineHeight = 20.sp)
            else Text("No description available.", color = Muted, fontSize = 13.sp)

            if (movie.director.isNotBlank() || movie.actors.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                if (movie.director.isNotBlank())
                    Text("Director: ${movie.director}", color = Muted, fontSize = 12.sp)
                if (movie.actors.isNotBlank())
                    Text("Cast: ${movie.actors}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
            }
        }
        Column(Modifier.padding(start = 18.dp, end = 18.dp, bottom = 18.dp)) {
            Spacer(Modifier.height(16.dp))

            if (moreLike.isNotEmpty()) {
                Spacer(Modifier.height(20.dp))
                Text("More like this", color = TextCol, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                // build 39: v14's "More like this" size — 150 × 225 on a 1280 screen, 18 apart, frame (no growing)
                val mk = railScale()
                LazyRow(horizontalArrangement = Arrangement.spacedBy((18f * mk).dp), contentPadding = PaddingValues(end = 18.dp)) {
                    itemsIndexed(moreLike) { _, mm -> RailPoster(mm, onOpenMovie, widthDp = 150f * mk) }
                }
            }
        }
    }
}

// A category name as a real button — the same translucent pill and remote focus ring as the app's
// other chips. A locked adult category shows a 🔒 and asks for the PIN first.
@Composable
private fun CategoryButton(title: String, modifier: Modifier = Modifier, locked: Boolean = false, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.tvFocus(RoundedCornerShape(10.dp)).clickable { onClick() }
            .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        if (locked) { Text("🔒", fontSize = 13.sp); Spacer(Modifier.width(6.dp)) }
        Text(title, color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        Spacer(Modifier.width(6.dp))
        Text("›", color = Amber, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

// Placeholder for a locked adult rail: one card, no images, tap to enter the PIN.
@Composable
private fun LockedRailCard(onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 18.dp)
            .tvFocus(RoundedCornerShape(12.dp)).clickable { onClick() }
            .background(Panel, RoundedCornerShape(12.dp))
            .border(1.dp, Line, RoundedCornerShape(12.dp))
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Text("🔒", fontSize = 26.sp)
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Locked", color = TextCol, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Enter the parental PIN to show this category", color = Muted, fontSize = 12.sp)
        }
    }
}
